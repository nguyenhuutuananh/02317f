#
# TABLE STRUCTURE FOR: district
#

DROP TABLE IF EXISTS `district`;

CREATE TABLE `district` (
  `districtid` varchar(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL,
  `provinceid` varchar(5) NOT NULL,
  PRIMARY KEY (`districtid`),
  KEY `provinceid` (`provinceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('001', 'Ba Đình', 'Quận', '21 02 08N, 105 49 38E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('002', 'Hoàn Kiếm', 'Quận', '21 01 53N, 105 51 09E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('003', 'Tây Hồ', 'Quận', '21 04 10N, 105 49 07E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('004', 'Long Biên', 'Quận', '21 02 21N, 105 53 07E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('005', 'Cầu Giấy', 'Quận', '21 01 52N, 105 47 20E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('006', 'Đống Đa', 'Quận', '21 00 56N, 105 49 06E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('007', 'Hai Bà Trưng', 'Quận', '21 00 27N, 105 51 35E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('008', 'Hoàng Mai', 'Quận', '20 58 33N, 105 51 22E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('009', 'Thanh Xuân', 'Quận', '20 59 44N, 105 48 56E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('016', 'Sóc Sơn', 'Huyện', '21 16 55N, 105 49 46E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('017', 'Đông Anh', 'Huyện', '21 08 16N, 105 49 38E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('018', 'Gia Lâm', 'Huyện', '21 01 28N, 105 56 54E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('019', 'Từ Liêm', 'Huyện', '21 02 39N, 105 45 32E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('020', 'Thanh Trì', 'Huyện', '20 56 32N, 105 50 55E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('024', 'Hà Giang', 'Thị Xã', '22 46 23N, 105 02 39E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('026', 'Đồng Văn', 'Huyện', '23 14 34N, 105 15 48E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('027', 'Mèo Vạc', 'Huyện', '23 09 10N, 105 26 38E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('028', 'Yên Minh', 'Huyện', '23 04 20N, 105 10 13E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('029', 'Quản Bạ', 'Huyện', '23 04 03N, 104 58 05E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('030', 'Vị Xuyên', 'Huyện', '22 45 50N, 104 56 26E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('031', 'Bắc Mê', 'Huyện', '22 45 48N, 105 16 26E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('032', 'Hoàng Su Phì', 'Huyện', '22 41 37N, 104 40 06E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('033', 'Xín Mần', 'Huyện', '22 38 05N, 104 28 35E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('034', 'Bắc Quang', 'Huyện', '22 23 42N, 104 55 06E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('035', 'Quang Bình', 'Huyện', '22 23 07N, 104 37 11E', '02');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('040', 'Cao Bằng', 'Thị Xã', '22 39 20N, 106 15 20E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('042', 'Bảo Lâm', 'Huyện', '22 52 37N, 105 27 28E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('043', 'Bảo Lạc', 'Huyện', '22 52 31N, 105 42 41E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('044', 'Thông Nông', 'Huyện', '22 49 09N, 105 57 05E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('045', 'Hà Quảng', 'Huyện', '22 53 42N, 106 06 32E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('046', 'Trà Lĩnh', 'Huyện', '22 48 14N, 106 19 47E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('047', 'Trùng Khánh', 'Huyện', '22 49 31N, 106 33 58E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('048', 'Hạ Lang', 'Huyện', '22 42 37N, 106 41 42E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('049', 'Quảng Uyên', 'Huyện', '22 40 15N, 106 27 42E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('050', 'Phục Hoà', 'Huyện', '22 33 52N, 106 30 02E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('051', 'Hoà An', 'Huyện', '22 41 20N, 106 02 05E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('052', 'Nguyên Bình', 'Huyện', '22 38 52N, 105 57 02E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('053', 'Thạch An', 'Huyện', '22 28 51N, 106 19 51E', '04');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('058', 'Bắc Kạn', 'Thị Xã', '22 08 00N, 105 51 10E', '06');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('060', 'Pác Nặm', 'Huyện', '22 35 46N, 105 40 25E', '06');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('061', 'Ba Bể', 'Huyện', '22 23 54N, 105 43 30E', '06');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('062', 'Ngân Sơn', 'Huyện', '22 25 50N, 106 01 00E', '06');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('063', 'Bạch Thông', 'Huyện', '22 12 04N, 105 51 01E', '06');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('064', 'Chợ Đồn', 'Huyện', '22 11 18N, 105 34 43E', '06');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('065', 'Chợ Mới', 'Huyện', '21 57 56N, 105 51 29E', '06');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('066', 'Na Rì', 'Huyện', '22 09 48N, 106 05 09E', '06');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('070', 'Tuyên Quang', 'Thị Xã', '21 49 40N, 105 13 12E', '08');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('072', 'Nà Hang', 'Huyện', '22 28 34N, 105 21 03E', '08');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('073', 'Chiêm Hóa', 'Huyện', '22 12 49N, 105 14 32E', '08');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('074', 'Hàm Yên', 'Huyện', '22 05 46N, 105 00 13E', '08');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('075', 'Yên Sơn', 'Huyện', '21 51 53N, 105 18 14E', '08');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('076', 'Sơn Dương', 'Huyện', '21 40 22N, 105 22 57E', '08');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('080', 'Lào Cai', 'Thành Phố', '22 25 07N, 103 58 43E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('082', 'Bát Xát', 'Huyện', '22 35 50N, 103 44 49E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('083', 'Mường Khương', 'Huyện', '22 41 05N, 104 08 26E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('084', 'Si Ma Cai', 'Huyện', '22 39 46N, 104 16 05E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('085', 'Bắc Hà', 'Huyện', '22 30 08N, 104 18 54E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('086', 'Bảo Thắng', 'Huyện', '22 22 47N, 104 10 00E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('087', 'Bảo Yên', 'Huyện', '22 17 38N, 104 25 02E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('088', 'Sa Pa', 'Huyện', '22 18 54N, 103 54 18E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('089', 'Văn Bàn', 'Huyện', '22 03 48N, 104 10 59E', '10');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('094', 'Điện Biên Phủ', 'Thành Phố', '21 24 52N, 103 02 31E', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('095', 'Mường Lay', 'Thị Xã', '22 01 47N, 103 07 10E', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('096', 'Mường Nhé', 'Huyện', '22 06 11N, 102 30 54E', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('097', 'Mường Chà', 'Huyện', '21 50 31N, 103 03 15E', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('098', 'Tủa Chùa', 'Huyện', '21 58 19N, 103 23 01E', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('099', 'Tuần Giáo', 'Huyện', '21 38 03N, 103 21 06E', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('100', 'Điện Biên', 'Huyện', '21 15 19N, 103 03 19E', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('101', 'Điện Biên Đông', 'Huyện', '21 14 07N, 103 15 19E', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('102', 'Mường Ảng', 'Huyện', '', '11');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('104', 'Lai Châu', 'Thị Xã', '22 23 15N, 103 24 22E', '12');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('106', 'Tam Đường', 'Huyện', '22 20 16N, 103 32 53E', '12');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('107', 'Mường Tè', 'Huyện', '22 24 16N, 102 43 11E', '12');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('108', 'Sìn Hồ', 'Huyện', '22 17 21N, 103 18 12E', '12');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('109', 'Phong Thổ', 'Huyện', '22 38 24N, 103 22 38E', '12');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('110', 'Than Uyên', 'Huyện', '21 59 35N, 103 45 30E', '12');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('111', 'Tân Uyên', 'Huyện', '', '12');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('116', 'Sơn La', 'Thành Phố', '21 20 39N, 103 54 52E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('118', 'Quỳnh Nhai', 'Huyện', '21 46 34N, 103 39 02E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('119', 'Thuận Châu', 'Huyện', '21 24 54N, 103 39 46E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('120', 'Mường La', 'Huyện', '21 31 38N, 104 02 48E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('121', 'Bắc Yên', 'Huyện', '21 13 23N, 104 22 09E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('122', 'Phù Yên', 'Huyện', '21 13 33N, 104 41 51E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('123', 'Mộc Châu', 'Huyện', '20 49 21N, 104 43 10E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('124', 'Yên Châu', 'Huyện', '20 59 33N, 104 19 51E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('125', 'Mai Sơn', 'Huyện', '21 10 08N, 103 59 36E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('126', 'Sông Mã', 'Huyện', '21 06 04N, 103 43 56E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('127', 'Sốp Cộp', 'Huyện', '20 52 46N, 103 30 38E', '14');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('132', 'Yên Bái', 'Thành Phố', '21 44 28N, 104 53 42E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('133', 'Nghĩa Lộ', 'Thị Xã', '21 35 58N, 104 29 22E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('135', 'Lục Yên', 'Huyện', '22 06 44N, 104 43 12E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('136', 'Văn Yên', 'Huyện', '21 55 55N, 104 33 51E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('137', 'Mù Cang Chải', 'Huyện', '21 48 22N, 104 09 01E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('138', 'Trấn Yên', 'Huyện', '21 42 20N, 104 48 56E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('139', 'Trạm Tấu', 'Huyện', '21 30 40N, 104 28 03E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('140', 'Văn Chấn', 'Huyện', '21 34 15N, 104 35 19E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('141', 'Yên Bình', 'Huyện', '21 52 24N, 104 55 16E', '15');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('148', 'Hòa Bình', 'Thành Phố', '20 50 36N, 105 19 20E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('150', 'Đà Bắc', 'Huyện', '20 55 58N, 105 04 52E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('151', 'Kỳ Sơn', 'Huyện', '20 54 06N, 105 23 18E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('152', 'Lương Sơn', 'Huyện', '20 53 16N, 105 30 55E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('153', 'Kim Bôi', 'Huyện', '20 40 34N, 105 32 15E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('154', 'Cao Phong', 'Huyện', '20 41 23N, 105 17 48E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('155', 'Tân Lạc', 'Huyện', '20 36 44N, 105 15 03E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('156', 'Mai Châu', 'Huyện', '20 40 56N, 104 59 46E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('157', 'Lạc Sơn', 'Huyện', '20 29 59N, 105 24 57E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('158', 'Yên Thủy', 'Huyện', '20 25 42N, 105 37 59E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('159', 'Lạc Thủy', 'Huyện', '20 29 12N, 105 44 06E', '17');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('164', 'Thái Nguyên', 'Thành Phố', '21 33 20N, 105 48 26E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('165', 'Sông Công', 'Thị Xã', '21 29 14N, 105 48 47E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('167', 'Định Hóa', 'Huyện', '21 53 50N, 105 38 01E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('168', 'Phú Lương', 'Huyện', '21 45 57N, 105 43 22E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('169', 'Đồng Hỷ', 'Huyện', '21 41 10N, 105 55 43E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('170', 'Võ Nhai', 'Huyện', '21 47 14N, 106 02 29E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('171', 'Đại Từ', 'Huyện', '21 36 17N, 105 37 28E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('172', 'Phổ Yên', 'Huyện', '21 27 08N, 105 45 19E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('173', 'Phú Bình', 'Huyện', '21 29 36N, 105 57 42E', '19');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('178', 'Lạng Sơn', 'Thành Phố', '21 51 19N, 106 44 50E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('180', 'Tràng Định', 'Huyện', '22 18 09N, 106 26 32E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('181', 'Bình Gia', 'Huyện', '22 03 56N, 106 19 01E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('182', 'Văn Lãng', 'Huyện', '22 01 59N, 106 34 17E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('183', 'Cao Lộc', 'Huyện', '21 53 05N, 106 50 34E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('184', 'Văn Quan', 'Huyện', '21 51 04N, 106 33 04E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('185', 'Bắc Sơn', 'Huyện', '21 48 57N, 106 15 28E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('186', 'Hữu Lũng', 'Huyện', '21 34 33N, 106 20 33E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('187', 'Chi Lăng', 'Huyện', '21 40 05N, 106 37 24E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('188', 'Lộc Bình', 'Huyện', '21 40 41N, 106 58 12E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('189', 'Đình Lập', 'Huyện', '21 32 07N, 107 07 25E', '20');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('193', 'Hạ Long', 'Thành Phố', '20 52 24N, 107 05 23E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('194', 'Móng Cái', 'Thành Phố', '21 26 31N, 107 55 09E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('195', 'Cẩm Phả', 'Thị Xã', '21 03 42N, 107 17 22E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('196', 'Uông Bí', 'Thị Xã', '21 04 33N, 106 45 07E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('198', 'Bình Liêu', 'Huyện', '21 33 07N, 107 26 24E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('199', 'Tiên Yên', 'Huyện', '21 22 24N, 107 22 50E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('200', 'Đầm Hà', 'Huyện', '21 21 23N, 107 34 32E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('201', 'Hải Hà', 'Huyện', '21 25 50N, 107 41 26E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('202', 'Ba Chẽ', 'Huyện', '21 15 40N, 107 09 52E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('203', 'Vân Đồn', 'Huyện', '20 56 17N, 107 28 02E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('204', 'Hoành Bồ', 'Huyện', '21 06 30N, 107 02 43E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('205', 'Đông Triều', 'Huyện', '21 07 10N, 106 34 36E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('206', 'Yên Hưng', 'Huyện', '20 55 40N, 106 51 05E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('207', 'Cô Tô', 'Huyện', '21 05 01N, 107 49 10E', '22');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('213', 'Bắc Giang', 'Thành Phố', '21 17 36N, 106 11 18E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('215', 'Yên Thế', 'Huyện', '21 31 29N, 106 09 27E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('216', 'Tân Yên', 'Huyện', '21 23 23N, 106 05 55E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('217', 'Lạng Giang', 'Huyện', '21 21 58N, 106 15 21E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('218', 'Lục Nam', 'Huyện', '21 18 16N, 106 29 24E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('219', 'Lục Ngạn', 'Huyện', '21 26 15N, 106 39 09E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('220', 'Sơn Động', 'Huyện', '21 19 42N, 106 51 09E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('221', 'Yên Dũng', 'Huyện', '21 12 22N, 106 14 12E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('222', 'Việt Yên', 'Huyện', '21 16 16N, 106 04 59E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('223', 'Hiệp Hòa', 'Huyện', '21 15 51N, 105 57 30E', '24');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('227', 'Việt Trì', 'Thành Phố', '21 19 01N, 105 23 35E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('228', 'Phú Thọ', 'Thị Xã', '21 24 54N, 105 13 46E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('230', 'Đoan Hùng', 'Huyện', '21 36 56N, 105 08 42E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('231', 'Hạ Hoà', 'Huyện', '21 35 13N, 105 00 22E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('232', 'Thanh Ba', 'Huyện', '21 27 04N, 105 09 10E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('233', 'Phù Ninh', 'Huyện', '21 26 59N, 105 18 13E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('234', 'Yên Lập', 'Huyện', '21 22 21N, 105 01 25E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('235', 'Cẩm Khê', 'Huyện', '21 23 04N, 105 05 25E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('236', 'Tam Nông', 'Huyện', '21 18 24N, 105 14 59E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('237', 'Lâm Thao', 'Huyện', '21 19 37N, 105 18 09E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('238', 'Thanh Sơn', 'Huyện', '21 08 32N, 105 04 40E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('239', 'Thanh Thuỷ', 'Huyện', '21 07 26N, 105 17 18E', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('240', 'Tân Sơn', 'Huyện', '', '25');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('243', 'Vĩnh Yên', 'Thành Phố', '21 18 26N, 105 35 33E', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('244', 'Phúc Yên', 'Thị Xã', '21 18 55N, 105 43 54E', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('246', 'Lập Thạch', 'Huyện', '21 24 45N, 105 25 39E', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('247', 'Tam Dương', 'Huyện', '21 21 40N, 105 33 36E', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('248', 'Tam Đảo', 'Huyện', '21 27 34N, 105 35 09E', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('249', 'Bình Xuyên', 'Huyện', '21 19 48N, 105 39 43E', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('250', 'Mê Linh', 'Huyện', '21 10 53N, 105 42 05E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('251', 'Yên Lạc', 'Huyện', '21 13 17N, 105 34 44E', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('252', 'Vĩnh Tường', 'Huyện', '21 14 58N, 105 29 37E', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('253', 'Sông Lô', 'Huyện', '', '26');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('256', 'Bắc Ninh', 'Thành Phố', '21 10 48N, 106 03 58E', '27');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('258', 'Yên Phong', 'Huyện', '21 12 40N, 105 59 36E', '27');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('259', 'Quế Võ', 'Huyện', '21 08 44N, 106 11 06E', '27');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('260', 'Tiên Du', 'Huyện', '21 07 37N, 106 02 19E', '27');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('261', 'Từ Sơn', 'Thị Xã', '21 07 12N, 105 57 26E', '27');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('262', 'Thuận Thành', 'Huyện', '21 02 24N, 106 04 10E', '27');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('263', 'Gia Bình', 'Huyện', '21 03 55N, 106 12 53E', '27');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('264', 'Lương Tài', 'Huyện', '21 01 33N, 106 13 28E', '27');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('268', 'Hà Đông', 'Quận', '20 57 25N, 105 45 21E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('269', 'Sơn Tây', 'Thị Xã', '21 05 51N, 105 28 27E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('271', 'Ba Vì', 'Huyện', '21 09 40N, 105 22 43E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('272', 'Phúc Thọ', 'Huyện', '21 06 32N, 105 34 52E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('273', 'Đan Phượng', 'Huyện', '21 07 13N, 105 40 49E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('274', 'Hoài Đức', 'Huyện', '21 01 25N, 105 42 03E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('275', 'Quốc Oai', 'Huyện', '20 58 45N, 105 36 43E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('276', 'Thạch Thất', 'Huyện', '21 02 17N, 105 33 05E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('277', 'Chương Mỹ', 'Huyện', '20 52 46N, 105 39 01E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('278', 'Thanh Oai', 'Huyện', '20 51 44N, 105 46 18E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('279', 'Thường Tín', 'Huyện', '20 49 59N, 105 22 19E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('280', 'Phú Xuyên', 'Huyện', '20 43 37N, 105 53 43E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('281', 'Ứng Hòa', 'Huyện', '20 42 41N, 105 47 58E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('282', 'Mỹ Đức', 'Huyện', '20 41 53N, 105 43 31E', '01');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('288', 'Hải Dương', 'Thành Phố', '20 56 14N, 106 18 21E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('290', 'Chí Linh', 'Huyện', '21 07 47N, 106 23 46E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('291', 'Nam Sách', 'Huyện', '21 00 15N, 106 20 26E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('292', 'Kinh Môn', 'Huyện', '21 00 04N, 106 30 23E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('293', 'Kim Thành', 'Huyện', '20 55 40N, 106 30 33E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('294', 'Thanh Hà', 'Huyện', '20 53 19N, 106 25 43E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('295', 'Cẩm Giàng', 'Huyện', '20 57 05N, 106 12 29E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('296', 'Bình Giang', 'Huyện', '20 52 36N, 106 11 24E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('297', 'Gia Lộc', 'Huyện', '20 51 01N, 106 17 34E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('298', 'Tứ Kỳ', 'Huyện', '20 49 05N, 106 24 05E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('299', 'Ninh Giang', 'Huyện', '20 45 13N, 106 20 09E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('300', 'Thanh Miện', 'Huyện', '20 46 02N, 106 12 26E', '30');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('303', 'Hồng Bàng', 'Quận', '20 52 37N, 106 38 32E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('304', 'Ngô Quyền', 'Quận', '20 51 13N, 106 41 57E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('305', 'Lê Chân', 'Quận', '20 50 12N, 106 40 30E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('306', 'Hải An', 'Quận', '20 49 38N, 106 45 57E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('307', 'Kiến An', 'Quận', '20 48 26N, 106 38 03E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('308', 'Đồ Sơn', 'Quận', '20 42 41N, 106 44 54E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('309', 'Kinh Dương', 'Quận', '', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('311', 'Thuỷ Nguyên', 'Huyện', '20 56 36N, 106 39 38E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('312', 'An Dương', 'Huyện', '20 53 06N, 106 35 36E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('313', 'An Lão', 'Huyện', '20 47 54N, 106 33 19E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('314', 'Kiến Thụy', 'Huyện', '20 45 13N, 106 41 47E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('315', 'Tiên Lãng', 'Huyện', '20 42 23N, 106 36 03E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('316', 'Vĩnh Bảo', 'Huyện', '20 40 56N, 106 29 57E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('317', 'Cát Hải', 'Huyện', '20 47 09N, 106 58 07E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('318', 'Bạch Long Vĩ', 'Huyện', '20 08 41N, 107 42 51E', '31');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('323', 'Hưng Yên', 'Thành Phố', '20 39 38N, 106 03 08E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('325', 'Văn Lâm', 'Huyện', '20 58 31N, 106 02 51E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('326', 'Văn Giang', 'Huyện', '20 55 51N, 105 57 14E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('327', 'Yên Mỹ', 'Huyện', '20 53 45N, 106 01 21E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('328', 'Mỹ Hào', 'Huyện', '20 55 35N, 106 05 34E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('329', 'Ân Thi', 'Huyện', '20 48 49N, 106 05 30E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('330', 'Khoái Châu', 'Huyện', '20 49 53N, 105 58 28E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('331', 'Kim Động', 'Huyện', '20 44 47N, 106 01 47E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('332', 'Tiên Lữ', 'Huyện', '20 40 05N, 106 07 59E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('333', 'Phù Cừ', 'Huyện', '20 42 51N, 106 11 30E', '33');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('336', 'Thái Bình', 'Thành Phố', '20 26 45N, 106 19 56E', '34');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('338', 'Quỳnh Phụ', 'Huyện', '20 38 57N, 106 21 16E', '34');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('339', 'Hưng Hà', 'Huyện', '20 35 38N, 106 12 42E', '34');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('340', 'Đông Hưng', 'Huyện', '20 32 50N, 106 20 15E', '34');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('341', 'Thái Thụy', 'Huyện', '20 32 33N, 106 32 32E', '34');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('342', 'Tiền Hải', 'Huyện', '20 21 05N, 106 32 45E', '34');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('343', 'Kiến Xương', 'Huyện', '20 23 52N, 106 25 22E', '34');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('344', 'Vũ Thư', 'Huyện', '20 25 29N, 106 16 43E', '34');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('347', 'Phủ Lý', 'Thành Phố', '20 32 19N, 105 54 55E', '35');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('349', 'Duy Tiên', 'Huyện', '20 37 33N, 105 58 01E', '35');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('350', 'Kim Bảng', 'Huyện', '20 34 19N, 105 50 41E', '35');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('351', 'Thanh Liêm', 'Huyện', '20 27 31N, 105 55 09E', '35');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('352', 'Bình Lục', 'Huyện', '20 29 23N, 106 02 52E', '35');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('353', 'Lý Nhân', 'Huyện', '20 32 55N, 106 04 48E', '35');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('356', 'Nam Định', 'Thành Phố', '20 25 07N, 106 09 54E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('358', 'Mỹ Lộc', 'Huyện', '20 27 21N, 106 07 56E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('359', 'Vụ Bản', 'Huyện', '20 22 57N, 106 05 35E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('360', 'Ý Yên', 'Huyện', '20 19 48N, 106 01 55E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('361', 'Nghĩa Hưng', 'Huyện', '20 05 37N, 106 08 59E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('362', 'Nam Trực', 'Huyện', '20 20 08N, 106 12 54E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('363', 'Trực Ninh', 'Huyện', '20 14 42N, 106 12 45E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('364', 'Xuân Trường', 'Huyện', '20 17 53N, 106 21 43E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('365', 'Giao Thủy', 'Huyện', '20 14 45N, 106 28 39E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('366', 'Hải Hậu', 'Huyện', '20 06 26N, 106 16 29E', '36');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('369', 'Ninh Bình', 'Thành Phố', '20 14 45N, 105 58 24E', '37');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('370', 'Tam Điệp', 'Thị Xã', '20 09 42N, 103 52 43E', '37');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('372', 'Nho Quan', 'Huyện', '20 18 46N, 105 42 48E', '37');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('373', 'Gia Viễn', 'Huyện', '20 19 50N, 105 52 20E', '37');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('374', 'Hoa Lư', 'Huyện', '20 15 04N, 105 55 52E', '37');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('375', 'Yên Khánh', 'Huyện', '20 11 26N, 106 04 33E', '37');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('376', 'Kim Sơn', 'Huyện', '20 02 07N, 106 05 27E', '37');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('377', 'Yên Mô', 'Huyện', '20 07 45N, 105 59 45E', '37');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('380', 'Thanh Hóa', 'Thành Phố', '19 48 26N, 105 47 37E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('381', 'Bỉm Sơn', 'Thị Xã', '20 05 21N, 105 51 48E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('382', 'Sầm Sơn', 'Thị Xã', '19 45 11N, 105 54 03E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('384', 'Mường Lát', 'Huyện', '20 30 42N, 104 37 27E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('385', 'Quan Hóa', 'Huyện', '20 29 15N, 104 56 35E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('386', 'Bá Thước', 'Huyện', '20 22 48N, 105 14 50E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('387', 'Quan Sơn', 'Huyện', '20 15 17N, 104 51 58E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('388', 'Lang Chánh', 'Huyện', '20 08 58N, 105 07 40E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('389', 'Ngọc Lặc', 'Huyện', '20 04 08N, 105 22 39E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('390', 'Cẩm Thủy', 'Huyện', '20 12 20N, 105 27 22E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('391', 'Thạch Thành', 'Huyện', '21 12 41N, 105 36 38E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('392', 'Hà Trung', 'Huyện', '20 03 20N, 105 51 20E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('393', 'Vĩnh Lộc', 'Huyện', '20 02 29N, 105 39 28E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('394', 'Yên Định', 'Huyện', '20 00 31N, 105 37 44E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('395', 'Thọ Xuân', 'Huyện', '19 55 39N, 105 29 14E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('396', 'Thường Xuân', 'Huyện', '19 54 55N, 105 10 46E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('397', 'Triệu Sơn', 'Huyện', '19 48 11N, 105 34 03E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('398', 'Thiệu Hoá', 'Huyện', '19 53 56N, 105 40 57E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('399', 'Hoằng Hóa', 'Huyện', '19 51 59N, 105 51 34E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('400', 'Hậu Lộc', 'Huyện', '19 56 02N, 105 53 19E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('401', 'Nga Sơn', 'Huyện', '20 00 16N, 105 59 26E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('402', 'Như Xuân', 'Huyện', '19 5 55N, 105 20 22E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('403', 'Như Thanh', 'Huyện', '19 35 19N, 105 33 09E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('404', 'Nông Cống', 'Huyện', '19 36 58N, 105 40 54E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('405', 'Đông Sơn', 'Huyện', '19 47 44N, 105 42 19E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('406', 'Quảng Xương', 'Huyện', '19 40 53N, 105 48 01E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('407', 'Tĩnh Gia', 'Huyện', '19 27 13N, 105 43 38E', '38');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('412', 'Vinh', 'Thành Phố', '18 41 06N, 105 42 05E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('413', 'Cửa Lò', 'Thị Xã', '18 47 26N, 105 43 31E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('414', 'Thái Hoà', 'Thị Xã', '', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('415', 'Quế Phong', 'Huyện', '19 42 25N, 104 54 21E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('416', 'Quỳ Châu', 'Huyện', '19 32 16N, 105 03 18E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('417', 'Kỳ Sơn', 'Huyện', '19 24 36N, 104 09 45E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('418', 'Tương Dương', 'Huyện', '19 19 15N, 104 35 41E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('419', 'Nghĩa Đàn', 'Huyện', '19 21 19N, 105 26 33E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('420', 'Quỳ Hợp', 'Huyện', '19 19 24N, 105 09 12E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('421', 'Quỳnh Lưu', 'Huyện', '19 14 01N, 105 37 00E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('422', 'Con Cuông', 'Huyện', '19 03 50N, 107 47 15E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('423', 'Tân Kỳ', 'Huyện', '19 06 11N, 105 14 14E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('424', 'Anh Sơn', 'Huyện', '18 58 04N, 105 04 30E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('425', 'Diễn Châu', 'Huyện', '19 01 20N, 105 34 13E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('426', 'Yên Thành', 'Huyện', '19 01 25N, 105 26 17E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('427', 'Đô Lương', 'Huyện', '18 55 00N, 105 21 03E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('428', 'Thanh Chương', 'Huyện', '18 44 11N, 105 12 59E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('429', 'Nghi Lộc', 'Huyện', '18 47 41N, 105 31 30E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('430', 'Nam Đàn', 'Huyện', '18 40 28N, 105 30 32E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('431', 'Hưng Nguyên', 'Huyện', '18 41 13N, 105 37 41E', '40');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('436', 'Hà Tĩnh', 'Thành Phố', '18 21 20N, 105 54 00E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('437', 'Hồng Lĩnh', 'Thị Xã', '18 32 05N, 105 42 40E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('439', 'Hương Sơn', 'Huyện', '18 26 47N, 105 19 36E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('440', 'Đức Thọ', 'Huyện', '18 29 23N, 105 36 39E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('441', 'Vũ Quang', 'Huyện', '18 19 30N, 105 26 38E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('442', 'Nghi Xuân', 'Huyện', '18 38 46N, 105 46 17E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('443', 'Can Lộc', 'Huyện', '18 26 39N, 105 46 13E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('444', 'Hương Khê', 'Huyện', '18 11 36N, 105 41 24E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('445', 'Thạch Hà', 'Huyện', '18 19 29N, 105 52 43E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('446', 'Cẩm Xuyên', 'Huyện', '18 11 32N, 106 00 04E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('447', 'Kỳ Anh', 'Huyện', '18 05 15N, 106 15 49E', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('448', 'Lộc Hà', 'Huyện', '', '42');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('450', 'Đồng Hới', 'Thành Phố', '17 26 53N, 106 35 15E', '44');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('452', 'Minh Hóa', 'Huyện', '17 44 03N, 105 51 45E', '44');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('453', 'Tuyên Hóa', 'Huyện', '17 54 04N, 105 58 17E', '44');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('454', 'Quảng Trạch', 'Huyện', '17 50 04N, 106 22 24E', '44');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('455', 'Bố Trạch', 'Huyện', '17 29 13N, 106 06 54E', '44');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('456', 'Quảng Ninh', 'Huyện', '17 15 15N, 106 32 31E', '44');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('457', 'Lệ Thủy', 'Huyện', '17 07 35N, 106 41 47E', '44');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('461', 'Đông Hà', 'Thành Phố', '16 48 12N, 107 05 12E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('462', 'Quảng Trị', 'Thị Xã', '16 44 37N, 107 11 20E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('464', 'Vĩnh Linh', 'Huyện', '17 01 35N, 106 53 49E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('465', 'Hướng Hóa', 'Huyện', '16 42 19N, 106 40 14E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('466', 'Gio Linh', 'Huyện', '16 54 49N, 106 56 16E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('467', 'Đa Krông', 'Huyện', '16 33 58N, 106 55 49E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('468', 'Cam Lộ', 'Huyện', '16 47 09N, 106 57 52E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('469', 'Triệu Phong', 'Huyện', '16 46 32N, 107 09 12E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('470', 'Hải Lăng', 'Huyện', '16 41 07N, 107 13 34E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('471', 'Cồn Cỏ', 'Huyện', '19 09 39N, 107 19 58E', '45');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('474', 'Huế', 'Thành Phố', '16 27 16N, 107 34 29E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('476', 'Phong Điền', 'Huyện', '16 32 42N, 106 16 37E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('477', 'Quảng Điền', 'Huyện', '16 35 21N, 107 29 31E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('478', 'Phú Vang', 'Huyện', '16 27 20N, 107 42 28E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('479', 'Hương Thủy', 'Huyện', '16 19 27N, 107 37 26E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('480', 'Hương Trà', 'Huyện', '16 25 49N, 107 28 37E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('481', 'A Lưới', 'Huyện', '16 13 59N, 107 16 12E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('482', 'Phú Lộc', 'Huyện', '16 17 16N, 107 55 25E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('483', 'Nam Đông', 'Huyện', '16 07 11N, 107 41 25E', '46');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('490', 'Liên Chiểu', 'Quận', '16 07 26N, 108 07 04E', '48');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('491', 'Thanh Khê', 'Quận', '16 03 28N, 108 11 00E', '48');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('492', 'Hải Châu', 'Quận', '16 03 38N, 108 11 46E', '48');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('493', 'Sơn Trà', 'Quận', '16 06 13N, 108 16 26E', '48');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('494', 'Ngũ Hành Sơn', 'Quận', '16 00 30N, 108 15 09E', '48');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('495', 'Cẩm Lệ', 'Quận', '', '48');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('497', 'Hoà Vang', 'Huyện', '16 03 59N, 108 01 57E', '48');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('498', 'Hoàng Sa', 'Huyện', '16 21 36N, 111 57 01E', '48');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('502', 'Tam Kỳ', 'Thành Phố', '15 34 37N, 108 29 52E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('503', 'Hội An', 'Thành Phố', '15 53 20N, 108 20 42E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('504', 'Tây Giang', 'Huyện', '15 53 46N, 107 25 52E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('505', 'Đông Giang', 'Huyện', '15 54 44N, 107 47 06E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('506', 'Đại Lộc', 'Huyện', '15 50 10N, 107 58 27E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('507', 'Điện Bàn', 'Huyện', '15 54 15N, 108 13 38E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('508', 'Duy Xuyên', 'Huyện', '15 47 58N, 108 13 27E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('509', 'Quế Sơn', 'Huyện', '15 41 03N, 108 05 34E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('510', 'Nam Giang', 'Huyện', '15 36 37N, 107 33 52E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('511', 'Phước Sơn', 'Huyện', '15 23 17N, 107 50 22E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('512', 'Hiệp Đức', 'Huyện', '15 31 09N, 108 05 56E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('513', 'Thăng Bình', 'Huyện', '15 42 29N, 108 22 04E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('514', 'Tiên Phước', 'Huyện', '15 29 30N, 108 15 28E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('515', 'Bắc Trà My', 'Huyện', '15 08 00N, 108 05 32E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('516', 'Nam Trà My', 'Huyện', '15 16 40N, 108 12 15E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('517', 'Núi Thành', 'Huyện', '15 26 53N, 108 34 49E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('518', 'Phú Ninh', 'Huyện', '15 30 43N, 108 24 43E', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('519', 'Nông Sơn', 'Huyện', '', '49');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('522', 'Quảng Ngãi', 'Thành Phố', '15 07 17N, 108 48 24E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('524', 'Bình Sơn', 'Huyện', '15 18 45N, 108 45 35E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('525', 'Trà Bồng', 'Huyện', '15 13 30N, 108 29 57E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('526', 'Tây Trà', 'Huyện', '15 11 13N, 108 22 23E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('527', 'Sơn Tịnh', 'Huyện', '15 11 49N, 108 45 03E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('528', 'Tư Nghĩa', 'Huyện', '15 05 25N, 108 45 23E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('529', 'Sơn Hà', 'Huyện', '14 58 35N, 108 29 09E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('530', 'Sơn Tây', 'Huyện', '14 58 11N, 108 21 22E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('531', 'Minh Long', 'Huyện', '14 56 49N, 108 40 19E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('532', 'Nghĩa Hành', 'Huyện', '14 58 06N, 108 46 05E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('533', 'Mộ Đức', 'Huyện', '11 59 13N, 108 52 21E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('534', 'Đức Phổ', 'Huyện', '14 44 59N, 108 56 58E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('535', 'Ba Tơ', 'Huyện', '14 42 52N, 108 43 44E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('536', 'Lý Sơn', 'Huyện', '15 22 50N, 109 06 56E', '51');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('540', 'Qui Nhơn', 'Thành Phố', '13 47 15N, 109 12 48E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('542', 'An Lão', 'Huyện', '14 32 10N, 108 47 52E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('543', 'Hoài Nhơn', 'Huyện', '14 30 56N, 109 01 56E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('544', 'Hoài Ân', 'Huyện', '14 20 51N, 108 54 04E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('545', 'Phù Mỹ', 'Huyện', '14 14 41N, 109 05 43E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('546', 'Vĩnh Thạnh', 'Huyện', '14 14 26N, 108 44 08E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('547', 'Tây Sơn', 'Huyện', '13 56 47N, 108 53 06E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('548', 'Phù Cát', 'Huyện', '14 03 48N, 109 03 57E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('549', 'An Nhơn', 'Huyện', '13 51 28N, 109 04 02E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('550', 'Tuy Phước', 'Huyện', '13 46 30N, 109 05 38E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('551', 'Vân Canh', 'Huyện', '13 40 35N, 108 57 52E', '52');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('555', 'Tuy Hòa', 'Thành Phố', '13 05 42N, 109 15 50E', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('557', 'Sông Cầu', 'Thị Xã', '13 31 40N, 109 12 39E', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('558', 'Đồng Xuân', 'Huyện', '13 24 59N, 108 56 46E', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('559', 'Tuy An', 'Huyện', '13 15 19N, 109 12 21E', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('560', 'Sơn Hòa', 'Huyện', '13 12 16N, 108 57 17E', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('561', 'Sông Hinh', 'Huyện', '12 54 19N, 108 53 38E', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('562', 'Tây Hoà', 'Huyện', '', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('563', 'Phú Hoà', 'Huyện', '13 04 07N, 109 11 24E', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('564', 'Đông Hoà', 'Huyện', '', '54');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('568', 'Nha Trang', 'Thành Phố', '12 15 40N, 109 10 40E', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('569', 'Cam Ranh', 'Thị Xã', '11 59 05N, 108 08 17E', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('570', 'Cam Lâm', 'Huyện', '', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('571', 'Vạn Ninh', 'Huyện', '12 43 10N, 109 11 18E', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('572', 'Ninh Hòa', 'Huyện', '12 32 54N, 109 06 11E', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('573', 'Khánh Vĩnh', 'Huyện', '12 17 50N, 108 51 56E', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('574', 'Diên Khánh', 'Huyện', '12 13 19N, 109 02 16E', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('575', 'Khánh Sơn', 'Huyện', '12 02 17N, 108 53 47E', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('576', 'Trường Sa', 'Huyện', '9 07 27N, 114 15 00E', '56');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('582', 'Phan Rang-Tháp Chàm', 'Thành Phố', '11 36 11N, 108 58 34E', '58');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('584', 'Bác Ái', 'Huyện', '11 54 45N, 108 51 29E', '58');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('585', 'Ninh Sơn', 'Huyện', '11 42 36N, 108 44 55E', '58');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('586', 'Ninh Hải', 'Huyện', '11 42 46N, 109 05 41E', '58');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('587', 'Ninh Phước', 'Huyện', '11 28 56N, 108 50 34E', '58');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('588', 'Thuận Bắc', 'Huyện', '', '58');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('589', 'Thuận Nam', 'Huyện', '', '58');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('593', 'Phan Thiết', 'Thành Phố', '10 54 16N, 108 03 44E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('594', 'La Gi', 'Thị Xã', '', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('595', 'Tuy Phong', 'Huyện', '11 20 26N, 108 41 15E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('596', 'Bắc Bình', 'Huyện', '11 15 52N, 108 21 33E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('597', 'Hàm Thuận Bắc', 'Huyện', '11 09 18N, 108 03 07E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('598', 'Hàm Thuận Nam', 'Huyện', '10 56 20N, 107 54 38E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('599', 'Tánh Linh', 'Huyện', '11 08 26N, 107 41 22E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('600', 'Đức Linh', 'Huyện', '11 11 43N, 107 31 34E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('601', 'Hàm Tân', 'Huyện', '10 44 41N, 107 41 33E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('602', 'Phú Quí', 'Huyện', '10 33 13N, 108 57 46E', '60');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('608', 'Kon Tum', 'Thành Phố', '14 20 32N, 107 58 04E', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('610', 'Đắk Glei', 'Huyện', '15 08 13N, 107 44 03E', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('611', 'Ngọc Hồi', 'Huyện', '14 44 23N, 107 38 49E', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('612', 'Đắk Tô', 'Huyện', '14 46 49N, 107 55 36E', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('613', 'Kon Plông', 'Huyện', '14 48 13N, 108 20 05E', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('614', 'Kon Rẫy', 'Huyện', '14 32 56N, 108 13 09E', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('615', 'Đắk Hà', 'Huyện', '14 36 50N, 107 59 55E', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('616', 'Sa Thầy', 'Huyện', '14 16 02N, 107 36 30E', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('617', 'Tu Mơ Rông', 'Huyện', '', '62');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('622', 'Pleiku', 'Thành Phố', '13 57 42N, 107 58 03E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('623', 'An Khê', 'Thị Xã', '14 01 24N, 108 41 29E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('624', 'Ayun Pa', 'Thị Xã', '', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('625', 'Kbang', 'Huyện', '14 18 08N, 108 29 17E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('626', 'Đăk Đoa', 'Huyện', '14 07 02N, 108 09 36E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('627', 'Chư Păh', 'Huyện', '14 13 30N, 107 56 33E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('628', 'Ia Grai', 'Huyện', '13 59 25N, 107 43 16E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('629', 'Mang Yang', 'Huyện', '13 57 26N, 108 18 37E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('630', 'Kông Chro', 'Huyện', '13 45 47N, 108 36 04E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('631', 'Đức Cơ', 'Huyện', '13 46 16N, 107 38 26E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('632', 'Chư Prông', 'Huyện', '13 35 39N, 107 47 36E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('633', 'Chư Sê', 'Huyện', '13 37 04N, 108 06 56E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('634', 'Đăk Pơ', 'Huyện', '13 55 47N, 108 36 16E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('635', 'Ia Pa', 'Huyện', '13 31 37N, 108 30 34E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('637', 'Krông Pa', 'Huyện', '13 14 13N, 108 39 12E', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('638', 'Phú Thiện', 'Huyện', '', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('639', 'Chư Pưh', 'Huyện', '', '64');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('643', 'Buôn Ma Thuột', 'Thành Phố', '12 39 43N, 108 10 40E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('644', 'Buôn Hồ', 'Thị Xã', '', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('645', 'Ea H\'leo', 'Huyện', '13 13 52N, 108 12 30E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('646', 'Ea Súp', 'Huyện', '13 10 59N, 107 46 49E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('647', 'Buôn Đôn', 'Huyện', '12 52 45N, 107 45 20E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('648', 'Cư M\'gar', 'Huyện', '12 53 47N, 108 04 16E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('649', 'Krông Búk', 'Huyện', '12 56 27N, 108 13 54E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('650', 'Krông Năng', 'Huyện', '12 59 41N, 108 23 42E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('651', 'Ea Kar', 'Huyện', '12 48 17N, 108 32 42E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('652', 'M\'đrắk', 'Huyện', '12 42 14N, 108 47 09E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('653', 'Krông Bông', 'Huyện', '12 27 08N, 108 27 01E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('654', 'Krông Pắc', 'Huyện', '12 41 20N, 108 18 42E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('655', 'Krông A Na', 'Huyện', '12 31 51N, 108 05 03E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('656', 'Lắk', 'Huyện', '12 19 20N, 108 12 17E', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('657', 'Cư Kuin', 'Huyện', '', '66');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('660', 'Gia Nghĩa', 'Thị Xã', '', '67');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('661', 'Đắk Glong', 'Huyện', '12 01 53N, 107 50 37E', '67');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('662', 'Cư Jút', 'Huyện', '12 40 56N, 107 44 44E', '67');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('663', 'Đắk Mil', 'Huyện', '12 31 08N, 107 42 24E', '67');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('664', 'Krông Nô', 'Huyện', '12 22 16N, 107 53 49E', '67');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('665', 'Đắk Song', 'Huyện', '12 14 04N, 107 36 30E', '67');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('666', 'Đắk R\'lấp', 'Huyện', '12 02 30N, 107 25 59E', '67');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('667', 'Tuy Đức', 'Huyện', '', '67');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('672', 'Đà Lạt', 'Thành Phố', '11 54 33N, 108 27 08E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('673', 'Bảo Lộc', 'Thị Xã', '11 32 48N, 107 47 37E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('674', 'Đam Rông', 'Huyện', '12 02 35N, 108 10 26E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('675', 'Lạc Dương', 'Huyện', '12 08 30N, 108 27 48E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('676', 'Lâm Hà', 'Huyện', '11 55 26N, 108 11 31E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('677', 'Đơn Dương', 'Huyện', '11 48 26N, 108 32 48E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('678', 'Đức Trọng', 'Huyện', '11 41 50N, 108 18 58E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('679', 'Di Linh', 'Huyện', '11 31 10N, 108 05 23E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('680', 'Bảo Lâm', 'Huyện', '11 38 31N, 107 43 25E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('681', 'Đạ Huoai', 'Huyện', '11 27 11N, 107 38 08E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('682', 'Đạ Tẻh', 'Huyện', '11 33 46N, 107 32 00E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('683', 'Cát Tiên', 'Huyện', '11 39 38N, 107 23 27E', '68');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('688', 'Phước Long', 'Thị Xã', '', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('689', 'Đồng Xoài', 'Thị Xã', '11 31 01N, 106 50 21E', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('690', 'Bình Long', 'Thị Xã', '', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('691', 'Bù Gia Mập', 'Huyện', '11 56 57N, 106 59 21E', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('692', 'Lộc Ninh', 'Huyện', '11 49 28N, 106 35 11E', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('693', 'Bù Đốp', 'Huyện', '11 59 08N, 106 49 54E', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('694', 'Hớn Quản', 'Huyện', '11 37 37N, 106 36 02E', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('695', 'Đồng Phù', 'Huyện', '11 28 45N, 106 57 07E', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('696', 'Bù Đăng', 'Huyện', '11 46 09N, 107 14 14E', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('697', 'Chơn Thành', 'Huyện', '11 28 45N, 106 39 26E', '70');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('703', 'Tây Ninh', 'Thị Xã', '11 21 59N, 106 07 47E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('705', 'Tân Biên', 'Huyện', '11 35 14N, 105 57 53E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('706', 'Tân Châu', 'Huyện', '11 34 49N, 106 17 48E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('707', 'Dương Minh Châu', 'Huyện', '11 22 04N, 106 16 58E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('708', 'Châu Thành', 'Huyện', '11 19 02N, 106 00 15E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('709', 'Hòa Thành', 'Huyện', '11 15 31N, 106 08 44E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('710', 'Gò Dầu', 'Huyện', '11 09 39N, 106 14 42E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('711', 'Bến Cầu', 'Huyện', '11 07 50N, 106 08 25E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('712', 'Trảng Bàng', 'Huyện', '11 06 18N, 106 23 12E', '72');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('718', 'Thủ Dầu Một', 'Thị Xã', '11 00 01N, 106 38 56E', '74');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('720', 'Dầu Tiếng', 'Huyện', '11 19 07N, 106 26 59E', '74');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('721', 'Bến Cát', 'Huyện', '11 12 42N, 106 36 28E', '74');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('722', 'Phú Giáo', 'Huyện', '11 20 21N, 106 47 48E', '74');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('723', 'Tân Uyên', 'Huyện', '11 06 31N, 106 49 02E', '74');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('724', 'Dĩ An', 'Huyện', '10 55 03N, 106 47 09E', '74');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('725', 'Thuận An', 'Huyện', '10 55 58N, 106 41 59E', '74');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('731', 'Biên Hòa', 'Thành Phố', '10 56 31N, 106 50 50E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('732', 'Long Khánh', 'Thị Xã', '10 56 24N, 107 14 29E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('734', 'Tân Phú', 'Huyện', '11 22 51N, 107 21 35E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('735', 'Vĩnh Cửu', 'Huyện', '11 14 31N, 107 00 06E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('736', 'Định Quán', 'Huyện', '11 12 41N, 107 17 03E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('737', 'Trảng Bom', 'Huyện', '10 58 39N, 107 00 52E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('738', 'Thống Nhất', 'Huyện', '10 58 29N, 107 09 26E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('739', 'Cẩm Mỹ', 'Huyện', '10 47 05N, 107 14 36E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('740', 'Long Thành', 'Huyện', '10 47 38N, 106 59 42E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('741', 'Xuân Lộc', 'Huyện', '10 55 39N, 107 24 21E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('742', 'Nhơn Trạch', 'Huyện', '10 39 18N, 106 53 18E', '75');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('747', 'Vũng Tầu', 'Thành Phố', '10 24 08N, 107 07 05E', '77');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('748', 'Bà Rịa', 'Thị Xã', '10 30 33N, 107 10 47E', '77');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('750', 'Châu Đức', 'Huyện', '10 39 23N, 107 15 08E', '77');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('751', 'Xuyên Mộc', 'Huyện', '10 37 46N, 107 29 39E', '77');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('752', 'Long Điền', 'Huyện', '10 26 47N, 107 12 53E', '77');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('753', 'Đất Đỏ', 'Huyện', '10 28 40N, 107 18 27E', '77');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('754', 'Tân Thành', 'Huyện', '10 34 50N, 107 05 06E', '77');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('755', 'Côn Đảo', 'Huyện', '8 42 25N, 106 36 05E', '77');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('760', '1', 'Quận', '10 46 34N, 106 41 45E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('761', '12', 'Quận', '10 51 43N, 106 39 32E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('762', 'Thủ Đức', 'Quận', '10 51 20N, 106 45 05E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('763', '9', 'Quận', '10 49 49N, 106 49 03E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('764', 'Gò Vấp', 'Quận', '10 50 12N, 106 39 52E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('765', 'Bình Thạnh', 'Quận', '10 48 46N, 106 42 57E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('766', 'Tân Bình', 'Quận', '10 48 13N, 106 39 03E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('767', 'Tân Phú', 'Quận', '10 47 32N, 106 37 31E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('768', 'Phú Nhuận', 'Quận', '10 48 06N, 106 40 39E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('769', '2', 'Quận', '10 46 51N, 106 45 25E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('770', '3', 'Quận', '10 46 48N, 106 40 46E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('771', '10', 'Quận', '10 46 25N, 106 40 02E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('772', '11', 'Quận', '10 46 01N, 106 38 44E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('773', '4', 'Quận', '10 45 42N, 106 42 09E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('774', '5', 'Quận', '10 45 24N, 106 40 00E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('775', '6', 'Quận', '10 44 46N, 106 38 10E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('776', '8', 'Quận', '10 43 24N, 106 37 40E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('777', 'Bình Tân', 'Quận', '10 46 16N, 106 35 26E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('778', '7', 'Quận', '10 44 19N, 106 43 35E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('783', 'Củ Chi', 'Huyện', '11 02 17N, 106 30 20E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('784', 'Hóc Môn', 'Huyện', '10 52 42N, 106 35 33E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('785', 'Bình Chánh', 'Huyện', '10 45 01N, 106 30 45E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('786', 'Nhà Bè', 'Huyện', '10 39 06N, 106 43 35E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('787', 'Cần Giờ', 'Huyện', '10 30 43N, 106 52 50E', '79');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('794', 'Tân An', 'Thành Phố', '10 31 36N, 106 24 06E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('796', 'Tân Hưng', 'Huyện', '10 49 05N, 105 39 26E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('797', 'Vĩnh Hưng', 'Huyện', '10 52 54N, 105 45 58E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('798', 'Mộc Hóa', 'Huyện', '10 47 09N, 105 57 56E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('799', 'Tân Thạnh', 'Huyện', '10 37 44N, 105 57 07E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('800', 'Thạnh Hóa', 'Huyện', '10 41 37N, 106 11 08E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('801', 'Đức Huệ', 'Huyện', '10 51 57N, 106 15 48E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('802', 'Đức Hòa', 'Huyện', '10 53 04N, 106 23 58E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('803', 'Bến Lức', 'Huyện', '10 41 40N, 106 26 28E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('804', 'Thủ Thừa', 'Huyện', '10 39 41N, 106 20 12E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('805', 'Tân Trụ', 'Huyện', '10 31 47N, 106 30 06E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('806', 'Cần Đước', 'Huyện', '10 32 21N, 106 36 33E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('807', 'Cần Giuộc', 'Huyện', '10 34 43N, 106 38 35E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('808', 'Châu Thành', 'Huyện', '10 27 52N, 106 30 00E', '80');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('815', 'Mỹ Tho', 'Thành Phố', '10 22 14N, 106 21 52E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('816', 'Gò Công', 'Thị Xã', '10 21 55N, 106 40 24E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('818', 'Tân Phước', 'Huyện', '10 30 36N, 106 13 02E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('819', 'Cái Bè', 'Huyện', '10 24 21N, 105 56 01E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('820', 'Cai Lậy', 'Huyện', '10 24 20N, 106 06 05E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('821', 'Châu Thành', 'Huyện', '20 25 21N, 106 16 57E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('822', 'Chợ Gạo', 'Huyện', '10 23 45N, 106 26 53E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('823', 'Gò Công Tây', 'Huyện', '10 19 55N, 106 35 02E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('824', 'Gò Công Đông', 'Huyện', '10 20 42N, 106 42 54E', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('825', 'Tân Phú Đông', 'Huyện', '', '82');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('829', 'Bến Tre', 'Thành Phố', '10 14 17N, 106 22 26E', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('831', 'Châu Thành', 'Huyện', '10 17 24N, 106 17 45E', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('832', 'Chợ Lách', 'Huyện', '10 13 26N, 106 09 08E', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('833', 'Mỏ Cày Nam', 'Huyện', '10 06 56N, 106 19 40E', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('834', 'Giồng Trôm', 'Huyện', '10 08 46N, 106 28 12E', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('835', 'Bình Đại', 'Huyện', '10 09 56N, 106 37 46E', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('836', 'Ba Tri', 'Huyện', '10 04 08N, 106 35 10E', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('837', 'Thạnh Phú', 'Huyện', '9 55 53N, 106 32 45E', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('838', 'Mỏ Cày Bắc', 'Huyện', '', '83');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('842', 'Trà Vinh', 'Thị Xã', '9 57 09N, 106 20 39E', '84');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('844', 'Càng Long', 'Huyện', '9 58 18N, 106 12 52E', '84');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('845', 'Cầu Kè', 'Huyện', '9 51 23N, 106 03 33E', '84');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('846', 'Tiểu Cần', 'Huyện', '9 48 37N, 106 12 06E', '84');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('847', 'Châu Thành', 'Huyện', '9 52 57N, 106 24 12E', '84');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('848', 'Cầu Ngang', 'Huyện', '9 47 14N, 106 29 19E', '84');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('849', 'Trà Cú', 'Huyện', '9 42 06N, 106 16 24E', '84');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('850', 'Duyên Hải', 'Huyện', '9 39 58N, 106 26 23E', '84');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('855', 'Vĩnh Long', 'Thành Phố', '10 15 09N, 105 56 08E', '86');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('857', 'Long Hồ', 'Huyện', '10 13 58N, 105 55 47E', '86');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('858', 'Mang Thít', 'Huyện', '10 10 58N, 106 05 13E', '86');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('859', 'Vũng Liêm', 'Huyện', '10 03 32N, 106 10 35E', '86');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('860', 'Tam Bình', 'Huyện', '10 03 58N, 105 58 03E', '86');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('861', 'Bình Minh', 'Huyện', '10 05 45N, 105 47 21E', '86');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('862', 'Trà Ôn', 'Huyện', '9 59 20N, 105 57 56E', '86');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('863', 'Bình Tân', 'Huyện', '', '86');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('866', 'Cao Lãnh', 'Thành Phố', '10 27 38N, 105 37 21E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('867', 'Sa Đéc', 'Thị Xã', '10 19 22N, 105 44 31E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('868', 'Hồng Ngự', 'Thị Xã', '', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('869', 'Tân Hồng', 'Huyện', '10 52 48N, 105 29 21E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('870', 'Hồng Ngự', 'Huyện', '10 48 13N, 105 19 00E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('871', 'Tam Nông', 'Huyện', '10 44 06N, 105 30 58E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('872', 'Tháp Mười', 'Huyện', '10 33 36N, 105 47 13E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('873', 'Cao Lãnh', 'Huyện', '10 29 03N, 105 41 40E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('874', 'Thanh Bình', 'Huyện', '10 36 38N, 105 28 51E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('875', 'Lấp Vò', 'Huyện', '10 21 27N, 105 36 06E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('876', 'Lai Vung', 'Huyện', '10 14 43N, 105 38 40E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('877', 'Châu Thành', 'Huyện', '10 13 27N, 105 48 38E', '87');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('883', 'Long Xuyên', 'Thành Phố', '10 22 22N, 105 25 33E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('884', 'Châu Đốc', 'Thị Xã', '10 41 20N, 105 05 15E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('886', 'An Phú', 'Huyện', '10 50 12N, 105 05 33E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('887', 'Tân Châu', 'Thị Xã', '10 49 11N, 105 11 18E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('888', 'Phú Tân', 'Huyện', '10 40 26N, 105 14 40E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('889', 'Châu Phú', 'Huyện', '10 34 12N, 105 12 13E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('890', 'Tịnh Biên', 'Huyện', '10 33 30N, 105 00 17E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('891', 'Tri Tôn', 'Huyện', '10 24 41N, 104 56 58E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('892', 'Châu Thành', 'Huyện', '10 25 39N, 105 15 31E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('893', 'Chợ Mới', 'Huyện', '10 27 23N, 105 26 57E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('894', 'Thoại Sơn', 'Huyện', '10 16 45N, 105 15 59E', '89');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('899', 'Rạch Giá', 'Thành Phố', '10 01 35N, 105 06 20E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('900', 'Hà Tiên', 'Thị Xã', '10 22 54N, 104 30 10E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('902', 'Kiên Lương', 'Huyện', '10 20 21N, 104 39 46E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('903', 'Hòn Đất', 'Huyện', '10 14 20N, 104 55 57E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('904', 'Tân Hiệp', 'Huyện', '10 05 18N, 105 14 04E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('905', 'Châu Thành', 'Huyện', '9 57 37N, 105 10 16E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('906', 'Giồng Giềng', 'Huyện', '9 56 05N, 105 22 06E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('907', 'Gò Quao', 'Huyện', '9 43 17N, 105 17 06E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('908', 'An Biên', 'Huyện', '9 48 37N, 105 03 18E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('909', 'An Minh', 'Huyện', '9 40 24N, 104 59 05E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('910', 'Vĩnh Thuận', 'Huyện', '9 33 25N, 105 11 30E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('911', 'Phú Quốc', 'Huyện', '10 13 44N, 103 57 25E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('912', 'Kiên Hải', 'Huyện', '9 48 31N, 104 37 48E', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('913', 'U Minh Thượng', 'Huyện', '', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('914', 'Giang Thành', 'Huyện', '', '91');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('916', 'Ninh Kiều', 'Quận', '10 01 58N, 105 45 34E', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('917', 'Ô Môn', 'Quận', '10 07 28N, 105 37 51E', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('918', 'Bình Thuỷ', 'Quận', '10 03 42N, 105 43 17E', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('919', 'Cái Răng', 'Quận', '9 59 57N, 105 46 56E', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('923', 'Thốt Nốt', 'Quận', '10 14 23N, 105 32 02E', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('924', 'Vĩnh Thạnh', 'Huyện', '10 11 35N, 105 22 45E', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('925', 'Cờ Đỏ', 'Huyện', '10 02 48N, 105 29 46E', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('926', 'Phong Điền', 'Huyện', '9 59 57N, 105 39 35E', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('927', 'Thới Lai', 'Huyện', '', '92');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('930', 'Vị Thanh', 'Thị Xã', '9 45 15N, 105 24 50E', '93');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('931', 'Ngã Bảy', 'Thị Xã', '', '93');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('932', 'Châu Thành A', 'Huyện', '9 55 50N, 105 38 31E', '93');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('933', 'Châu Thành', 'Huyện', '9 55 22N, 105 48 37E', '93');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('934', 'Phụng Hiệp', 'Huyện', '9 47 20N, 105 43 29E', '93');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('935', 'Vị Thuỷ', 'Huyện', '9 48 05N, 105 32 13E', '93');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('936', 'Long Mỹ', 'Huyện', '9 40 47N, 105 30 53E', '93');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('941', 'Sóc Trăng', 'Thành Phố', '9 36 39N, 105 59 00E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('942', 'Châu Thành', 'Huyện', '', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('943', 'Kế Sách', 'Huyện', '9 49 30N, 105 57 25E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('944', 'Mỹ Tú', 'Huyện', '9 38 21N, 105 49 52E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('945', 'Cù Lao Dung', 'Huyện', '9 37 36N, 106 12 13E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('946', 'Long Phú', 'Huyện', '9 34 38N, 106 06 07E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('947', 'Mỹ Xuyên', 'Huyện', '9 28 16N, 105 55 51E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('948', 'Ngã Năm', 'Huyện', '9 31 38N, 105 37 22E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('949', 'Thạnh Trị', 'Huyện', '9 28 05N, 105 43 02E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('950', 'Vĩnh Châu', 'Huyện', '9 20 50N, 105 59 58E', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('951', 'Trần Đề', 'Huyện', '', '94');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('954', 'Bạc Liêu', 'Thị Xã', '9 16 05N, 105 45 08E', '95');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('956', 'Hồng Dân', 'Huyện', '9 30 37N, 105 24 25E', '95');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('957', 'Phước Long', 'Huyện', '9 23 13N, 105 24 41E', '95');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('958', 'Vĩnh Lợi', 'Huyện', '9 16 51N, 105 40 54E', '95');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('959', 'Giá Rai', 'Huyện', '9 15 51N, 105 23 18E', '95');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('960', 'Đông Hải', 'Huyện', '9 08 11N, 105 24 42E', '95');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('961', 'Hoà Bình', 'Huyện', '', '95');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('964', 'Cà Mau', 'Thành Phố', '9 10 33N, 105 11 11E', '96');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('966', 'U Minh', 'Huyện', '9 22 30N, 104 57 00E', '96');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('967', 'Thới Bình', 'Huyện', '9 22 50N, 105 07 35E', '96');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('968', 'Trần Văn Thời', 'Huyện', '9 07 36N, 104 57 27E', '96');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('969', 'Cái Nước', 'Huyện', '9 00 31N, 105 03 23E', '96');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('970', 'Đầm Dơi', 'Huyện', '8 57 48N, 105 13 56E', '96');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('971', 'Năm Căn', 'Huyện', '8 46 59N, 104 58 20E', '96');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('972', 'Phú Tân', 'Huyện', '8 52 47N, 104 53 35E', '96');
INSERT INTO `district` (`districtid`, `name`, `type`, `location`, `provinceid`) VALUES ('973', 'Ngọc Hiển', 'Huyện', '8 40 47N, 104 57 58E', '96');


#
# TABLE STRUCTURE FOR: landtype
#

DROP TABLE IF EXISTS `landtype`;

CREATE TABLE `landtype` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `parentid` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('1', '0', 'Bán căn hộ chung cư');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('2', '0', 'Tất cả các loại nhà bán');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('3', '0', 'Tất cả các loại đất bán');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('4', '0', 'Bán trang trại, khu nghỉ dưỡng');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('5', '0', 'Bán kho, nhà xưởng');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('6', '0', 'Bán loại bất động sản khác');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('7', '2', 'Bán nhà riêng');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('8', '2', 'Bán nhà biệt thự, liền kề');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('9', '2', 'Bán nhà mặt phố');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('10', '3', 'Bán đất nền dự án');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('11', '3', 'Bán đất');
INSERT INTO `landtype` (`id`, `parentid`, `name`) VALUES ('12', '1', 'Can ho trung cu 1');


#
# TABLE STRUCTURE FOR: province
#

DROP TABLE IF EXISTS `province`;

CREATE TABLE `province` (
  `provinceid` varchar(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  PRIMARY KEY (`provinceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('01', 'Hà Nội', 'Thành Phố');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('02', 'Hà Giang', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('04', 'Cao Bằng', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('06', 'Bắc Kạn', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('08', 'Tuyên Quang', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('10', 'Lào Cai', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('11', 'Điện Biên', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('12', 'Lai Châu', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('14', 'Sơn La', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('15', 'Yên Bái', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('17', 'Hòa Bình', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('19', 'Thái Nguyên', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('20', 'Lạng Sơn', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('22', 'Quảng Ninh', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('24', 'Bắc Giang', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('25', 'Phú Thọ', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('26', 'Vĩnh Phúc', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('27', 'Bắc Ninh', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('30', 'Hải Dương', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('31', 'Hải Phòng', 'Thành Phố');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('33', 'Hưng Yên', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('34', 'Thái Bình', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('35', 'Hà Nam', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('36', 'Nam Định', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('37', 'Ninh Bình', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('38', 'Thanh Hóa', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('40', 'Nghệ An', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('42', 'Hà Tĩnh', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('44', 'Quảng Bình', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('45', 'Quảng Trị', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('46', 'Thừa Thiên Huế', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('48', 'Đà Nẵng', 'Thành Phố');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('49', 'Quảng Nam', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('51', 'Quảng Ngãi', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('52', 'Bình Định', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('54', 'Phú Yên', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('56', 'Khánh Hòa', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('58', 'Ninh Thuận', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('60', 'Bình Thuận', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('62', 'Kon Tum', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('64', 'Gia Lai', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('66', 'Đắk Lắk', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('67', 'Đắk Nông', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('68', 'Lâm Đồng', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('70', 'Bình Phước', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('72', 'Tây Ninh', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('74', 'Bình Dương', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('75', 'Đồng Nai', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('77', 'Bà Rịa - Vũng Tàu', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('79', 'Hồ Chí Minh', 'Thành Phố');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('80', 'Long An', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('82', 'Tiền Giang', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('83', 'Bến Tre', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('84', 'Trà Vinh', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('86', 'Vĩnh Long', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('87', 'Đồng Tháp', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('89', 'An Giang', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('91', 'Kiên Giang', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('92', 'Cần Thơ', 'Thành Phố');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('93', 'Hậu Giang', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('94', 'Sóc Trăng', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('95', 'Bạc Liêu', 'Tỉnh');
INSERT INTO `province` (`provinceid`, `name`, `type`) VALUES ('96', 'Cà Mau', 'Tỉnh');


#
# TABLE STRUCTURE FOR: tblactivitylog
#

DROP TABLE IF EXISTS `tblactivitylog`;

CREATE TABLE `tblactivitylog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=MyISAM AUTO_INCREMENT=219 DEFAULT CHARSET=utf8;

INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('1', 'Failed Login Attempt [Email:admin@admin.com, Is Staff Member:Yes, IP:::1]', '2017-03-30 14:25:38', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('2', 'Failed Login Attempt [Email:admin@admin.com, Is Staff Member:Yes, IP:::1]', '2017-03-30 14:25:45', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('3', 'Failed Login Attempt [Email:admin@admin.com, Is Staff Member:Yes, IP:::1]', '2017-03-30 14:26:21', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('4', 'New Client Created [FOSO From Staff: 1]', '2017-03-30 14:30:34', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('5', 'Failed Login Attempt [Email:client@test.com, Is Staff Member:No, IP:::1]', '2017-03-30 14:32:52', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('6', 'Contact Created [Khách hàng 1]', '2017-03-30 20:53:19', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('7', 'New Client Created [Viettel From Staff: 1]', '2017-03-30 20:53:19', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('8', 'Contact Created [FO SO]', '2017-03-30 20:57:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('9', 'New Contract Added [Báo cáo thuế]', '2017-03-31 00:14:42', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('10', 'Failed Login Attempt [Email:khachhang1@gmail.com, Is Staff Member:No, IP:::1]', '2017-03-31 00:25:03', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('11', 'Failed Login Attempt [Email:khachhang1@gmail.com, Is Staff Member:No, IP:::1]', '2017-03-31 00:25:13', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('12', 'New Staff Member Added [ID: 2, Tân Nguyễn]', '2017-03-31 00:37:49', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('13', 'Tried to access page where dont have permission [contracts]', '2017-03-31 00:44:01', 'Tân Nguyễn');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('14', 'Role Updated [ID: 1.Sale]', '2017-03-31 00:46:52', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('15', 'New Role Added [ID: 2.Nghiệp Vụ]', '2017-03-31 00:47:42', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('16', 'New Role Added [ID: 3.Kế toán]', '2017-03-31 00:48:11', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('17', 'New Staff Member Added [ID: 3, Ngọc Hà]', '2017-03-31 00:49:22', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('18', 'Staff Member Updated [ID: 3, Ngọc Hà]', '2017-03-31 00:49:32', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('19', 'New Staff Member Added [ID: 4, Thùy Linh]', '2017-03-31 00:50:39', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('20', 'Tried to access page where dont have permission [settings]', '2017-03-31 00:53:35', 'Thùy Linh');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('21', 'Customer Attachment Deleted [CustomerID: 2]', '2017-03-31 01:42:47', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('22', 'Customer Attachment Deleted [CustomerID: 2]', '2017-03-31 01:43:03', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('23', 'New Task Added [ID:1, Name: Nhiệm vụ 1]', '2017-04-03 12:52:35', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('24', 'New Task Added [ID:2, Name: Chăm sóc khách hàng]', '2017-04-03 12:56:14', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('25', 'New Task Added [ID:3, Name: Chăm sóc khách hàng]', '2017-04-03 12:58:03', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('26', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:05:33', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('27', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:08:00', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('28', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:11:20', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('29', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:14:45', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('30', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:17:53', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('31', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:18:07', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('32', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:18:11', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('33', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:21:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('34', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:21:20', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('35', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:25:18', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('36', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:26:57', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('37', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 11:32:55', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('38', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 2]', '2017-05-04 12:12:48', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('39', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 2]', '2017-05-04 13:45:39', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('40', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 2]', '2017-05-04 13:45:41', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('41', 'New Invoice Item Added [ID:1, nhân viên]', '2017-05-04 13:48:10', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('42', 'Invoice Item Deleted [ID: 1]', '2017-05-04 13:48:14', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('43', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 13:48:40', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('44', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 13:48:42', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('45', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 16:09:21', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('46', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 16:09:24', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('47', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 16:09:27', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('48', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 16:09:29', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('49', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 16:59:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('50', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 16:59:09', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('51', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:02:58', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('52', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:03:00', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('53', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:03:03', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('54', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:03:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('55', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:03:08', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('56', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:07:22', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('57', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:47:30', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('58', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:47:32', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('59', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:47:34', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('60', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:47:37', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('61', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-04 17:47:39', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('62', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-05 08:37:10', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('63', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-05 09:07:25', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('64', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-05 09:07:43', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('65', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-05 09:54:08', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('66', 'Đã Hủy Đính Kèm của Khách Hàng [CustomerID: 1]', '2017-05-05 09:54:11', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('67', 'Items Group Created [Name: Thuy]', '2017-05-05 15:37:46', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('68', 'Items Land Type Updated [Name: Thuy aa]', '2017-05-05 15:38:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('69', 'Items Land Type Created [Name: thuy]', '2017-05-05 15:38:32', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('70', 'Invoice Item Deleted [ID: 15]', '2017-05-05 16:08:41', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('71', 'New Invoice Item Added [ID:17, dsad]', '2017-05-05 16:08:51', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('72', 'Invoice Item Updated [ID: 17, dsad]', '2017-05-05 16:14:03', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('73', 'New Invoice Item Added [ID:18, fgfdg]', '2017-05-05 16:18:31', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('74', 'Invoice Item Updated [ID: 17, dsad]', '2017-05-05 16:38:45', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('75', 'New Invoice Item Added [ID:19, sdsadsa]', '2017-05-05 16:47:20', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('76', 'Invoice Item Updated [ID: 17, dsad]', '2017-05-06 08:26:00', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('77', 'Invoice Item Updated [ID: 19, sdsadsa]', '2017-05-06 08:34:51', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('78', 'Invoice Item Updated [ID: 19, sdsadsa]', '2017-05-06 08:35:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('79', 'Invoice Item Updated [ID: 19, sdsadsa]', '2017-05-06 08:35:24', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('80', 'Invoice Item Updated [ID: 19, sdsadsa]', '2017-05-06 08:37:09', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('81', 'Invoice Item Updated [ID: 19, sdsadsa]', '2017-05-06 08:37:23', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('82', 'Invoice Item Updated [ID: 16, sdvdsf]', '2017-05-06 08:39:52', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('83', 'New Invoice Item Added [ID:20, aaaa]', '2017-05-06 08:46:24', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('84', 'Invoice Item Updated [ID: 19, sdsadsa]', '2017-05-06 09:05:46', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('85', 'Invoice Item Updated [ID: 19, sdsadsa]', '2017-05-06 09:06:12', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('86', 'Invoice Item Updated [ID: 16, sdvdsf]', '2017-05-06 09:11:33', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('87', 'New Invoice Item Added [ID:21, Thuy]', '2017-05-06 09:12:25', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('88', 'New Invoice Item Added [ID:22, Tan]', '2017-05-06 09:14:43', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('89', 'New Invoice Item Added [ID:23, wedwae]', '2017-05-06 09:28:17', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('90', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-06 09:29:48', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('91', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-06 09:30:03', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('92', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-06 09:31:09', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('93', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-06 09:31:17', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('94', 'Invoice Item Deleted [ID: 23]', '2017-05-06 09:36:49', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('95', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-06 09:41:26', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('96', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-08 09:47:21', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('97', 'New Invoice Item Added [ID:24, System Administrator]', '2017-05-08 09:47:49', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('98', 'Invoice Item Updated [ID: 24, System Administrator]', '2017-05-08 10:29:58', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('99', 'Invoice Item Updated [ID: 24, System Administrator]', '2017-05-08 10:30:27', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('100', 'Invoice Item Updated [ID: 24, System Administrator]', '2017-05-08 10:31:03', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('101', 'Invoice Item Deleted [ID: 24]', '2017-05-08 10:31:11', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('102', 'New Invoice Item Added [ID:25, nhân viên]', '2017-05-08 10:31:40', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('103', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-08 10:41:28', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('104', 'Invoice Item Deleted [ID: 25]', '2017-05-08 11:56:24', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('105', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-08 11:56:59', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('106', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-08 14:50:13', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('107', 'Invoice Item Updated [ID: 22, Tan]', '2017-05-08 14:50:57', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('108', 'New Invoice Item Added [ID:26, thuan]', '2017-05-08 15:25:39', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('109', 'Invoice Item Updated [ID: 21, Thuy]', '2017-05-08 15:26:46', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('110', 'New Invoice Item Added [ID:27, dssad]', '2017-05-08 15:27:52', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('111', 'New Invoice Item Added [ID:28, 1ghfhfdh]', '2017-05-08 15:28:37', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('112', 'New Invoice Item Added [ID:29, ewqewqe]', '2017-05-08 15:31:19', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('113', 'New Invoice Item Added [ID:30, aaa1111]', '2017-05-08 16:07:46', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('114', 'New Invoice Item Added [ID:31, 232432432]', '2017-05-08 16:17:06', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('115', 'Invoice Item Updated [ID: 31, 232432432]', '2017-05-08 16:17:13', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('116', 'Invoice Item Updated [ID: 29, ewqewqe]', '2017-05-08 16:18:20', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('117', 'Invoice Item Updated [ID: 27, dssad]', '2017-05-08 16:22:33', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('118', 'Invoice Item Updated [ID: 27, dssad]', '2017-05-08 16:34:10', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('119', 'Invoice Item Updated [ID: 27, dssad]', '2017-05-08 16:54:33', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('120', 'Invoice Item Deleted [ID: 28]', '2017-05-08 16:56:36', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('121', 'Invoice Item Deleted [ID: 27]', '2017-05-08 16:56:41', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('122', 'Invoice Item Updated [ID: 29, ewqewqe]', '2017-05-08 16:56:52', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('123', 'Invoice Item Deleted [ID: 31]', '2017-05-09 08:43:59', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('124', 'Invoice Item Deleted [ID: 30]', '2017-05-09 08:44:02', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('125', 'Invoice Item Deleted [ID: 26]', '2017-05-09 08:44:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('126', 'Invoice Item Deleted [ID: 22]', '2017-05-09 08:44:07', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('127', 'New Invoice Item Added [ID:32, sdsa]', '2017-05-10 08:46:23', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('128', 'New Invoice Item Added [ID:33, a]', '2017-05-10 09:03:46', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('129', 'Invoice Item Deleted [ID: 21]', '2017-05-10 09:05:34', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('130', 'Invoice Item Deleted [ID: 33]', '2017-05-10 09:05:36', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('131', 'Invoice Item Deleted [ID: 29]', '2017-05-10 09:05:39', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('132', 'Invoice Item Deleted [ID: 32]', '2017-05-10 09:05:41', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('133', 'New Invoice Item Added [ID:34, 1]', '2017-05-10 09:06:00', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('134', 'Invoice Item Updated [ID: 34, 1]', '2017-05-10 09:06:14', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('135', 'Invoice Item Updated [ID: 34, 1]', '2017-05-10 09:06:20', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('136', 'Trạng thái Khách hàng đã thay đổi [CustomerID: 1 Status(Active/Inactive): 0]', '2017-05-10 09:27:48', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('137', 'Trạng thái Khách hàng đã thay đổi [CustomerID: 1 Status(Active/Inactive): 1]', '2017-05-10 09:27:49', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('138', 'Trạng thái Khách hàng đã thay đổi [CustomerID: 1 Status(Active/Inactive): 0]', '2017-05-10 09:27:51', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('139', 'Trạng thái Khách hàng đã thay đổi [CustomerID: 1 Status(Active/Inactive): 1]', '2017-05-10 09:27:55', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('140', 'Invoice Item Updated [ID: 34, 1]', '2017-05-10 09:31:38', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('141', 'Invoice Item Updated [ID: 34, 1]', '2017-05-10 09:35:04', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('142', 'New Invoice Item Added [ID:35, 2]', '2017-05-10 09:53:47', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('143', 'Invoice Item Updated [ID: 35, 2]', '2017-05-10 09:53:57', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('144', 'Invoice Item Updated [ID: 35, 2]', '2017-05-10 09:54:18', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('145', 'Invoice Item Updated [ID: 35, 2]', '2017-05-10 09:54:32', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('146', 'Invoice Item Updated [ID: 35, 2]', '2017-05-10 09:54:46', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('147', 'New Invoice Item Added [ID:36, dsa]', '2017-05-10 10:27:13', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('148', 'Invoice Item Updated [ID: 36, dsa]', '2017-05-10 10:27:27', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('149', 'Failed Login Attempt [Email:admin@admin.com, Is Staff Member:Yes, IP:::1]', '2017-05-13 10:55:26', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('150', 'Failed Login Attempt [Email:admin@admin.com, Is Staff Member:Yes, IP:::1]', '2017-05-15 08:25:50', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('151', 'Failed Login Attempt [Email:admin@gmail.com, Is Staff Member:Yes, IP:::1]', '2017-05-15 08:25:55', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('152', 'Contact Updated [Khách hàng 1]', '2017-05-15 11:26:49', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('153', 'Failed Login Attempt [Email:admin@admin.com, Is Staff Member:Yes, IP:::1]', '2017-05-15 11:27:18', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('154', 'Failed Login Attempt [Email:admin@admin.com, Is Staff Member:Yes, IP:::1]', '2017-05-15 11:27:22', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('155', 'Email Template Updated [New marketing Added/Registered (Welcome Email)]', '2017-05-16 12:06:10', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('156', 'Tax Deleted [ID: 5]', '2017-05-17 15:22:51', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('157', 'Tax Deleted [ID: 4]', '2017-05-17 15:23:31', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('158', 'Tax Deleted [ID: 7]', '2017-05-17 15:30:24', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('159', 'Tax Deleted [ID: 13]', '2017-05-17 16:13:21', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('160', 'Tax Deleted [ID: 14]', '2017-05-17 16:13:35', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('161', 'Tax Deleted [ID: 15]', '2017-05-17 16:17:14', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('162', 'Tax Deleted [ID: 16]', '2017-05-17 16:23:22', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('163', 'Tax Deleted [ID: 17]', '2017-05-17 16:23:37', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('164', 'Tax Deleted [ID: 18]', '2017-05-17 16:28:01', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('165', 'Tax Deleted [ID: 19]', '2017-05-17 16:41:52', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('166', 'Tax Deleted [ID: 20]', '2017-05-17 16:54:38', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('167', 'Tax Deleted [ID: 21]', '2017-05-17 16:54:50', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('168', 'Tax Deleted [ID: 22]', '2017-05-17 17:02:24', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('169', 'Tax Deleted [ID: 23]', '2017-05-17 17:03:22', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('170', 'Tax Deleted [ID: 24]', '2017-05-17 17:04:53', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('171', 'Tax Deleted [ID: 25]', '2017-05-17 17:06:26', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('172', 'Tax Deleted [ID: 26]', '2017-05-17 17:10:12', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('173', 'Tax Deleted [ID: 27]', '2017-05-17 17:14:51', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('174', 'Tax Deleted [ID: 29]', '2017-05-17 17:18:12', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('175', 'Tax Deleted [ID: 28]', '2017-05-17 17:18:15', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('176', 'Tax Deleted [ID: 8]', '2017-05-18 08:21:12', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('177', 'Tax Deleted [ID: 32]', '2017-05-18 08:21:23', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('178', 'Tax Deleted [ID: 33]', '2017-05-18 08:21:30', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('179', 'Tax Deleted [ID: 3]', '2017-05-18 08:21:35', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('180', 'Tax Deleted [ID: 6]', '2017-05-18 08:21:41', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('181', 'Tax Deleted [ID: 2]', '2017-05-18 11:19:23', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('182', 'Email Send To [Email:thuylinh@gmail.com, Template:Staff Added as Project Member]', '2017-05-25 14:08:44', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('183', 'Email Send To [Email:ngocha@gmail.com, Template:Staff Added as Project Member]', '2017-05-25 14:08:44', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('184', 'New Project Created [ID: 1]', '2017-05-25 14:08:44', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('185', 'Email Send To [Email:ngocha@gmail.com, Template:Staff Added as Project Member]', '2017-05-25 14:10:04', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('186', 'New Project Created [ID: 2]', '2017-05-25 14:10:04', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('187', 'Tax Deleted [ID: 34]', '2017-05-25 14:22:59', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('188', 'Tax Deleted [ID: 42]', '2017-05-27 14:31:14', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('189', 'Tax Deleted [ID: 39]', '2017-05-27 14:31:22', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('190', 'Tax Deleted [ID: 41]', '2017-05-27 14:33:14', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('191', 'Tax Deleted [ID: 43]', '2017-05-27 14:33:20', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('192', 'Tax Deleted [ID: 47]', '2017-05-27 14:33:45', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('193', 'Tax Deleted [ID: 46]', '2017-05-27 14:34:02', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('194', 'Tax Deleted [ID: 45]', '2017-05-27 14:34:09', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('195', 'Tax Deleted [ID: 44]', '2017-05-27 14:34:12', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('196', 'Tax Deleted [ID: 40]', '2017-05-27 14:35:01', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('197', 'Tax Deleted [ID: 52]', '2017-05-27 14:39:22', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('198', 'Tax Deleted [ID: 26]', '2017-05-27 16:37:27', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('199', 'Email Template Updated [New marketing Added/Registered (Welcome Email)]', '2017-05-27 17:05:42', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('200', 'Email Template Updated [Quên mật khẩu]', '2017-05-27 17:08:13', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('201', 'Tax Deleted [ID: 23]', '2017-05-30 11:50:58', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('202', 'Tax Deleted [ID: 48]', '2017-05-30 11:56:20', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('203', 'Tax Deleted [ID: 57]', '2017-05-30 11:56:43', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('204', 'Tax Deleted [ID: 56]', '2017-05-30 11:56:50', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('205', 'Tax Deleted [ID: 50]', '2017-05-30 11:57:00', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('206', 'Tax Deleted [ID: 51]', '2017-05-30 11:57:06', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('207', 'Tax Deleted [ID: 54]', '2017-05-30 12:02:58', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('208', 'Tax Deleted [ID: 55]', '2017-05-30 12:03:10', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('209', 'New Leads Status Added [StatusID: 2, Name: Đã liên lạc]', '2017-05-30 12:10:33', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('210', 'Lead Deleted [Deleted by:  , LeadID: 3]', '2017-05-30 12:12:31', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('211', 'Lead Deleted [Deleted by:  , LeadID: 2]', '2017-05-30 12:12:38', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('212', 'Lead Deleted [Deleted by:  , LeadID: 1]', '2017-05-30 12:12:45', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('213', 'Tax Deleted [ID: 60]', '2017-05-30 13:11:49', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('214', 'Tax Deleted [ID: 31]', '2017-05-30 13:23:36', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('215', 'Tax Deleted [ID: 32]', '2017-05-30 13:39:51', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('216', 'Tax Deleted [ID: 30]', '2017-05-30 13:41:59', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('217', 'Tax Deleted [ID: 27]', '2017-05-30 13:43:18', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('218', 'Tax Deleted [ID: 33]', '2017-05-30 13:44:25', ' ');


#
# TABLE STRUCTURE FOR: tblannouncements
#

DROP TABLE IF EXISTS `tblannouncements`;

CREATE TABLE `tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `message` text,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcategory
#

DROP TABLE IF EXISTS `tblcategory`;

CREATE TABLE `tblcategory` (
  `Id_category` int(11) NOT NULL AUTO_INCREMENT,
  `name_category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id_category`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblcategory` (`Id_category`, `name_category`) VALUES ('1', 'tập tin');
INSERT INTO `tblcategory` (`Id_category`, `name_category`) VALUES ('2', 'hình ảnh');


#
# TABLE STRUCTURE FOR: tblclients
#

DROP TABLE IF EXISTS `tblclients`;

CREATE TABLE `tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(100) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT '0',
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT '0',
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT '0',
  `longitude` varchar(300) DEFAULT NULL,
  `latitude` varchar(300) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT '0',
  `show_primary_contact` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `country` (`country`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`) VALUES ('1', 'FOSO', '123456789', '0126479974', '243', 'TP.HCM', '', '', 'Cao thắng', '', '2017-03-30 14:30:34', '1', NULL, '', '', '', '', '0', '', '', '', '', '0', '', '', '', '1', '0');
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`) VALUES ('2', 'Viettel', '123456789', '1216479974', '243', 'ee', '', '', 'adssadada', '', '2017-03-30 20:53:19', '1', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, '0', NULL, NULL, 'vietnamese', '0', '0');


#
# TABLE STRUCTURE FOR: tblcommentlikes
#

DROP TABLE IF EXISTS `tblcommentlikes`;

CREATE TABLE `tblcommentlikes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontactpermissions
#

DROP TABLE IF EXISTS `tblcontactpermissions`;

CREATE TABLE `tblcontactpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('1', '1', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('2', '2', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('3', '3', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('4', '4', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('5', '5', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('6', '6', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('7', '1', '2');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('8', '2', '2');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('9', '3', '2');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('10', '4', '2');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('11', '5', '2');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('12', '6', '2');


#
# TABLE STRUCTURE FOR: tblcontacts
#

DROP TABLE IF EXISTS `tblcontacts`;

CREATE TABLE `tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT '1',
  `firstname` varchar(300) NOT NULL,
  `lastname` varchar(300) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `profile_image` varchar(300) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `is_primary` (`is_primary`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`) VALUES ('1', '2', '1', 'Khách', 'hàng 1', 'client@gmail.com', '01216479974', '', '2017-03-30 20:53:19', '$2a$08$hOSLlwxsDLH6xOxHWv134evd.4H6fUvd2Z6I0G/NYlT.L7hecXoRS', NULL, NULL, '::1', '2017-05-15 11:27:46', '2017-05-15 11:26:49', '1', NULL, '');
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`) VALUES ('2', '1', '1', 'FO', 'SO', 'companyfoso@gmail.com', '01216479974', '', '2017-03-30 20:57:05', '$2a$08$HMHxLD0HtHJbz6kmzXU8COB5UpCSq0CI63PXtYRTDpWd.j2c94cIK', NULL, NULL, '::1', '2017-03-30 20:57:33', NULL, '1', NULL, 'ltr');


#
# TABLE STRUCTURE FOR: tblcontractrenewals
#

DROP TABLE IF EXISTS `tblcontractrenewals`;

CREATE TABLE `tblcontractrenewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(11,2) DEFAULT NULL,
  `new_value` decimal(11,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT '0',
  `is_on_old_expiry_notified` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontracts
#

DROP TABLE IF EXISTS `tblcontracts`;

CREATE TABLE `tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `description` text,
  `subject` varchar(300) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT '0',
  `contract_value` decimal(11,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT '0',
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontracts` (`id`, `content`, `description`, `subject`, `client`, `datestart`, `dateend`, `contract_type`, `addedfrom`, `dateadded`, `isexpirynotified`, `contract_value`, `trash`, `not_visible_to_client`) VALUES ('1', NULL, '', 'Báo cáo thuế', '2', '2017-03-31', '2017-05-19', '0', '1', '2017-03-31 00:14:42', '0', '8000000.00', '0', '0');


#
# TABLE STRUCTURE FOR: tblcontracttypes
#

DROP TABLE IF EXISTS `tblcontracttypes`;

CREATE TABLE `tblcontracttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcountries
#

DROP TABLE IF EXISTS `tblcountries`;

CREATE TABLE `tblcountries` (
  `country_id` int(5) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;

INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('1', 'AF', 'Afghanistan', 'Islamic Republic of Afghanistan', 'AFG', '004', 'yes', '93', '.af');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('2', 'AX', 'Aland Islands', '&Aring;land Islands', 'ALA', '248', 'no', '358', '.ax');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('3', 'AL', 'Albania', 'Republic of Albania', 'ALB', '008', 'yes', '355', '.al');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('4', 'DZ', 'Algeria', 'People\'s Democratic Republic of Algeria', 'DZA', '012', 'yes', '213', '.dz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('5', 'AS', 'American Samoa', 'American Samoa', 'ASM', '016', 'no', '1+684', '.as');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('6', 'AD', 'Andorra', 'Principality of Andorra', 'AND', '020', 'yes', '376', '.ad');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('7', 'AO', 'Angola', 'Republic of Angola', 'AGO', '024', 'yes', '244', '.ao');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('8', 'AI', 'Anguilla', 'Anguilla', 'AIA', '660', 'no', '1+264', '.ai');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('9', 'AQ', 'Antarctica', 'Antarctica', 'ATA', '010', 'no', '672', '.aq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('10', 'AG', 'Antigua and Barbuda', 'Antigua and Barbuda', 'ATG', '028', 'yes', '1+268', '.ag');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('11', 'AR', 'Argentina', 'Argentine Republic', 'ARG', '032', 'yes', '54', '.ar');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('12', 'AM', 'Armenia', 'Republic of Armenia', 'ARM', '051', 'yes', '374', '.am');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('13', 'AW', 'Aruba', 'Aruba', 'ABW', '533', 'no', '297', '.aw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('14', 'AU', 'Australia', 'Commonwealth of Australia', 'AUS', '036', 'yes', '61', '.au');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('15', 'AT', 'Austria', 'Republic of Austria', 'AUT', '040', 'yes', '43', '.at');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('16', 'AZ', 'Azerbaijan', 'Republic of Azerbaijan', 'AZE', '031', 'yes', '994', '.az');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('17', 'BS', 'Bahamas', 'Commonwealth of The Bahamas', 'BHS', '044', 'yes', '1+242', '.bs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('18', 'BH', 'Bahrain', 'Kingdom of Bahrain', 'BHR', '048', 'yes', '973', '.bh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('19', 'BD', 'Bangladesh', 'People\'s Republic of Bangladesh', 'BGD', '050', 'yes', '880', '.bd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('20', 'BB', 'Barbados', 'Barbados', 'BRB', '052', 'yes', '1+246', '.bb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('21', 'BY', 'Belarus', 'Republic of Belarus', 'BLR', '112', 'yes', '375', '.by');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('22', 'BE', 'Belgium', 'Kingdom of Belgium', 'BEL', '056', 'yes', '32', '.be');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('23', 'BZ', 'Belize', 'Belize', 'BLZ', '084', 'yes', '501', '.bz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('24', 'BJ', 'Benin', 'Republic of Benin', 'BEN', '204', 'yes', '229', '.bj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('25', 'BM', 'Bermuda', 'Bermuda Islands', 'BMU', '060', 'no', '1+441', '.bm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('26', 'BT', 'Bhutan', 'Kingdom of Bhutan', 'BTN', '064', 'yes', '975', '.bt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('27', 'BO', 'Bolivia', 'Plurinational State of Bolivia', 'BOL', '068', 'yes', '591', '.bo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('28', 'BQ', 'Bonaire, Sint Eustatius and Saba', 'Bonaire, Sint Eustatius and Saba', 'BES', '535', 'no', '599', '.bq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('29', 'BA', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', 'BIH', '070', 'yes', '387', '.ba');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('30', 'BW', 'Botswana', 'Republic of Botswana', 'BWA', '072', 'yes', '267', '.bw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('31', 'BV', 'Bouvet Island', 'Bouvet Island', 'BVT', '074', 'no', 'NONE', '.bv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('32', 'BR', 'Brazil', 'Federative Republic of Brazil', 'BRA', '076', 'yes', '55', '.br');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('33', 'IO', 'British Indian Ocean Territory', 'British Indian Ocean Territory', 'IOT', '086', 'no', '246', '.io');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('34', 'BN', 'Brunei', 'Brunei Darussalam', 'BRN', '096', 'yes', '673', '.bn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('35', 'BG', 'Bulgaria', 'Republic of Bulgaria', 'BGR', '100', 'yes', '359', '.bg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('36', 'BF', 'Burkina Faso', 'Burkina Faso', 'BFA', '854', 'yes', '226', '.bf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('37', 'BI', 'Burundi', 'Republic of Burundi', 'BDI', '108', 'yes', '257', '.bi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('38', 'KH', 'Cambodia', 'Kingdom of Cambodia', 'KHM', '116', 'yes', '855', '.kh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('39', 'CM', 'Cameroon', 'Republic of Cameroon', 'CMR', '120', 'yes', '237', '.cm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('40', 'CA', 'Canada', 'Canada', 'CAN', '124', 'yes', '1', '.ca');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('41', 'CV', 'Cape Verde', 'Republic of Cape Verde', 'CPV', '132', 'yes', '238', '.cv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('42', 'KY', 'Cayman Islands', 'The Cayman Islands', 'CYM', '136', 'no', '1+345', '.ky');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('43', 'CF', 'Central African Republic', 'Central African Republic', 'CAF', '140', 'yes', '236', '.cf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('44', 'TD', 'Chad', 'Republic of Chad', 'TCD', '148', 'yes', '235', '.td');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('45', 'CL', 'Chile', 'Republic of Chile', 'CHL', '152', 'yes', '56', '.cl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('46', 'CN', 'China', 'People\'s Republic of China', 'CHN', '156', 'yes', '86', '.cn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('47', 'CX', 'Christmas Island', 'Christmas Island', 'CXR', '162', 'no', '61', '.cx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('48', 'CC', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', 'CCK', '166', 'no', '61', '.cc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('49', 'CO', 'Colombia', 'Republic of Colombia', 'COL', '170', 'yes', '57', '.co');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('50', 'KM', 'Comoros', 'Union of the Comoros', 'COM', '174', 'yes', '269', '.km');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('51', 'CG', 'Congo', 'Republic of the Congo', 'COG', '178', 'yes', '242', '.cg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('52', 'CK', 'Cook Islands', 'Cook Islands', 'COK', '184', 'some', '682', '.ck');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('53', 'CR', 'Costa Rica', 'Republic of Costa Rica', 'CRI', '188', 'yes', '506', '.cr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('54', 'CI', 'Cote d\'ivoire (Ivory Coast)', 'Republic of C&ocirc;te D\'Ivoire (Ivory Coast)', 'CIV', '384', 'yes', '225', '.ci');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('55', 'HR', 'Croatia', 'Republic of Croatia', 'HRV', '191', 'yes', '385', '.hr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('56', 'CU', 'Cuba', 'Republic of Cuba', 'CUB', '192', 'yes', '53', '.cu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('57', 'CW', 'Curacao', 'Cura&ccedil;ao', 'CUW', '531', 'no', '599', '.cw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('58', 'CY', 'Cyprus', 'Republic of Cyprus', 'CYP', '196', 'yes', '357', '.cy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('59', 'CZ', 'Czech Republic', 'Czech Republic', 'CZE', '203', 'yes', '420', '.cz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('60', 'CD', 'Democratic Republic of the Congo', 'Democratic Republic of the Congo', 'COD', '180', 'yes', '243', '.cd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('61', 'DK', 'Denmark', 'Kingdom of Denmark', 'DNK', '208', 'yes', '45', '.dk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('62', 'DJ', 'Djibouti', 'Republic of Djibouti', 'DJI', '262', 'yes', '253', '.dj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('63', 'DM', 'Dominica', 'Commonwealth of Dominica', 'DMA', '212', 'yes', '1+767', '.dm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('64', 'DO', 'Dominican Republic', 'Dominican Republic', 'DOM', '214', 'yes', '1+809, 8', '.do');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('65', 'EC', 'Ecuador', 'Republic of Ecuador', 'ECU', '218', 'yes', '593', '.ec');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('66', 'EG', 'Egypt', 'Arab Republic of Egypt', 'EGY', '818', 'yes', '20', '.eg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('67', 'SV', 'El Salvador', 'Republic of El Salvador', 'SLV', '222', 'yes', '503', '.sv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('68', 'GQ', 'Equatorial Guinea', 'Republic of Equatorial Guinea', 'GNQ', '226', 'yes', '240', '.gq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('69', 'ER', 'Eritrea', 'State of Eritrea', 'ERI', '232', 'yes', '291', '.er');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('70', 'EE', 'Estonia', 'Republic of Estonia', 'EST', '233', 'yes', '372', '.ee');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('71', 'ET', 'Ethiopia', 'Federal Democratic Republic of Ethiopia', 'ETH', '231', 'yes', '251', '.et');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('72', 'FK', 'Falkland Islands (Malvinas)', 'The Falkland Islands (Malvinas)', 'FLK', '238', 'no', '500', '.fk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('73', 'FO', 'Faroe Islands', 'The Faroe Islands', 'FRO', '234', 'no', '298', '.fo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('74', 'FJ', 'Fiji', 'Republic of Fiji', 'FJI', '242', 'yes', '679', '.fj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('75', 'FI', 'Finland', 'Republic of Finland', 'FIN', '246', 'yes', '358', '.fi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('76', 'FR', 'France', 'French Republic', 'FRA', '250', 'yes', '33', '.fr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('77', 'GF', 'French Guiana', 'French Guiana', 'GUF', '254', 'no', '594', '.gf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('78', 'PF', 'French Polynesia', 'French Polynesia', 'PYF', '258', 'no', '689', '.pf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('79', 'TF', 'French Southern Territories', 'French Southern Territories', 'ATF', '260', 'no', NULL, '.tf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('80', 'GA', 'Gabon', 'Gabonese Republic', 'GAB', '266', 'yes', '241', '.ga');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('81', 'GM', 'Gambia', 'Republic of The Gambia', 'GMB', '270', 'yes', '220', '.gm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('82', 'GE', 'Georgia', 'Georgia', 'GEO', '268', 'yes', '995', '.ge');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('83', 'DE', 'Germany', 'Federal Republic of Germany', 'DEU', '276', 'yes', '49', '.de');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('84', 'GH', 'Ghana', 'Republic of Ghana', 'GHA', '288', 'yes', '233', '.gh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('85', 'GI', 'Gibraltar', 'Gibraltar', 'GIB', '292', 'no', '350', '.gi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('86', 'GR', 'Greece', 'Hellenic Republic', 'GRC', '300', 'yes', '30', '.gr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('87', 'GL', 'Greenland', 'Greenland', 'GRL', '304', 'no', '299', '.gl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('88', 'GD', 'Grenada', 'Grenada', 'GRD', '308', 'yes', '1+473', '.gd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('89', 'GP', 'Guadaloupe', 'Guadeloupe', 'GLP', '312', 'no', '590', '.gp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('90', 'GU', 'Guam', 'Guam', 'GUM', '316', 'no', '1+671', '.gu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('91', 'GT', 'Guatemala', 'Republic of Guatemala', 'GTM', '320', 'yes', '502', '.gt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('92', 'GG', 'Guernsey', 'Guernsey', 'GGY', '831', 'no', '44', '.gg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('93', 'GN', 'Guinea', 'Republic of Guinea', 'GIN', '324', 'yes', '224', '.gn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('94', 'GW', 'Guinea-Bissau', 'Republic of Guinea-Bissau', 'GNB', '624', 'yes', '245', '.gw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('95', 'GY', 'Guyana', 'Co-operative Republic of Guyana', 'GUY', '328', 'yes', '592', '.gy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('96', 'HT', 'Haiti', 'Republic of Haiti', 'HTI', '332', 'yes', '509', '.ht');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('97', 'HM', 'Heard Island and McDonald Islands', 'Heard Island and McDonald Islands', 'HMD', '334', 'no', 'NONE', '.hm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('98', 'HN', 'Honduras', 'Republic of Honduras', 'HND', '340', 'yes', '504', '.hn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('99', 'HK', 'Hong Kong', 'Hong Kong', 'HKG', '344', 'no', '852', '.hk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('100', 'HU', 'Hungary', 'Hungary', 'HUN', '348', 'yes', '36', '.hu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('101', 'IS', 'Iceland', 'Republic of Iceland', 'ISL', '352', 'yes', '354', '.is');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('102', 'IN', 'India', 'Republic of India', 'IND', '356', 'yes', '91', '.in');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('103', 'ID', 'Indonesia', 'Republic of Indonesia', 'IDN', '360', 'yes', '62', '.id');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('104', 'IR', 'Iran', 'Islamic Republic of Iran', 'IRN', '364', 'yes', '98', '.ir');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('105', 'IQ', 'Iraq', 'Republic of Iraq', 'IRQ', '368', 'yes', '964', '.iq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('106', 'IE', 'Ireland', 'Ireland', 'IRL', '372', 'yes', '353', '.ie');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('107', 'IM', 'Isle of Man', 'Isle of Man', 'IMN', '833', 'no', '44', '.im');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('108', 'IL', 'Israel', 'State of Israel', 'ISR', '376', 'yes', '972', '.il');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('109', 'IT', 'Italy', 'Italian Republic', 'ITA', '380', 'yes', '39', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('110', 'JM', 'Jamaica', 'Jamaica', 'JAM', '388', 'yes', '1+876', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('111', 'JP', 'Japan', 'Japan', 'JPN', '392', 'yes', '81', '.jp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('112', 'JE', 'Jersey', 'The Bailiwick of Jersey', 'JEY', '832', 'no', '44', '.je');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('113', 'JO', 'Jordan', 'Hashemite Kingdom of Jordan', 'JOR', '400', 'yes', '962', '.jo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('114', 'KZ', 'Kazakhstan', 'Republic of Kazakhstan', 'KAZ', '398', 'yes', '7', '.kz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('115', 'KE', 'Kenya', 'Republic of Kenya', 'KEN', '404', 'yes', '254', '.ke');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('116', 'KI', 'Kiribati', 'Republic of Kiribati', 'KIR', '296', 'yes', '686', '.ki');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('117', 'XK', 'Kosovo', 'Republic of Kosovo', '---', '---', 'some', '381', '');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('118', 'KW', 'Kuwait', 'State of Kuwait', 'KWT', '414', 'yes', '965', '.kw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('119', 'KG', 'Kyrgyzstan', 'Kyrgyz Republic', 'KGZ', '417', 'yes', '996', '.kg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('120', 'LA', 'Laos', 'Lao People\'s Democratic Republic', 'LAO', '418', 'yes', '856', '.la');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('121', 'LV', 'Latvia', 'Republic of Latvia', 'LVA', '428', 'yes', '371', '.lv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('122', 'LB', 'Lebanon', 'Republic of Lebanon', 'LBN', '422', 'yes', '961', '.lb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('123', 'LS', 'Lesotho', 'Kingdom of Lesotho', 'LSO', '426', 'yes', '266', '.ls');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('124', 'LR', 'Liberia', 'Republic of Liberia', 'LBR', '430', 'yes', '231', '.lr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('125', 'LY', 'Libya', 'Libya', 'LBY', '434', 'yes', '218', '.ly');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('126', 'LI', 'Liechtenstein', 'Principality of Liechtenstein', 'LIE', '438', 'yes', '423', '.li');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('127', 'LT', 'Lithuania', 'Republic of Lithuania', 'LTU', '440', 'yes', '370', '.lt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('128', 'LU', 'Luxembourg', 'Grand Duchy of Luxembourg', 'LUX', '442', 'yes', '352', '.lu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('129', 'MO', 'Macao', 'The Macao Special Administrative Region', 'MAC', '446', 'no', '853', '.mo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('130', 'MK', 'Macedonia', 'The Former Yugoslav Republic of Macedonia', 'MKD', '807', 'yes', '389', '.mk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('131', 'MG', 'Madagascar', 'Republic of Madagascar', 'MDG', '450', 'yes', '261', '.mg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('132', 'MW', 'Malawi', 'Republic of Malawi', 'MWI', '454', 'yes', '265', '.mw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('133', 'MY', 'Malaysia', 'Malaysia', 'MYS', '458', 'yes', '60', '.my');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('134', 'MV', 'Maldives', 'Republic of Maldives', 'MDV', '462', 'yes', '960', '.mv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('135', 'ML', 'Mali', 'Republic of Mali', 'MLI', '466', 'yes', '223', '.ml');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('136', 'MT', 'Malta', 'Republic of Malta', 'MLT', '470', 'yes', '356', '.mt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('137', 'MH', 'Marshall Islands', 'Republic of the Marshall Islands', 'MHL', '584', 'yes', '692', '.mh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('138', 'MQ', 'Martinique', 'Martinique', 'MTQ', '474', 'no', '596', '.mq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('139', 'MR', 'Mauritania', 'Islamic Republic of Mauritania', 'MRT', '478', 'yes', '222', '.mr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('140', 'MU', 'Mauritius', 'Republic of Mauritius', 'MUS', '480', 'yes', '230', '.mu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('141', 'YT', 'Mayotte', 'Mayotte', 'MYT', '175', 'no', '262', '.yt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('142', 'MX', 'Mexico', 'United Mexican States', 'MEX', '484', 'yes', '52', '.mx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('143', 'FM', 'Micronesia', 'Federated States of Micronesia', 'FSM', '583', 'yes', '691', '.fm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('144', 'MD', 'Moldava', 'Republic of Moldova', 'MDA', '498', 'yes', '373', '.md');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('145', 'MC', 'Monaco', 'Principality of Monaco', 'MCO', '492', 'yes', '377', '.mc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('146', 'MN', 'Mongolia', 'Mongolia', 'MNG', '496', 'yes', '976', '.mn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('147', 'ME', 'Montenegro', 'Montenegro', 'MNE', '499', 'yes', '382', '.me');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('148', 'MS', 'Montserrat', 'Montserrat', 'MSR', '500', 'no', '1+664', '.ms');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('149', 'MA', 'Morocco', 'Kingdom of Morocco', 'MAR', '504', 'yes', '212', '.ma');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('150', 'MZ', 'Mozambique', 'Republic of Mozambique', 'MOZ', '508', 'yes', '258', '.mz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('151', 'MM', 'Myanmar (Burma)', 'Republic of the Union of Myanmar', 'MMR', '104', 'yes', '95', '.mm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('152', 'NA', 'Namibia', 'Republic of Namibia', 'NAM', '516', 'yes', '264', '.na');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('153', 'NR', 'Nauru', 'Republic of Nauru', 'NRU', '520', 'yes', '674', '.nr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('154', 'NP', 'Nepal', 'Federal Democratic Republic of Nepal', 'NPL', '524', 'yes', '977', '.np');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('155', 'NL', 'Netherlands', 'Kingdom of the Netherlands', 'NLD', '528', 'yes', '31', '.nl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('156', 'NC', 'New Caledonia', 'New Caledonia', 'NCL', '540', 'no', '687', '.nc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('157', 'NZ', 'New Zealand', 'New Zealand', 'NZL', '554', 'yes', '64', '.nz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('158', 'NI', 'Nicaragua', 'Republic of Nicaragua', 'NIC', '558', 'yes', '505', '.ni');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('159', 'NE', 'Niger', 'Republic of Niger', 'NER', '562', 'yes', '227', '.ne');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('160', 'NG', 'Nigeria', 'Federal Republic of Nigeria', 'NGA', '566', 'yes', '234', '.ng');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('161', 'NU', 'Niue', 'Niue', 'NIU', '570', 'some', '683', '.nu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('162', 'NF', 'Norfolk Island', 'Norfolk Island', 'NFK', '574', 'no', '672', '.nf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('163', 'KP', 'North Korea', 'Democratic People\'s Republic of Korea', 'PRK', '408', 'yes', '850', '.kp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('164', 'MP', 'Northern Mariana Islands', 'Northern Mariana Islands', 'MNP', '580', 'no', '1+670', '.mp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('165', 'NO', 'Norway', 'Kingdom of Norway', 'NOR', '578', 'yes', '47', '.no');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('166', 'OM', 'Oman', 'Sultanate of Oman', 'OMN', '512', 'yes', '968', '.om');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('167', 'PK', 'Pakistan', 'Islamic Republic of Pakistan', 'PAK', '586', 'yes', '92', '.pk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('168', 'PW', 'Palau', 'Republic of Palau', 'PLW', '585', 'yes', '680', '.pw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('169', 'PS', 'Palestine', 'State of Palestine (or Occupied Palestinian Territory)', 'PSE', '275', 'some', '970', '.ps');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('170', 'PA', 'Panama', 'Republic of Panama', 'PAN', '591', 'yes', '507', '.pa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('171', 'PG', 'Papua New Guinea', 'Independent State of Papua New Guinea', 'PNG', '598', 'yes', '675', '.pg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('172', 'PY', 'Paraguay', 'Republic of Paraguay', 'PRY', '600', 'yes', '595', '.py');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('173', 'PE', 'Peru', 'Republic of Peru', 'PER', '604', 'yes', '51', '.pe');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('174', 'PH', 'Phillipines', 'Republic of the Philippines', 'PHL', '608', 'yes', '63', '.ph');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('175', 'PN', 'Pitcairn', 'Pitcairn', 'PCN', '612', 'no', 'NONE', '.pn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('176', 'PL', 'Poland', 'Republic of Poland', 'POL', '616', 'yes', '48', '.pl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('177', 'PT', 'Portugal', 'Portuguese Republic', 'PRT', '620', 'yes', '351', '.pt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('178', 'PR', 'Puerto Rico', 'Commonwealth of Puerto Rico', 'PRI', '630', 'no', '1+939', '.pr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('179', 'QA', 'Qatar', 'State of Qatar', 'QAT', '634', 'yes', '974', '.qa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('180', 'RE', 'Reunion', 'R&eacute;union', 'REU', '638', 'no', '262', '.re');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('181', 'RO', 'Romania', 'Romania', 'ROU', '642', 'yes', '40', '.ro');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('182', 'RU', 'Russia', 'Russian Federation', 'RUS', '643', 'yes', '7', '.ru');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('183', 'RW', 'Rwanda', 'Republic of Rwanda', 'RWA', '646', 'yes', '250', '.rw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('184', 'BL', 'Saint Barthelemy', 'Saint Barth&eacute;lemy', 'BLM', '652', 'no', '590', '.bl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('185', 'SH', 'Saint Helena', 'Saint Helena, Ascension and Tristan da Cunha', 'SHN', '654', 'no', '290', '.sh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('186', 'KN', 'Saint Kitts and Nevis', 'Federation of Saint Christopher and Nevis', 'KNA', '659', 'yes', '1+869', '.kn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('187', 'LC', 'Saint Lucia', 'Saint Lucia', 'LCA', '662', 'yes', '1+758', '.lc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('188', 'MF', 'Saint Martin', 'Saint Martin', 'MAF', '663', 'no', '590', '.mf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('189', 'PM', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', 'SPM', '666', 'no', '508', '.pm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('190', 'VC', 'Saint Vincent and the Grenadines', 'Saint Vincent and the Grenadines', 'VCT', '670', 'yes', '1+784', '.vc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('191', 'WS', 'Samoa', 'Independent State of Samoa', 'WSM', '882', 'yes', '685', '.ws');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('192', 'SM', 'San Marino', 'Republic of San Marino', 'SMR', '674', 'yes', '378', '.sm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('193', 'ST', 'Sao Tome and Principe', 'Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'STP', '678', 'yes', '239', '.st');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('194', 'SA', 'Saudi Arabia', 'Kingdom of Saudi Arabia', 'SAU', '682', 'yes', '966', '.sa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('195', 'SN', 'Senegal', 'Republic of Senegal', 'SEN', '686', 'yes', '221', '.sn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('196', 'RS', 'Serbia', 'Republic of Serbia', 'SRB', '688', 'yes', '381', '.rs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('197', 'SC', 'Seychelles', 'Republic of Seychelles', 'SYC', '690', 'yes', '248', '.sc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('198', 'SL', 'Sierra Leone', 'Republic of Sierra Leone', 'SLE', '694', 'yes', '232', '.sl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('199', 'SG', 'Singapore', 'Republic of Singapore', 'SGP', '702', 'yes', '65', '.sg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('200', 'SX', 'Sint Maarten', 'Sint Maarten', 'SXM', '534', 'no', '1+721', '.sx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('201', 'SK', 'Slovakia', 'Slovak Republic', 'SVK', '703', 'yes', '421', '.sk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('202', 'SI', 'Slovenia', 'Republic of Slovenia', 'SVN', '705', 'yes', '386', '.si');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('203', 'SB', 'Solomon Islands', 'Solomon Islands', 'SLB', '090', 'yes', '677', '.sb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('204', 'SO', 'Somalia', 'Somali Republic', 'SOM', '706', 'yes', '252', '.so');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('205', 'ZA', 'South Africa', 'Republic of South Africa', 'ZAF', '710', 'yes', '27', '.za');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('206', 'GS', 'South Georgia and the South Sandwich Islands', 'South Georgia and the South Sandwich Islands', 'SGS', '239', 'no', '500', '.gs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('207', 'KR', 'South Korea', 'Republic of Korea', 'KOR', '410', 'yes', '82', '.kr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('208', 'SS', 'South Sudan', 'Republic of South Sudan', 'SSD', '728', 'yes', '211', '.ss');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('209', 'ES', 'Spain', 'Kingdom of Spain', 'ESP', '724', 'yes', '34', '.es');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('210', 'LK', 'Sri Lanka', 'Democratic Socialist Republic of Sri Lanka', 'LKA', '144', 'yes', '94', '.lk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('211', 'SD', 'Sudan', 'Republic of the Sudan', 'SDN', '729', 'yes', '249', '.sd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('212', 'SR', 'Suriname', 'Republic of Suriname', 'SUR', '740', 'yes', '597', '.sr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('213', 'SJ', 'Svalbard and Jan Mayen', 'Svalbard and Jan Mayen', 'SJM', '744', 'no', '47', '.sj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('214', 'SZ', 'Swaziland', 'Kingdom of Swaziland', 'SWZ', '748', 'yes', '268', '.sz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('215', 'SE', 'Sweden', 'Kingdom of Sweden', 'SWE', '752', 'yes', '46', '.se');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('216', 'CH', 'Switzerland', 'Swiss Confederation', 'CHE', '756', 'yes', '41', '.ch');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('217', 'SY', 'Syria', 'Syrian Arab Republic', 'SYR', '760', 'yes', '963', '.sy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('218', 'TW', 'Taiwan', 'Republic of China (Taiwan)', 'TWN', '158', 'former', '886', '.tw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('219', 'TJ', 'Tajikistan', 'Republic of Tajikistan', 'TJK', '762', 'yes', '992', '.tj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('220', 'TZ', 'Tanzania', 'United Republic of Tanzania', 'TZA', '834', 'yes', '255', '.tz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('221', 'TH', 'Thailand', 'Kingdom of Thailand', 'THA', '764', 'yes', '66', '.th');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('222', 'TL', 'Timor-Leste (East Timor)', 'Democratic Republic of Timor-Leste', 'TLS', '626', 'yes', '670', '.tl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('223', 'TG', 'Togo', 'Togolese Republic', 'TGO', '768', 'yes', '228', '.tg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('224', 'TK', 'Tokelau', 'Tokelau', 'TKL', '772', 'no', '690', '.tk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('225', 'TO', 'Tonga', 'Kingdom of Tonga', 'TON', '776', 'yes', '676', '.to');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('226', 'TT', 'Trinidad and Tobago', 'Republic of Trinidad and Tobago', 'TTO', '780', 'yes', '1+868', '.tt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('227', 'TN', 'Tunisia', 'Republic of Tunisia', 'TUN', '788', 'yes', '216', '.tn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('228', 'TR', 'Turkey', 'Republic of Turkey', 'TUR', '792', 'yes', '90', '.tr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('229', 'TM', 'Turkmenistan', 'Turkmenistan', 'TKM', '795', 'yes', '993', '.tm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('230', 'TC', 'Turks and Caicos Islands', 'Turks and Caicos Islands', 'TCA', '796', 'no', '1+649', '.tc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('231', 'TV', 'Tuvalu', 'Tuvalu', 'TUV', '798', 'yes', '688', '.tv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('232', 'UG', 'Uganda', 'Republic of Uganda', 'UGA', '800', 'yes', '256', '.ug');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('233', 'UA', 'Ukraine', 'Ukraine', 'UKR', '804', 'yes', '380', '.ua');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('234', 'AE', 'United Arab Emirates', 'United Arab Emirates', 'ARE', '784', 'yes', '971', '.ae');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('235', 'GB', 'United Kingdom', 'United Kingdom of Great Britain and Nothern Ireland', 'GBR', '826', 'yes', '44', '.uk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('236', 'US', 'United States', 'United States of America', 'USA', '840', 'yes', '1', '.us');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('237', 'UM', 'United States Minor Outlying Islands', 'United States Minor Outlying Islands', 'UMI', '581', 'no', 'NONE', 'NONE');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('238', 'UY', 'Uruguay', 'Eastern Republic of Uruguay', 'URY', '858', 'yes', '598', '.uy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('239', 'UZ', 'Uzbekistan', 'Republic of Uzbekistan', 'UZB', '860', 'yes', '998', '.uz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('240', 'VU', 'Vanuatu', 'Republic of Vanuatu', 'VUT', '548', 'yes', '678', '.vu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('241', 'VA', 'Vatican City', 'State of the Vatican City', 'VAT', '336', 'no', '39', '.va');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('242', 'VE', 'Venezuela', 'Bolivarian Republic of Venezuela', 'VEN', '862', 'yes', '58', '.ve');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('243', 'VN', 'Vietnam', 'Socialist Republic of Vietnam', 'VNM', '704', 'yes', '84', '.vn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('244', 'VG', 'Virgin Islands, British', 'British Virgin Islands', 'VGB', '092', 'no', '1+284', '.vg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('245', 'VI', 'Virgin Islands, US', 'Virgin Islands of the United States', 'VIR', '850', 'no', '1+340', '.vi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('246', 'WF', 'Wallis and Futuna', 'Wallis and Futuna', 'WLF', '876', 'no', '681', '.wf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('247', 'EH', 'Western Sahara', 'Western Sahara', 'ESH', '732', 'no', '212', '.eh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('248', 'YE', 'Yemen', 'Republic of Yemen', 'YEM', '887', 'yes', '967', '.ye');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('249', 'ZM', 'Zambia', 'Republic of Zambia', 'ZMB', '894', 'yes', '260', '.zm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('250', 'ZW', 'Zimbabwe', 'Republic of Zimbabwe', 'ZWE', '716', 'yes', '263', '.zw');


#
# TABLE STRUCTURE FOR: tblcurrencies
#

DROP TABLE IF EXISTS `tblcurrencies`;

CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `isdefault`) VALUES ('1', '$', 'USD', '1');
INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `isdefault`) VALUES ('2', '€', 'EUR', '0');


#
# TABLE STRUCTURE FOR: tblcustomeradmins
#

DROP TABLE IF EXISTS `tblcustomeradmins`;

CREATE TABLE `tblcustomeradmins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` text NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomerfiles_shares
#

DROP TABLE IF EXISTS `tblcustomerfiles_shares`;

CREATE TABLE `tblcustomerfiles_shares` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `tblcustomerfiles_shares` (`file_id`, `contact_id`) VALUES ('0', '2');


#
# TABLE STRUCTURE FOR: tblcustomergroups_in
#

DROP TABLE IF EXISTS `tblcustomergroups_in`;

CREATE TABLE `tblcustomergroups_in` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomersgroups
#

DROP TABLE IF EXISTS `tblcustomersgroups`;

CREATE TABLE `tblcustomersgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomfields
#

DROP TABLE IF EXISTS `tblcustomfields`;

CREATE TABLE `tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL,
  `options` mediumtext,
  `field_order` int(11) DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '1',
  `show_on_pdf` int(11) NOT NULL DEFAULT '0',
  `only_admin` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_table` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_client_portal` int(11) NOT NULL DEFAULT '0',
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT '0',
  `bs_column` int(11) NOT NULL DEFAULT '12',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomfieldsvalues
#

DROP TABLE IF EXISTS `tblcustomfieldsvalues`;

CREATE TABLE `tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`fieldid`),
  KEY `fieldto` (`fieldto`),
  KEY `relid_2` (`relid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `host` varchar(150) DEFAULT NULL,
  `password` mediumtext,
  `encryption` varchar(3) DEFAULT NULL,
  `delete_after_import` int(11) NOT NULL DEFAULT '0',
  `calendar_id` mediumtext,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`departmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbldismissedannouncements
#

DROP TABLE IF EXISTS `tbldismissedannouncements`;

CREATE TABLE `tbldismissedannouncements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblemaillists
#

DROP TABLE IF EXISTS `tblemaillists`;

CREATE TABLE `tblemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblemailtemplates
#

DROP TABLE IF EXISTS `tblemailtemplates`;

CREATE TABLE `tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` mediumtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` mediumtext NOT NULL,
  `subject` mediumtext NOT NULL,
  `message` text NOT NULL,
  `fromname` mediumtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=MyISAM AUTO_INCREMENT=835 DEFAULT CHARSET=utf8;

INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('1', 'client', 'new-client-created', 'english', 'New Contact Added/Registered (Welcome Email)', 'Welcome aboard', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><br /></span><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank you for registering on the {companyname} CRM System.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We just wanted to say welcome.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us if you need any help.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">(This is an automated email, so please don\'t reply to this email address)</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('2', 'invoice', 'invoice-send-to-client', 'english', 'Send Invoice to Customer', 'Invoice with number {invoice_number} created', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We have prepared the following invoice for you: #&nbsp;{invoice_number}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Invoice status:&nbsp;<strong style=\"font-family: Helvetica, Arial, sans-serif;\">{invoice_status}</strong></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span>&nbsp;</div>\r\n<div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span></div>\r\n</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us for more information.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('3', 'ticket', 'new-ticket-opened-admin', 'english', 'New Ticket Opened (Opened by Staff, Sent to Customer)', 'New Support Ticket Opened', '<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi&nbsp;{contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">New support ticket has been opened.</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: <span style=\"background-color: inherit;\">{ticket_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; color: #000000; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; color: #000000; font-size: 12pt; background-color: inherit;\">{ticket_message}<br /><br />You can view the ticket on the following link:&nbsp;<a href=\"{ticket_url}\">#{ticket_id}</a><br /></span></div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('4', 'ticket', 'ticket-reply', 'english', 'Ticket Reply (Sent to Customer)', 'New Ticket Reply', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi&nbsp;<span style=\"background-color: inherit;\">{contact_firstname} </span>{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You have a new ticket reply to ticket #{ticket_id}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: <span style=\"background-color: inherit;\">{ticket_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}<br /><br />You can view the ticket on the following link:&nbsp;<a href=\"{ticket_url}\">#{ticket_id}</a><br /></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('5', 'ticket', 'ticket-autoresponse', 'english', 'New Ticket Opened - Autoresponse', 'New Support Ticket Opened', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi&nbsp;{contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: {ticket_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: {ticket_priority}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('6', 'invoice', 'invoice-payment-recorded', 'english', 'Invoice Payment Recorded (Sent to Customer)', 'Invoice Payment Recorded', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Payment recorded for invoice&nbsp;# {invoice_number}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('7', 'invoice', 'invoice-overdue-notice', 'english', 'Invoice Overdue Notice', 'Invoice Overdue Notice - {invoice_number}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">This is an overdue notice for invoice # {invoice_number}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">This invoice was due: {invoice_duedate}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span>&nbsp;</div>\r\n<div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span></div>\r\n</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('8', 'invoice', 'invoice-already-send', 'english', 'Invoice Already Sent to Customer', 'On your command here is the invoice', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi <span style=\"background-color: inherit;\">{contact_firstname} {contact_lastname}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">At your request, here is the invoice with number #{invoice_number}</span></div>\r\n<div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span></div>\r\n</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us for more information.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('9', 'ticket', 'new-ticket-created-staff', 'english', 'New Ticket Created (Opened by Customer, Sent to Staff Members)', 'New Ticket Created', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A new support ticket has been opened.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: <span style=\"background-color: inherit;\">{ticket_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}<br /><br />You can view the ticket on the following link:&nbsp;<a href=\"{ticket_url}\">#{ticket_id}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('10', 'estimate', 'estimate-send-to-client', 'english', 'Send Estimate to Customer', 'Estimate # {estimate_number} created', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please find the attached estimate # {estimate_number}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Estimate status:&nbsp;<strong>{estimate_status}<br /><br /></strong>You can view the estimate on the following link:&nbsp;<a href=\"{estimate_link}\">{estimate_number}</a><br /></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We look forward to your communication.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('11', 'ticket', 'ticket-reply-to-admin', 'english', 'Ticket Reply (Sent to Staff)', 'New Support Ticket Reply', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: <span style=\"background-color: inherit;\">{ticket_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('12', 'estimate', 'estimate-already-send', 'english', 'Estimate Already Sent to Customer', 'Estimate # {estimate_number} ', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank you for your estimate request.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the estimate on the following link:&nbsp;<a href=\"{estimate_link}\">{estimate_number}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us for more information.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('13', 'contract', 'contract-expiration', 'english', 'Contract Expiration', 'Contract Expiration Reminder', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {client_company}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: {contract_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Description: {contract_description}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Date Start: {contract_datestart}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Date End: {contract_dateend}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Value: {contract_contract_value}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us for more information.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('14', 'tasks', 'task-assigned', 'english', 'New Task Assigned (Sent to Staff)', 'New Task Assigned to You - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You have been assigned a new task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Name: <span style=\"background-color: #ffffff;\">{task_name}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: <span style=\"background-color: #ffffff;\">{task_duedate}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: #ffffff;\">{task_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('15', 'tasks', 'task-added-as-follower', 'english', 'Staff Member Added as Follower on Task', 'You are added as follower on task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname} <span style=\"background-color: #ffffff;\">{staff_lastname}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You have been added as follower on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Name: {task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Description: {task_description}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: {task_priority}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Start date: {task_startdate}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: {task_duedate}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('16', 'tasks', 'task-commented', 'english', 'New Comment on Task (Sent to Staff)', 'New Comment on Task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A comment has been made on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Name: &nbsp;{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Description: &nbsp;{task_description}<br />Comment: {task_comment}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('17', 'tasks', 'task-marked-as-finished', 'english', 'Task Marked as Finished (Sent to Staff)', 'Task Marked as Finished - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} marked the following task as complete:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span>{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: <span style=\"background-color: #ffffff;\">{task_duedate}<br /></span></span><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('18', 'tasks', 'task-added-attachment', 'english', 'New Attachment on Task (Sent to Staff)', 'New Attachment on Task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} added an attachment on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span>{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('19', 'tasks', 'task-unmarked-as-finished', 'english', 'Task Unmarked as Finished (Sent to Staff)', 'Task UN-marked as finished - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} <span style=\"background-color: inherit;\">marked the </span>following task as <strong>in-complete / unfinished</strong></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span><span style=\"background-color: inherit;\">{task_name}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: {task_duedate}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('20', 'estimate', 'estimate-declined-to-staff', 'english', 'Estimate Declined (Sent to Staff)', 'Customer Declined Estimate', '<div><span style=\"font-size: 12pt;\">Hi</span></div>\r\n<div><span style=\"font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <span style=\"background-color: inherit;\">{estimate_number}</span></span></div>\r\n<div><span style=\"font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt;\">You can view the estimate on the following link:&nbsp;<a href=\"{estimate_link}\">{estimate_number}</a></span></div>\r\n<div><span style=\"font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('21', 'estimate', 'estimate-accepted-to-staff', 'english', 'Estimate Accepted (Sent to Staff)', 'Customer Accepted Estimate', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <span style=\"background-color: inherit;\">{estimate_number}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the estimate on the following link:&nbsp;<a href=\"{estimate_link}\">{estimate_number}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('22', 'proposals', 'proposal-client-accepted', 'english', 'Customer Action - Accepted (Sent to Staff)', 'Customer Accepted Proposal', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Client {proposal_proposal_to} accepted the following proposal:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: {proposal_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Total: {proposal_total}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('23', 'proposals', 'proposal-send-to-customer', 'english', 'Send Proposal to Customer', 'Proposal', '<div>Dear {proposal_proposal_to}</div>\r\n<div>&nbsp;</div>\r\n<div>Please find our attached proposal.</div>\r\n<div>&nbsp;</div>\r\n<div>This proposal is valid until: {proposal_open_till}</div>\r\n<div>You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a></div>\r\n<div>&nbsp;</div>\r\n<div>Please don\'t hesitate to comment online if you have any questions.</div>\r\n<div>&nbsp;</div>\r\n<div>We look forward to your communication.</div>\r\n<div>&nbsp;</div>\r\n<div>Kind regards</div>\r\n<div>&nbsp;</div>\r\n<div>{email_signature}</div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('24', 'proposals', 'proposal-client-declined', 'english', 'Customer Action - Declined (Sent to Staff)', 'Client Declined Proposal', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Customer {proposal_proposal_to} declined the proposal {proposal_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">View the proposal on the following link <a href=\"{proposal_link}\">{proposal_subject}</a>&nbsp;or from the admin area.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('25', 'proposals', 'proposal-client-thank-you', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting proposal', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {proposal_proposal_to}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank for for accepting the proposal.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We look forward to doing business with you.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We will contact you as soon as possible</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('26', 'proposals', 'proposal-comment-to-client', 'english', 'New Comment  (Sent to Customer Contacts)', 'New Proposal Comment', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {proposal_proposal_to}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A new comment has been made on the following proposal: {proposal_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('27', 'proposals', 'proposal-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Proposal Comment', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hello</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A new <strong>comment</strong> has been made to the proposal <span style=\"background-color: inherit;\">{proposal_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a><span style=\"background-color: inherit;\">&nbsp;or from the admin area.</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('28', 'estimate', 'estimate-thank-you-to-customer', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting estimate', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank for for accepting the estimate.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We look forward to doing business with you.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We will contact you as soon as possible.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('29', 'tasks', 'task-deadline-notification', 'english', 'Task Deadline Reminder - Sent to Assigned Members', 'Task Deadline Reminder', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">This is an automated email from {companyname}.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">The task {task_name} deadline is on {task_duedate}. This task is still not finished.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('30', 'contract', 'send-contract', 'english', 'Send Contract to Customer', 'Contract - {contract_subject}', '<p>Hi&nbsp;{client_company}</p>\r\n<p>Please find the {contract_subject}&nbsp;attached.</p>\r\n<p>Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('31', 'invoice', 'invoice-payment-recorded-to-staff', 'english', 'Invoice Payment Recorded (Sent to Staff)', 'New Invoice Payment', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Customer recorded payment for invoice # {invoice_number}</span></div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('32', 'ticket', 'auto-close-ticket', 'english', 'Auto Close Ticket', 'Ticket Auto Closed', '<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Ticket&nbsp;{ticket_subject} has been auto close due to inactivity.</span></p>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Ticket #: <span style=\"background-color: inherit;\">{ticket_id}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('33', 'project', 'new-project-discussion-created-to-staff', 'english', 'New Project Discussion (Sent to Project Members)', 'New Project Discussion Created', '<p>Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}</p>\r\n<p>New project discussion created from&nbsp;{discussion_creator}</p>\r\n<p>Subject:&nbsp;{discussion_subject}</p>\r\n<p>Description:&nbsp;{discussion_description}</p>\r\n<p>You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('34', 'project', 'new-project-discussion-created-to-customer', 'english', 'New Project Discussion (Sent to Customer Contacts)', 'New Project Discussion Created', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project discussion created from&nbsp;{discussion_creator}</p>\r\n<p>Subject:&nbsp;{discussion_subject}</p>\r\n<p>Description:&nbsp;{discussion_description}</p>\r\n<p>You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('35', 'project', 'new-project-file-uploaded-to-customer', 'english', 'New Project File Uploaded (Sent to Customer Contacts)', 'New Project File Uploaded', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;{project_name} from&nbsp;{file_creator}</p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br />To view&nbsp;the file in our CRM&nbsp;you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('36', 'project', 'new-project-file-uploaded-to-staff', 'english', 'New Project File Uploaded (Sent to Project Members)', 'New Project File Uploaded', '<p>Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;{project_name} from&nbsp;{file_creator}</p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('37', 'project', 'new-project-discussion-comment-to-customer', 'english', 'New Discussion Comment  (Sent to Customer Contacts)', 'New Discussion Comment', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New discussion comment has been made on {discussion_subject} from&nbsp;{comment_creator}</p>\r\n<p>Discussion subject:&nbsp;{discussion_subject}</p>\r\n<p>Comment:&nbsp;{discussion_comment}</p>\r\n<p>You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('38', 'project', 'new-project-discussion-comment-to-staff', 'english', 'New Discussion Comment (Sent to Project Members)', 'New Discussion Comment', '<p>Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}</p>\r\n<p>New discussion comment has been made on {discussion_subject} from&nbsp;{comment_creator}</p>\r\n<p>Discussion subject:&nbsp;{discussion_subject}</p>\r\n<p>Comment:&nbsp;{discussion_comment}</p>\r\n<p>You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('39', 'project', 'staff-added-as-project-member', 'english', 'Staff Added as Project Member', 'New project assigned to you', '<p>Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}</p>\r\n<p>New project has been assigned to you.</p>\r\n<p>You can view the project on the following link <a href=\"{project_link}\">{project_name}</a></p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('40', 'estimate', 'estimate-expiry-reminder', 'english', 'Estimate Expiration Reminder', 'Estimate Expiration Reminder', '<p>Hello&nbsp;{client_company}</p>\r\n<p>The estimate with&nbsp;{estimate_number} will expire on&nbsp;{estimate_expirydate}</p>\r\n<p>You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></p>\r\n<p>Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('41', 'proposals', 'proposal-expiry-reminder', 'english', 'Proposal Expiration Reminder', 'Proposal Expiration Reminder', '<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hello&nbsp;{proposal_proposal_to}</span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">The proposal {proposal_subject} will expire on&nbsp;{proposal_open_till}</span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a></span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Regards,</span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('42', 'staff', 'new-staff-created', 'english', 'New Staff Created (Welcome Email)', 'You are added as staff member', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />You are added as member on our CRM.<br />You can login at {admin_url}<br /><br />Please use the following&nbsp;logic credentials:<br /><br />Email:&nbsp;{staff_email}<br />Password:&nbsp;{password}<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('43', 'client', 'contact-forgot-password', 'english', 'Quên mật khẩu', 'Tạo mật khẩu mới', '<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('44', 'client', 'contact-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<strong>You have changed your password.<br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br />If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('45', 'client', 'contact-set-password', 'english', 'Set New Password', 'Set new password on {companyname} ', '<h2>Setup your new password on {companyname}</h2>\r\nPlease use the following link to setup your new password.<br /><br />Keep it in your records so you don\'t forget it.<br /><br /> Please set your new password in 48 hours. After that you wont be able to set your password. <br /><br />You can login at: {crm_url}<br /> Your email address for login: {contact_email}<br /> <br /><a href=\"{set_password_url}\">Set New Password</a><br /> <br />{email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('46', 'staff', 'staff-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('47', 'staff', 'staff-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<strong>You have changed your password.<br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /> If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('48', 'project', 'assigned-to-project', 'english', 'New Project Created (Sent to Customer Contacts)', 'New Project Created', '<p>Hello&nbsp;{contact_firstname}</p>\r\n<p>New project is assigned to your company.<br />Project Name:&nbsp;{project_name}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('49', 'tasks', 'task-marked-as-finished-to-contacts', 'english', 'Task Marked as Finished (Sent to customer contacts)', 'Task Marked as Finished - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} marked the following task as complete:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span>{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: <span style=\"background-color: #ffffff;\">{task_duedate}<br /></span></span><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('50', 'tasks', 'task-added-attachment-to-contacts', 'english', 'New Attachment on Task (Sent to Customer Contacts)', 'New Attachment on Task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} added an attachment on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span>{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('51', 'tasks', 'task-commented-to-contacts', 'english', 'New Comment on Task (Sent to Customer Contacts)', 'New Comment on Task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A comment has been made on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Name: &nbsp;{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Description: &nbsp;{task_description}<br />Comment: {task_comment}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('52', 'leads', 'new-lead-assigned', 'english', 'New Lead Assigned to Staff Member', 'New lead assigned to you', '<p>Hello {lead_assigned}</p>\r\n<p>New&nbsp;lead is assigned to you.<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}<br /><br /></a>Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('53', 'client', 'new-client-created', 'catalan', 'New Contact Added/Registered (Welcome Email) [catalan]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('54', 'invoice', 'invoice-send-to-client', 'catalan', 'Send Invoice to Customer [catalan]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('55', 'ticket', 'new-ticket-opened-admin', 'catalan', 'New Ticket Opened (Opened by Staff, Sent to Customer) [catalan]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('56', 'ticket', 'ticket-reply', 'catalan', 'Ticket Reply (Sent to Customer) [catalan]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('57', 'ticket', 'ticket-autoresponse', 'catalan', 'New Ticket Opened - Autoresponse [catalan]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('58', 'invoice', 'invoice-payment-recorded', 'catalan', 'Invoice Payment Recorded (Sent to Customer) [catalan]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('59', 'invoice', 'invoice-overdue-notice', 'catalan', 'Invoice Overdue Notice [catalan]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('60', 'invoice', 'invoice-already-send', 'catalan', 'Invoice Already Sent to Customer [catalan]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('61', 'ticket', 'new-ticket-created-staff', 'catalan', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [catalan]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('62', 'estimate', 'estimate-send-to-client', 'catalan', 'Send Estimate to Customer [catalan]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('63', 'ticket', 'ticket-reply-to-admin', 'catalan', 'Ticket Reply (Sent to Staff) [catalan]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('64', 'estimate', 'estimate-already-send', 'catalan', 'Estimate Already Sent to Customer [catalan]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('65', 'contract', 'contract-expiration', 'catalan', 'Contract Expiration [catalan]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('66', 'tasks', 'task-assigned', 'catalan', 'New Task Assigned (Sent to Staff) [catalan]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('67', 'tasks', 'task-added-as-follower', 'catalan', 'Staff Member Added as Follower on Task [catalan]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('68', 'tasks', 'task-commented', 'catalan', 'New Comment on Task (Sent to Staff) [catalan]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('69', 'tasks', 'task-marked-as-finished', 'catalan', 'Task Marked as Finished (Sent to Staff) [catalan]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('70', 'tasks', 'task-added-attachment', 'catalan', 'New Attachment on Task (Sent to Staff) [catalan]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('71', 'tasks', 'task-unmarked-as-finished', 'catalan', 'Task Unmarked as Finished (Sent to Staff) [catalan]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('72', 'estimate', 'estimate-declined-to-staff', 'catalan', 'Estimate Declined (Sent to Staff) [catalan]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('73', 'estimate', 'estimate-accepted-to-staff', 'catalan', 'Estimate Accepted (Sent to Staff) [catalan]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('74', 'proposals', 'proposal-client-accepted', 'catalan', 'Customer Action - Accepted (Sent to Staff) [catalan]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('75', 'proposals', 'proposal-send-to-customer', 'catalan', 'Send Proposal to Customer [catalan]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('76', 'proposals', 'proposal-client-declined', 'catalan', 'Customer Action - Declined (Sent to Staff) [catalan]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('77', 'proposals', 'proposal-client-thank-you', 'catalan', 'Thank You Email (Sent to Customer After Accept) [catalan]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('78', 'proposals', 'proposal-comment-to-client', 'catalan', 'New Comment  (Sent to Customer Contacts) [catalan]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('79', 'proposals', 'proposal-comment-to-admin', 'catalan', 'New Comment (Sent to Staff)  [catalan]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('80', 'estimate', 'estimate-thank-you-to-customer', 'catalan', 'Thank You Email (Sent to Customer After Accept) [catalan]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('81', 'tasks', 'task-deadline-notification', 'catalan', 'Task Deadline Reminder - Sent to Assigned Members [catalan]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('82', 'contract', 'send-contract', 'catalan', 'Send Contract to Customer [catalan]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('83', 'invoice', 'invoice-payment-recorded-to-staff', 'catalan', 'Invoice Payment Recorded (Sent to Staff) [catalan]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('84', 'ticket', 'auto-close-ticket', 'catalan', 'Auto Close Ticket [catalan]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('85', 'project', 'new-project-discussion-created-to-staff', 'catalan', 'New Project Discussion (Sent to Project Members) [catalan]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('86', 'project', 'new-project-discussion-created-to-customer', 'catalan', 'New Project Discussion (Sent to Customer Contacts) [catalan]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('87', 'project', 'new-project-file-uploaded-to-customer', 'catalan', 'New Project File Uploaded (Sent to Customer Contacts) [catalan]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('88', 'project', 'new-project-file-uploaded-to-staff', 'catalan', 'New Project File Uploaded (Sent to Project Members) [catalan]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('89', 'project', 'new-project-discussion-comment-to-customer', 'catalan', 'New Discussion Comment  (Sent to Customer Contacts) [catalan]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('90', 'project', 'new-project-discussion-comment-to-staff', 'catalan', 'New Discussion Comment (Sent to Project Members) [catalan]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('91', 'project', 'staff-added-as-project-member', 'catalan', 'Staff Added as Project Member [catalan]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('92', 'estimate', 'estimate-expiry-reminder', 'catalan', 'Estimate Expiration Reminder [catalan]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('93', 'proposals', 'proposal-expiry-reminder', 'catalan', 'Proposal Expiration Reminder [catalan]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('94', 'staff', 'new-staff-created', 'catalan', 'New Staff Created (Welcome Email) [catalan]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('95', 'client', 'contact-forgot-password', 'catalan', 'Forgot Password [catalan]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('96', 'client', 'contact-password-reseted', 'catalan', 'Password Reset - Confirmation [catalan]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('97', 'client', 'contact-set-password', 'catalan', 'Set New Password [catalan]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('98', 'staff', 'staff-forgot-password', 'catalan', 'Forgot Password [catalan]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('99', 'staff', 'staff-password-reseted', 'catalan', 'Password Reset - Confirmation [catalan]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('100', 'project', 'assigned-to-project', 'catalan', 'New Project Created (Sent to Customer Contacts) [catalan]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('101', 'tasks', 'task-marked-as-finished-to-contacts', 'catalan', 'Task Marked as Finished (Sent to customer contacts) [catalan]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('102', 'tasks', 'task-added-attachment-to-contacts', 'catalan', 'New Attachment on Task (Sent to Customer Contacts) [catalan]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('103', 'tasks', 'task-commented-to-contacts', 'catalan', 'New Comment on Task (Sent to Customer Contacts) [catalan]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('104', 'leads', 'new-lead-assigned', 'catalan', 'New Lead Assigned to Staff Member [catalan]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('105', 'client', 'new-client-created', 'chinese', 'New Contact Added/Registered (Welcome Email) [chinese]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('106', 'invoice', 'invoice-send-to-client', 'chinese', 'Send Invoice to Customer [chinese]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('107', 'ticket', 'new-ticket-opened-admin', 'chinese', 'New Ticket Opened (Opened by Staff, Sent to Customer) [chinese]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('108', 'ticket', 'ticket-reply', 'chinese', 'Ticket Reply (Sent to Customer) [chinese]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('109', 'ticket', 'ticket-autoresponse', 'chinese', 'New Ticket Opened - Autoresponse [chinese]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('110', 'invoice', 'invoice-payment-recorded', 'chinese', 'Invoice Payment Recorded (Sent to Customer) [chinese]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('111', 'invoice', 'invoice-overdue-notice', 'chinese', 'Invoice Overdue Notice [chinese]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('112', 'invoice', 'invoice-already-send', 'chinese', 'Invoice Already Sent to Customer [chinese]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('113', 'ticket', 'new-ticket-created-staff', 'chinese', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [chinese]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('114', 'estimate', 'estimate-send-to-client', 'chinese', 'Send Estimate to Customer [chinese]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('115', 'ticket', 'ticket-reply-to-admin', 'chinese', 'Ticket Reply (Sent to Staff) [chinese]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('116', 'estimate', 'estimate-already-send', 'chinese', 'Estimate Already Sent to Customer [chinese]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('117', 'contract', 'contract-expiration', 'chinese', 'Contract Expiration [chinese]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('118', 'tasks', 'task-assigned', 'chinese', 'New Task Assigned (Sent to Staff) [chinese]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('119', 'tasks', 'task-added-as-follower', 'chinese', 'Staff Member Added as Follower on Task [chinese]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('120', 'tasks', 'task-commented', 'chinese', 'New Comment on Task (Sent to Staff) [chinese]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('121', 'tasks', 'task-marked-as-finished', 'chinese', 'Task Marked as Finished (Sent to Staff) [chinese]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('122', 'tasks', 'task-added-attachment', 'chinese', 'New Attachment on Task (Sent to Staff) [chinese]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('123', 'tasks', 'task-unmarked-as-finished', 'chinese', 'Task Unmarked as Finished (Sent to Staff) [chinese]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('124', 'estimate', 'estimate-declined-to-staff', 'chinese', 'Estimate Declined (Sent to Staff) [chinese]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('125', 'estimate', 'estimate-accepted-to-staff', 'chinese', 'Estimate Accepted (Sent to Staff) [chinese]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('126', 'proposals', 'proposal-client-accepted', 'chinese', 'Customer Action - Accepted (Sent to Staff) [chinese]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('127', 'proposals', 'proposal-send-to-customer', 'chinese', 'Send Proposal to Customer [chinese]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('128', 'proposals', 'proposal-client-declined', 'chinese', 'Customer Action - Declined (Sent to Staff) [chinese]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('129', 'proposals', 'proposal-client-thank-you', 'chinese', 'Thank You Email (Sent to Customer After Accept) [chinese]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('130', 'proposals', 'proposal-comment-to-client', 'chinese', 'New Comment  (Sent to Customer Contacts) [chinese]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('131', 'proposals', 'proposal-comment-to-admin', 'chinese', 'New Comment (Sent to Staff)  [chinese]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('132', 'estimate', 'estimate-thank-you-to-customer', 'chinese', 'Thank You Email (Sent to Customer After Accept) [chinese]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('133', 'tasks', 'task-deadline-notification', 'chinese', 'Task Deadline Reminder - Sent to Assigned Members [chinese]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('134', 'contract', 'send-contract', 'chinese', 'Send Contract to Customer [chinese]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('135', 'invoice', 'invoice-payment-recorded-to-staff', 'chinese', 'Invoice Payment Recorded (Sent to Staff) [chinese]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('136', 'ticket', 'auto-close-ticket', 'chinese', 'Auto Close Ticket [chinese]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('137', 'project', 'new-project-discussion-created-to-staff', 'chinese', 'New Project Discussion (Sent to Project Members) [chinese]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('138', 'project', 'new-project-discussion-created-to-customer', 'chinese', 'New Project Discussion (Sent to Customer Contacts) [chinese]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('139', 'project', 'new-project-file-uploaded-to-customer', 'chinese', 'New Project File Uploaded (Sent to Customer Contacts) [chinese]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('140', 'project', 'new-project-file-uploaded-to-staff', 'chinese', 'New Project File Uploaded (Sent to Project Members) [chinese]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('141', 'project', 'new-project-discussion-comment-to-customer', 'chinese', 'New Discussion Comment  (Sent to Customer Contacts) [chinese]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('142', 'project', 'new-project-discussion-comment-to-staff', 'chinese', 'New Discussion Comment (Sent to Project Members) [chinese]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('143', 'project', 'staff-added-as-project-member', 'chinese', 'Staff Added as Project Member [chinese]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('144', 'estimate', 'estimate-expiry-reminder', 'chinese', 'Estimate Expiration Reminder [chinese]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('145', 'proposals', 'proposal-expiry-reminder', 'chinese', 'Proposal Expiration Reminder [chinese]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('146', 'staff', 'new-staff-created', 'chinese', 'New Staff Created (Welcome Email) [chinese]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('147', 'client', 'contact-forgot-password', 'chinese', 'Forgot Password [chinese]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('148', 'client', 'contact-password-reseted', 'chinese', 'Password Reset - Confirmation [chinese]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('149', 'client', 'contact-set-password', 'chinese', 'Set New Password [chinese]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('150', 'staff', 'staff-forgot-password', 'chinese', 'Forgot Password [chinese]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('151', 'staff', 'staff-password-reseted', 'chinese', 'Password Reset - Confirmation [chinese]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('152', 'project', 'assigned-to-project', 'chinese', 'New Project Created (Sent to Customer Contacts) [chinese]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('153', 'tasks', 'task-marked-as-finished-to-contacts', 'chinese', 'Task Marked as Finished (Sent to customer contacts) [chinese]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('154', 'tasks', 'task-added-attachment-to-contacts', 'chinese', 'New Attachment on Task (Sent to Customer Contacts) [chinese]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('155', 'tasks', 'task-commented-to-contacts', 'chinese', 'New Comment on Task (Sent to Customer Contacts) [chinese]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('156', 'leads', 'new-lead-assigned', 'chinese', 'New Lead Assigned to Staff Member [chinese]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('157', 'client', 'new-client-created', 'dutch', 'New Contact Added/Registered (Welcome Email) [dutch]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('158', 'invoice', 'invoice-send-to-client', 'dutch', 'Send Invoice to Customer [dutch]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('159', 'ticket', 'new-ticket-opened-admin', 'dutch', 'New Ticket Opened (Opened by Staff, Sent to Customer) [dutch]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('160', 'ticket', 'ticket-reply', 'dutch', 'Ticket Reply (Sent to Customer) [dutch]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('161', 'ticket', 'ticket-autoresponse', 'dutch', 'New Ticket Opened - Autoresponse [dutch]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('162', 'invoice', 'invoice-payment-recorded', 'dutch', 'Invoice Payment Recorded (Sent to Customer) [dutch]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('163', 'invoice', 'invoice-overdue-notice', 'dutch', 'Invoice Overdue Notice [dutch]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('164', 'invoice', 'invoice-already-send', 'dutch', 'Invoice Already Sent to Customer [dutch]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('165', 'ticket', 'new-ticket-created-staff', 'dutch', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [dutch]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('166', 'estimate', 'estimate-send-to-client', 'dutch', 'Send Estimate to Customer [dutch]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('167', 'ticket', 'ticket-reply-to-admin', 'dutch', 'Ticket Reply (Sent to Staff) [dutch]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('168', 'estimate', 'estimate-already-send', 'dutch', 'Estimate Already Sent to Customer [dutch]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('169', 'contract', 'contract-expiration', 'dutch', 'Contract Expiration [dutch]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('170', 'tasks', 'task-assigned', 'dutch', 'New Task Assigned (Sent to Staff) [dutch]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('171', 'tasks', 'task-added-as-follower', 'dutch', 'Staff Member Added as Follower on Task [dutch]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('172', 'tasks', 'task-commented', 'dutch', 'New Comment on Task (Sent to Staff) [dutch]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('173', 'tasks', 'task-marked-as-finished', 'dutch', 'Task Marked as Finished (Sent to Staff) [dutch]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('174', 'tasks', 'task-added-attachment', 'dutch', 'New Attachment on Task (Sent to Staff) [dutch]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('175', 'tasks', 'task-unmarked-as-finished', 'dutch', 'Task Unmarked as Finished (Sent to Staff) [dutch]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('176', 'estimate', 'estimate-declined-to-staff', 'dutch', 'Estimate Declined (Sent to Staff) [dutch]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('177', 'estimate', 'estimate-accepted-to-staff', 'dutch', 'Estimate Accepted (Sent to Staff) [dutch]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('178', 'proposals', 'proposal-client-accepted', 'dutch', 'Customer Action - Accepted (Sent to Staff) [dutch]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('179', 'proposals', 'proposal-send-to-customer', 'dutch', 'Send Proposal to Customer [dutch]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('180', 'proposals', 'proposal-client-declined', 'dutch', 'Customer Action - Declined (Sent to Staff) [dutch]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('181', 'proposals', 'proposal-client-thank-you', 'dutch', 'Thank You Email (Sent to Customer After Accept) [dutch]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('182', 'proposals', 'proposal-comment-to-client', 'dutch', 'New Comment  (Sent to Customer Contacts) [dutch]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('183', 'proposals', 'proposal-comment-to-admin', 'dutch', 'New Comment (Sent to Staff)  [dutch]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('184', 'estimate', 'estimate-thank-you-to-customer', 'dutch', 'Thank You Email (Sent to Customer After Accept) [dutch]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('185', 'tasks', 'task-deadline-notification', 'dutch', 'Task Deadline Reminder - Sent to Assigned Members [dutch]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('186', 'contract', 'send-contract', 'dutch', 'Send Contract to Customer [dutch]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('187', 'invoice', 'invoice-payment-recorded-to-staff', 'dutch', 'Invoice Payment Recorded (Sent to Staff) [dutch]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('188', 'ticket', 'auto-close-ticket', 'dutch', 'Auto Close Ticket [dutch]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('189', 'project', 'new-project-discussion-created-to-staff', 'dutch', 'New Project Discussion (Sent to Project Members) [dutch]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('190', 'project', 'new-project-discussion-created-to-customer', 'dutch', 'New Project Discussion (Sent to Customer Contacts) [dutch]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('191', 'project', 'new-project-file-uploaded-to-customer', 'dutch', 'New Project File Uploaded (Sent to Customer Contacts) [dutch]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('192', 'project', 'new-project-file-uploaded-to-staff', 'dutch', 'New Project File Uploaded (Sent to Project Members) [dutch]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('193', 'project', 'new-project-discussion-comment-to-customer', 'dutch', 'New Discussion Comment  (Sent to Customer Contacts) [dutch]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('194', 'project', 'new-project-discussion-comment-to-staff', 'dutch', 'New Discussion Comment (Sent to Project Members) [dutch]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('195', 'project', 'staff-added-as-project-member', 'dutch', 'Staff Added as Project Member [dutch]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('196', 'estimate', 'estimate-expiry-reminder', 'dutch', 'Estimate Expiration Reminder [dutch]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('197', 'proposals', 'proposal-expiry-reminder', 'dutch', 'Proposal Expiration Reminder [dutch]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('198', 'staff', 'new-staff-created', 'dutch', 'New Staff Created (Welcome Email) [dutch]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('199', 'client', 'contact-forgot-password', 'dutch', 'Forgot Password [dutch]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('200', 'client', 'contact-password-reseted', 'dutch', 'Password Reset - Confirmation [dutch]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('201', 'client', 'contact-set-password', 'dutch', 'Set New Password [dutch]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('202', 'staff', 'staff-forgot-password', 'dutch', 'Forgot Password [dutch]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('203', 'staff', 'staff-password-reseted', 'dutch', 'Password Reset - Confirmation [dutch]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('204', 'project', 'assigned-to-project', 'dutch', 'New Project Created (Sent to Customer Contacts) [dutch]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('205', 'tasks', 'task-marked-as-finished-to-contacts', 'dutch', 'Task Marked as Finished (Sent to customer contacts) [dutch]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('206', 'tasks', 'task-added-attachment-to-contacts', 'dutch', 'New Attachment on Task (Sent to Customer Contacts) [dutch]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('207', 'tasks', 'task-commented-to-contacts', 'dutch', 'New Comment on Task (Sent to Customer Contacts) [dutch]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('208', 'leads', 'new-lead-assigned', 'dutch', 'New Lead Assigned to Staff Member [dutch]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('209', 'client', 'new-client-created', 'french', 'New Contact Added/Registered (Welcome Email) [french]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('210', 'invoice', 'invoice-send-to-client', 'french', 'Send Invoice to Customer [french]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('211', 'ticket', 'new-ticket-opened-admin', 'french', 'New Ticket Opened (Opened by Staff, Sent to Customer) [french]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('212', 'ticket', 'ticket-reply', 'french', 'Ticket Reply (Sent to Customer) [french]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('213', 'ticket', 'ticket-autoresponse', 'french', 'New Ticket Opened - Autoresponse [french]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('214', 'invoice', 'invoice-payment-recorded', 'french', 'Invoice Payment Recorded (Sent to Customer) [french]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('215', 'invoice', 'invoice-overdue-notice', 'french', 'Invoice Overdue Notice [french]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('216', 'invoice', 'invoice-already-send', 'french', 'Invoice Already Sent to Customer [french]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('217', 'ticket', 'new-ticket-created-staff', 'french', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [french]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('218', 'estimate', 'estimate-send-to-client', 'french', 'Send Estimate to Customer [french]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('219', 'ticket', 'ticket-reply-to-admin', 'french', 'Ticket Reply (Sent to Staff) [french]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('220', 'estimate', 'estimate-already-send', 'french', 'Estimate Already Sent to Customer [french]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('221', 'contract', 'contract-expiration', 'french', 'Contract Expiration [french]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('222', 'tasks', 'task-assigned', 'french', 'New Task Assigned (Sent to Staff) [french]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('223', 'tasks', 'task-added-as-follower', 'french', 'Staff Member Added as Follower on Task [french]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('224', 'tasks', 'task-commented', 'french', 'New Comment on Task (Sent to Staff) [french]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('225', 'tasks', 'task-marked-as-finished', 'french', 'Task Marked as Finished (Sent to Staff) [french]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('226', 'tasks', 'task-added-attachment', 'french', 'New Attachment on Task (Sent to Staff) [french]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('227', 'tasks', 'task-unmarked-as-finished', 'french', 'Task Unmarked as Finished (Sent to Staff) [french]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('228', 'estimate', 'estimate-declined-to-staff', 'french', 'Estimate Declined (Sent to Staff) [french]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('229', 'estimate', 'estimate-accepted-to-staff', 'french', 'Estimate Accepted (Sent to Staff) [french]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('230', 'proposals', 'proposal-client-accepted', 'french', 'Customer Action - Accepted (Sent to Staff) [french]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('231', 'proposals', 'proposal-send-to-customer', 'french', 'Send Proposal to Customer [french]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('232', 'proposals', 'proposal-client-declined', 'french', 'Customer Action - Declined (Sent to Staff) [french]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('233', 'proposals', 'proposal-client-thank-you', 'french', 'Thank You Email (Sent to Customer After Accept) [french]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('234', 'proposals', 'proposal-comment-to-client', 'french', 'New Comment  (Sent to Customer Contacts) [french]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('235', 'proposals', 'proposal-comment-to-admin', 'french', 'New Comment (Sent to Staff)  [french]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('236', 'estimate', 'estimate-thank-you-to-customer', 'french', 'Thank You Email (Sent to Customer After Accept) [french]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('237', 'tasks', 'task-deadline-notification', 'french', 'Task Deadline Reminder - Sent to Assigned Members [french]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('238', 'contract', 'send-contract', 'french', 'Send Contract to Customer [french]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('239', 'invoice', 'invoice-payment-recorded-to-staff', 'french', 'Invoice Payment Recorded (Sent to Staff) [french]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('240', 'ticket', 'auto-close-ticket', 'french', 'Auto Close Ticket [french]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('241', 'project', 'new-project-discussion-created-to-staff', 'french', 'New Project Discussion (Sent to Project Members) [french]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('242', 'project', 'new-project-discussion-created-to-customer', 'french', 'New Project Discussion (Sent to Customer Contacts) [french]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('243', 'project', 'new-project-file-uploaded-to-customer', 'french', 'New Project File Uploaded (Sent to Customer Contacts) [french]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('244', 'project', 'new-project-file-uploaded-to-staff', 'french', 'New Project File Uploaded (Sent to Project Members) [french]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('245', 'project', 'new-project-discussion-comment-to-customer', 'french', 'New Discussion Comment  (Sent to Customer Contacts) [french]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('246', 'project', 'new-project-discussion-comment-to-staff', 'french', 'New Discussion Comment (Sent to Project Members) [french]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('247', 'project', 'staff-added-as-project-member', 'french', 'Staff Added as Project Member [french]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('248', 'estimate', 'estimate-expiry-reminder', 'french', 'Estimate Expiration Reminder [french]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('249', 'proposals', 'proposal-expiry-reminder', 'french', 'Proposal Expiration Reminder [french]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('250', 'staff', 'new-staff-created', 'french', 'New Staff Created (Welcome Email) [french]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('251', 'client', 'contact-forgot-password', 'french', 'Forgot Password [french]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('252', 'client', 'contact-password-reseted', 'french', 'Password Reset - Confirmation [french]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('253', 'client', 'contact-set-password', 'french', 'Set New Password [french]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('254', 'staff', 'staff-forgot-password', 'french', 'Forgot Password [french]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('255', 'staff', 'staff-password-reseted', 'french', 'Password Reset - Confirmation [french]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('256', 'project', 'assigned-to-project', 'french', 'New Project Created (Sent to Customer Contacts) [french]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('257', 'tasks', 'task-marked-as-finished-to-contacts', 'french', 'Task Marked as Finished (Sent to customer contacts) [french]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('258', 'tasks', 'task-added-attachment-to-contacts', 'french', 'New Attachment on Task (Sent to Customer Contacts) [french]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('259', 'tasks', 'task-commented-to-contacts', 'french', 'New Comment on Task (Sent to Customer Contacts) [french]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('260', 'leads', 'new-lead-assigned', 'french', 'New Lead Assigned to Staff Member [french]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('261', 'client', 'new-client-created', 'german', 'New Contact Added/Registered (Welcome Email) [german]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('262', 'invoice', 'invoice-send-to-client', 'german', 'Send Invoice to Customer [german]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('263', 'ticket', 'new-ticket-opened-admin', 'german', 'New Ticket Opened (Opened by Staff, Sent to Customer) [german]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('264', 'ticket', 'ticket-reply', 'german', 'Ticket Reply (Sent to Customer) [german]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('265', 'ticket', 'ticket-autoresponse', 'german', 'New Ticket Opened - Autoresponse [german]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('266', 'invoice', 'invoice-payment-recorded', 'german', 'Invoice Payment Recorded (Sent to Customer) [german]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('267', 'invoice', 'invoice-overdue-notice', 'german', 'Invoice Overdue Notice [german]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('268', 'invoice', 'invoice-already-send', 'german', 'Invoice Already Sent to Customer [german]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('269', 'ticket', 'new-ticket-created-staff', 'german', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [german]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('270', 'estimate', 'estimate-send-to-client', 'german', 'Send Estimate to Customer [german]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('271', 'ticket', 'ticket-reply-to-admin', 'german', 'Ticket Reply (Sent to Staff) [german]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('272', 'estimate', 'estimate-already-send', 'german', 'Estimate Already Sent to Customer [german]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('273', 'contract', 'contract-expiration', 'german', 'Contract Expiration [german]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('274', 'tasks', 'task-assigned', 'german', 'New Task Assigned (Sent to Staff) [german]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('275', 'tasks', 'task-added-as-follower', 'german', 'Staff Member Added as Follower on Task [german]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('276', 'tasks', 'task-commented', 'german', 'New Comment on Task (Sent to Staff) [german]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('277', 'tasks', 'task-marked-as-finished', 'german', 'Task Marked as Finished (Sent to Staff) [german]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('278', 'tasks', 'task-added-attachment', 'german', 'New Attachment on Task (Sent to Staff) [german]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('279', 'tasks', 'task-unmarked-as-finished', 'german', 'Task Unmarked as Finished (Sent to Staff) [german]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('280', 'estimate', 'estimate-declined-to-staff', 'german', 'Estimate Declined (Sent to Staff) [german]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('281', 'estimate', 'estimate-accepted-to-staff', 'german', 'Estimate Accepted (Sent to Staff) [german]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('282', 'proposals', 'proposal-client-accepted', 'german', 'Customer Action - Accepted (Sent to Staff) [german]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('283', 'proposals', 'proposal-send-to-customer', 'german', 'Send Proposal to Customer [german]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('284', 'proposals', 'proposal-client-declined', 'german', 'Customer Action - Declined (Sent to Staff) [german]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('285', 'proposals', 'proposal-client-thank-you', 'german', 'Thank You Email (Sent to Customer After Accept) [german]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('286', 'proposals', 'proposal-comment-to-client', 'german', 'New Comment  (Sent to Customer Contacts) [german]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('287', 'proposals', 'proposal-comment-to-admin', 'german', 'New Comment (Sent to Staff)  [german]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('288', 'estimate', 'estimate-thank-you-to-customer', 'german', 'Thank You Email (Sent to Customer After Accept) [german]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('289', 'tasks', 'task-deadline-notification', 'german', 'Task Deadline Reminder - Sent to Assigned Members [german]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('290', 'contract', 'send-contract', 'german', 'Send Contract to Customer [german]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('291', 'invoice', 'invoice-payment-recorded-to-staff', 'german', 'Invoice Payment Recorded (Sent to Staff) [german]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('292', 'ticket', 'auto-close-ticket', 'german', 'Auto Close Ticket [german]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('293', 'project', 'new-project-discussion-created-to-staff', 'german', 'New Project Discussion (Sent to Project Members) [german]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('294', 'project', 'new-project-discussion-created-to-customer', 'german', 'New Project Discussion (Sent to Customer Contacts) [german]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('295', 'project', 'new-project-file-uploaded-to-customer', 'german', 'New Project File Uploaded (Sent to Customer Contacts) [german]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('296', 'project', 'new-project-file-uploaded-to-staff', 'german', 'New Project File Uploaded (Sent to Project Members) [german]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('297', 'project', 'new-project-discussion-comment-to-customer', 'german', 'New Discussion Comment  (Sent to Customer Contacts) [german]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('298', 'project', 'new-project-discussion-comment-to-staff', 'german', 'New Discussion Comment (Sent to Project Members) [german]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('299', 'project', 'staff-added-as-project-member', 'german', 'Staff Added as Project Member [german]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('300', 'estimate', 'estimate-expiry-reminder', 'german', 'Estimate Expiration Reminder [german]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('301', 'proposals', 'proposal-expiry-reminder', 'german', 'Proposal Expiration Reminder [german]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('302', 'staff', 'new-staff-created', 'german', 'New Staff Created (Welcome Email) [german]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('303', 'client', 'contact-forgot-password', 'german', 'Forgot Password [german]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('304', 'client', 'contact-password-reseted', 'german', 'Password Reset - Confirmation [german]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('305', 'client', 'contact-set-password', 'german', 'Set New Password [german]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('306', 'staff', 'staff-forgot-password', 'german', 'Forgot Password [german]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('307', 'staff', 'staff-password-reseted', 'german', 'Password Reset - Confirmation [german]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('308', 'project', 'assigned-to-project', 'german', 'New Project Created (Sent to Customer Contacts) [german]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('309', 'tasks', 'task-marked-as-finished-to-contacts', 'german', 'Task Marked as Finished (Sent to customer contacts) [german]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('310', 'tasks', 'task-added-attachment-to-contacts', 'german', 'New Attachment on Task (Sent to Customer Contacts) [german]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('311', 'tasks', 'task-commented-to-contacts', 'german', 'New Comment on Task (Sent to Customer Contacts) [german]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('312', 'leads', 'new-lead-assigned', 'german', 'New Lead Assigned to Staff Member [german]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('313', 'client', 'new-client-created', 'indonesia', 'New Contact Added/Registered (Welcome Email) [indonesia]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('314', 'invoice', 'invoice-send-to-client', 'indonesia', 'Send Invoice to Customer [indonesia]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('315', 'ticket', 'new-ticket-opened-admin', 'indonesia', 'New Ticket Opened (Opened by Staff, Sent to Customer) [indonesia]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('316', 'ticket', 'ticket-reply', 'indonesia', 'Ticket Reply (Sent to Customer) [indonesia]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('317', 'ticket', 'ticket-autoresponse', 'indonesia', 'New Ticket Opened - Autoresponse [indonesia]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('318', 'invoice', 'invoice-payment-recorded', 'indonesia', 'Invoice Payment Recorded (Sent to Customer) [indonesia]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('319', 'invoice', 'invoice-overdue-notice', 'indonesia', 'Invoice Overdue Notice [indonesia]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('320', 'invoice', 'invoice-already-send', 'indonesia', 'Invoice Already Sent to Customer [indonesia]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('321', 'ticket', 'new-ticket-created-staff', 'indonesia', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [indonesia]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('322', 'estimate', 'estimate-send-to-client', 'indonesia', 'Send Estimate to Customer [indonesia]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('323', 'ticket', 'ticket-reply-to-admin', 'indonesia', 'Ticket Reply (Sent to Staff) [indonesia]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('324', 'estimate', 'estimate-already-send', 'indonesia', 'Estimate Already Sent to Customer [indonesia]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('325', 'contract', 'contract-expiration', 'indonesia', 'Contract Expiration [indonesia]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('326', 'tasks', 'task-assigned', 'indonesia', 'New Task Assigned (Sent to Staff) [indonesia]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('327', 'tasks', 'task-added-as-follower', 'indonesia', 'Staff Member Added as Follower on Task [indonesia]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('328', 'tasks', 'task-commented', 'indonesia', 'New Comment on Task (Sent to Staff) [indonesia]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('329', 'tasks', 'task-marked-as-finished', 'indonesia', 'Task Marked as Finished (Sent to Staff) [indonesia]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('330', 'tasks', 'task-added-attachment', 'indonesia', 'New Attachment on Task (Sent to Staff) [indonesia]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('331', 'tasks', 'task-unmarked-as-finished', 'indonesia', 'Task Unmarked as Finished (Sent to Staff) [indonesia]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('332', 'estimate', 'estimate-declined-to-staff', 'indonesia', 'Estimate Declined (Sent to Staff) [indonesia]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('333', 'estimate', 'estimate-accepted-to-staff', 'indonesia', 'Estimate Accepted (Sent to Staff) [indonesia]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('334', 'proposals', 'proposal-client-accepted', 'indonesia', 'Customer Action - Accepted (Sent to Staff) [indonesia]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('335', 'proposals', 'proposal-send-to-customer', 'indonesia', 'Send Proposal to Customer [indonesia]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('336', 'proposals', 'proposal-client-declined', 'indonesia', 'Customer Action - Declined (Sent to Staff) [indonesia]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('337', 'proposals', 'proposal-client-thank-you', 'indonesia', 'Thank You Email (Sent to Customer After Accept) [indonesia]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('338', 'proposals', 'proposal-comment-to-client', 'indonesia', 'New Comment  (Sent to Customer Contacts) [indonesia]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('339', 'proposals', 'proposal-comment-to-admin', 'indonesia', 'New Comment (Sent to Staff)  [indonesia]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('340', 'estimate', 'estimate-thank-you-to-customer', 'indonesia', 'Thank You Email (Sent to Customer After Accept) [indonesia]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('341', 'tasks', 'task-deadline-notification', 'indonesia', 'Task Deadline Reminder - Sent to Assigned Members [indonesia]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('342', 'contract', 'send-contract', 'indonesia', 'Send Contract to Customer [indonesia]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('343', 'invoice', 'invoice-payment-recorded-to-staff', 'indonesia', 'Invoice Payment Recorded (Sent to Staff) [indonesia]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('344', 'ticket', 'auto-close-ticket', 'indonesia', 'Auto Close Ticket [indonesia]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('345', 'project', 'new-project-discussion-created-to-staff', 'indonesia', 'New Project Discussion (Sent to Project Members) [indonesia]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('346', 'project', 'new-project-discussion-created-to-customer', 'indonesia', 'New Project Discussion (Sent to Customer Contacts) [indonesia]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('347', 'project', 'new-project-file-uploaded-to-customer', 'indonesia', 'New Project File Uploaded (Sent to Customer Contacts) [indonesia]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('348', 'project', 'new-project-file-uploaded-to-staff', 'indonesia', 'New Project File Uploaded (Sent to Project Members) [indonesia]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('349', 'project', 'new-project-discussion-comment-to-customer', 'indonesia', 'New Discussion Comment  (Sent to Customer Contacts) [indonesia]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('350', 'project', 'new-project-discussion-comment-to-staff', 'indonesia', 'New Discussion Comment (Sent to Project Members) [indonesia]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('351', 'project', 'staff-added-as-project-member', 'indonesia', 'Staff Added as Project Member [indonesia]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('352', 'estimate', 'estimate-expiry-reminder', 'indonesia', 'Estimate Expiration Reminder [indonesia]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('353', 'proposals', 'proposal-expiry-reminder', 'indonesia', 'Proposal Expiration Reminder [indonesia]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('354', 'staff', 'new-staff-created', 'indonesia', 'New Staff Created (Welcome Email) [indonesia]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('355', 'client', 'contact-forgot-password', 'indonesia', 'Forgot Password [indonesia]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('356', 'client', 'contact-password-reseted', 'indonesia', 'Password Reset - Confirmation [indonesia]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('357', 'client', 'contact-set-password', 'indonesia', 'Set New Password [indonesia]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('358', 'staff', 'staff-forgot-password', 'indonesia', 'Forgot Password [indonesia]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('359', 'staff', 'staff-password-reseted', 'indonesia', 'Password Reset - Confirmation [indonesia]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('360', 'project', 'assigned-to-project', 'indonesia', 'New Project Created (Sent to Customer Contacts) [indonesia]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('361', 'tasks', 'task-marked-as-finished-to-contacts', 'indonesia', 'Task Marked as Finished (Sent to customer contacts) [indonesia]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('362', 'tasks', 'task-added-attachment-to-contacts', 'indonesia', 'New Attachment on Task (Sent to Customer Contacts) [indonesia]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('363', 'tasks', 'task-commented-to-contacts', 'indonesia', 'New Comment on Task (Sent to Customer Contacts) [indonesia]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('364', 'leads', 'new-lead-assigned', 'indonesia', 'New Lead Assigned to Staff Member [indonesia]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('365', 'client', 'new-client-created', 'italian', 'New Contact Added/Registered (Welcome Email) [italian]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('366', 'invoice', 'invoice-send-to-client', 'italian', 'Send Invoice to Customer [italian]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('367', 'ticket', 'new-ticket-opened-admin', 'italian', 'New Ticket Opened (Opened by Staff, Sent to Customer) [italian]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('368', 'ticket', 'ticket-reply', 'italian', 'Ticket Reply (Sent to Customer) [italian]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('369', 'ticket', 'ticket-autoresponse', 'italian', 'New Ticket Opened - Autoresponse [italian]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('370', 'invoice', 'invoice-payment-recorded', 'italian', 'Invoice Payment Recorded (Sent to Customer) [italian]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('371', 'invoice', 'invoice-overdue-notice', 'italian', 'Invoice Overdue Notice [italian]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('372', 'invoice', 'invoice-already-send', 'italian', 'Invoice Already Sent to Customer [italian]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('373', 'ticket', 'new-ticket-created-staff', 'italian', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [italian]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('374', 'estimate', 'estimate-send-to-client', 'italian', 'Send Estimate to Customer [italian]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('375', 'ticket', 'ticket-reply-to-admin', 'italian', 'Ticket Reply (Sent to Staff) [italian]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('376', 'estimate', 'estimate-already-send', 'italian', 'Estimate Already Sent to Customer [italian]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('377', 'contract', 'contract-expiration', 'italian', 'Contract Expiration [italian]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('378', 'tasks', 'task-assigned', 'italian', 'New Task Assigned (Sent to Staff) [italian]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('379', 'tasks', 'task-added-as-follower', 'italian', 'Staff Member Added as Follower on Task [italian]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('380', 'tasks', 'task-commented', 'italian', 'New Comment on Task (Sent to Staff) [italian]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('381', 'tasks', 'task-marked-as-finished', 'italian', 'Task Marked as Finished (Sent to Staff) [italian]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('382', 'tasks', 'task-added-attachment', 'italian', 'New Attachment on Task (Sent to Staff) [italian]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('383', 'tasks', 'task-unmarked-as-finished', 'italian', 'Task Unmarked as Finished (Sent to Staff) [italian]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('384', 'estimate', 'estimate-declined-to-staff', 'italian', 'Estimate Declined (Sent to Staff) [italian]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('385', 'estimate', 'estimate-accepted-to-staff', 'italian', 'Estimate Accepted (Sent to Staff) [italian]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('386', 'proposals', 'proposal-client-accepted', 'italian', 'Customer Action - Accepted (Sent to Staff) [italian]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('387', 'proposals', 'proposal-send-to-customer', 'italian', 'Send Proposal to Customer [italian]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('388', 'proposals', 'proposal-client-declined', 'italian', 'Customer Action - Declined (Sent to Staff) [italian]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('389', 'proposals', 'proposal-client-thank-you', 'italian', 'Thank You Email (Sent to Customer After Accept) [italian]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('390', 'proposals', 'proposal-comment-to-client', 'italian', 'New Comment  (Sent to Customer Contacts) [italian]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('391', 'proposals', 'proposal-comment-to-admin', 'italian', 'New Comment (Sent to Staff)  [italian]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('392', 'estimate', 'estimate-thank-you-to-customer', 'italian', 'Thank You Email (Sent to Customer After Accept) [italian]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('393', 'tasks', 'task-deadline-notification', 'italian', 'Task Deadline Reminder - Sent to Assigned Members [italian]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('394', 'contract', 'send-contract', 'italian', 'Send Contract to Customer [italian]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('395', 'invoice', 'invoice-payment-recorded-to-staff', 'italian', 'Invoice Payment Recorded (Sent to Staff) [italian]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('396', 'ticket', 'auto-close-ticket', 'italian', 'Auto Close Ticket [italian]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('397', 'project', 'new-project-discussion-created-to-staff', 'italian', 'New Project Discussion (Sent to Project Members) [italian]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('398', 'project', 'new-project-discussion-created-to-customer', 'italian', 'New Project Discussion (Sent to Customer Contacts) [italian]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('399', 'project', 'new-project-file-uploaded-to-customer', 'italian', 'New Project File Uploaded (Sent to Customer Contacts) [italian]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('400', 'project', 'new-project-file-uploaded-to-staff', 'italian', 'New Project File Uploaded (Sent to Project Members) [italian]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('401', 'project', 'new-project-discussion-comment-to-customer', 'italian', 'New Discussion Comment  (Sent to Customer Contacts) [italian]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('402', 'project', 'new-project-discussion-comment-to-staff', 'italian', 'New Discussion Comment (Sent to Project Members) [italian]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('403', 'project', 'staff-added-as-project-member', 'italian', 'Staff Added as Project Member [italian]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('404', 'estimate', 'estimate-expiry-reminder', 'italian', 'Estimate Expiration Reminder [italian]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('405', 'proposals', 'proposal-expiry-reminder', 'italian', 'Proposal Expiration Reminder [italian]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('406', 'staff', 'new-staff-created', 'italian', 'New Staff Created (Welcome Email) [italian]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('407', 'client', 'contact-forgot-password', 'italian', 'Forgot Password [italian]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('408', 'client', 'contact-password-reseted', 'italian', 'Password Reset - Confirmation [italian]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('409', 'client', 'contact-set-password', 'italian', 'Set New Password [italian]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('410', 'staff', 'staff-forgot-password', 'italian', 'Forgot Password [italian]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('411', 'staff', 'staff-password-reseted', 'italian', 'Password Reset - Confirmation [italian]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('412', 'project', 'assigned-to-project', 'italian', 'New Project Created (Sent to Customer Contacts) [italian]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('413', 'tasks', 'task-marked-as-finished-to-contacts', 'italian', 'Task Marked as Finished (Sent to customer contacts) [italian]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('414', 'tasks', 'task-added-attachment-to-contacts', 'italian', 'New Attachment on Task (Sent to Customer Contacts) [italian]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('415', 'tasks', 'task-commented-to-contacts', 'italian', 'New Comment on Task (Sent to Customer Contacts) [italian]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('416', 'leads', 'new-lead-assigned', 'italian', 'New Lead Assigned to Staff Member [italian]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('417', 'client', 'new-client-created', 'persian', 'New Contact Added/Registered (Welcome Email) [persian]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('418', 'invoice', 'invoice-send-to-client', 'persian', 'Send Invoice to Customer [persian]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('419', 'ticket', 'new-ticket-opened-admin', 'persian', 'New Ticket Opened (Opened by Staff, Sent to Customer) [persian]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('420', 'ticket', 'ticket-reply', 'persian', 'Ticket Reply (Sent to Customer) [persian]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('421', 'ticket', 'ticket-autoresponse', 'persian', 'New Ticket Opened - Autoresponse [persian]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('422', 'invoice', 'invoice-payment-recorded', 'persian', 'Invoice Payment Recorded (Sent to Customer) [persian]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('423', 'invoice', 'invoice-overdue-notice', 'persian', 'Invoice Overdue Notice [persian]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('424', 'invoice', 'invoice-already-send', 'persian', 'Invoice Already Sent to Customer [persian]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('425', 'ticket', 'new-ticket-created-staff', 'persian', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [persian]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('426', 'estimate', 'estimate-send-to-client', 'persian', 'Send Estimate to Customer [persian]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('427', 'ticket', 'ticket-reply-to-admin', 'persian', 'Ticket Reply (Sent to Staff) [persian]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('428', 'estimate', 'estimate-already-send', 'persian', 'Estimate Already Sent to Customer [persian]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('429', 'contract', 'contract-expiration', 'persian', 'Contract Expiration [persian]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('430', 'tasks', 'task-assigned', 'persian', 'New Task Assigned (Sent to Staff) [persian]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('431', 'tasks', 'task-added-as-follower', 'persian', 'Staff Member Added as Follower on Task [persian]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('432', 'tasks', 'task-commented', 'persian', 'New Comment on Task (Sent to Staff) [persian]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('433', 'tasks', 'task-marked-as-finished', 'persian', 'Task Marked as Finished (Sent to Staff) [persian]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('434', 'tasks', 'task-added-attachment', 'persian', 'New Attachment on Task (Sent to Staff) [persian]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('435', 'tasks', 'task-unmarked-as-finished', 'persian', 'Task Unmarked as Finished (Sent to Staff) [persian]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('436', 'estimate', 'estimate-declined-to-staff', 'persian', 'Estimate Declined (Sent to Staff) [persian]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('437', 'estimate', 'estimate-accepted-to-staff', 'persian', 'Estimate Accepted (Sent to Staff) [persian]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('438', 'proposals', 'proposal-client-accepted', 'persian', 'Customer Action - Accepted (Sent to Staff) [persian]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('439', 'proposals', 'proposal-send-to-customer', 'persian', 'Send Proposal to Customer [persian]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('440', 'proposals', 'proposal-client-declined', 'persian', 'Customer Action - Declined (Sent to Staff) [persian]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('441', 'proposals', 'proposal-client-thank-you', 'persian', 'Thank You Email (Sent to Customer After Accept) [persian]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('442', 'proposals', 'proposal-comment-to-client', 'persian', 'New Comment  (Sent to Customer Contacts) [persian]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('443', 'proposals', 'proposal-comment-to-admin', 'persian', 'New Comment (Sent to Staff)  [persian]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('444', 'estimate', 'estimate-thank-you-to-customer', 'persian', 'Thank You Email (Sent to Customer After Accept) [persian]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('445', 'tasks', 'task-deadline-notification', 'persian', 'Task Deadline Reminder - Sent to Assigned Members [persian]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('446', 'contract', 'send-contract', 'persian', 'Send Contract to Customer [persian]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('447', 'invoice', 'invoice-payment-recorded-to-staff', 'persian', 'Invoice Payment Recorded (Sent to Staff) [persian]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('448', 'ticket', 'auto-close-ticket', 'persian', 'Auto Close Ticket [persian]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('449', 'project', 'new-project-discussion-created-to-staff', 'persian', 'New Project Discussion (Sent to Project Members) [persian]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('450', 'project', 'new-project-discussion-created-to-customer', 'persian', 'New Project Discussion (Sent to Customer Contacts) [persian]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('451', 'project', 'new-project-file-uploaded-to-customer', 'persian', 'New Project File Uploaded (Sent to Customer Contacts) [persian]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('452', 'project', 'new-project-file-uploaded-to-staff', 'persian', 'New Project File Uploaded (Sent to Project Members) [persian]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('453', 'project', 'new-project-discussion-comment-to-customer', 'persian', 'New Discussion Comment  (Sent to Customer Contacts) [persian]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('454', 'project', 'new-project-discussion-comment-to-staff', 'persian', 'New Discussion Comment (Sent to Project Members) [persian]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('455', 'project', 'staff-added-as-project-member', 'persian', 'Staff Added as Project Member [persian]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('456', 'estimate', 'estimate-expiry-reminder', 'persian', 'Estimate Expiration Reminder [persian]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('457', 'proposals', 'proposal-expiry-reminder', 'persian', 'Proposal Expiration Reminder [persian]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('458', 'staff', 'new-staff-created', 'persian', 'New Staff Created (Welcome Email) [persian]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('459', 'client', 'contact-forgot-password', 'persian', 'Forgot Password [persian]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('460', 'client', 'contact-password-reseted', 'persian', 'Password Reset - Confirmation [persian]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('461', 'client', 'contact-set-password', 'persian', 'Set New Password [persian]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('462', 'staff', 'staff-forgot-password', 'persian', 'Forgot Password [persian]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('463', 'staff', 'staff-password-reseted', 'persian', 'Password Reset - Confirmation [persian]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('464', 'project', 'assigned-to-project', 'persian', 'New Project Created (Sent to Customer Contacts) [persian]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('465', 'tasks', 'task-marked-as-finished-to-contacts', 'persian', 'Task Marked as Finished (Sent to customer contacts) [persian]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('466', 'tasks', 'task-added-attachment-to-contacts', 'persian', 'New Attachment on Task (Sent to Customer Contacts) [persian]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('467', 'tasks', 'task-commented-to-contacts', 'persian', 'New Comment on Task (Sent to Customer Contacts) [persian]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('468', 'leads', 'new-lead-assigned', 'persian', 'New Lead Assigned to Staff Member [persian]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('469', 'client', 'new-client-created', 'polish', 'New Contact Added/Registered (Welcome Email) [polish]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('470', 'invoice', 'invoice-send-to-client', 'polish', 'Send Invoice to Customer [polish]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('471', 'ticket', 'new-ticket-opened-admin', 'polish', 'New Ticket Opened (Opened by Staff, Sent to Customer) [polish]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('472', 'ticket', 'ticket-reply', 'polish', 'Ticket Reply (Sent to Customer) [polish]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('473', 'ticket', 'ticket-autoresponse', 'polish', 'New Ticket Opened - Autoresponse [polish]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('474', 'invoice', 'invoice-payment-recorded', 'polish', 'Invoice Payment Recorded (Sent to Customer) [polish]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('475', 'invoice', 'invoice-overdue-notice', 'polish', 'Invoice Overdue Notice [polish]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('476', 'invoice', 'invoice-already-send', 'polish', 'Invoice Already Sent to Customer [polish]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('477', 'ticket', 'new-ticket-created-staff', 'polish', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [polish]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('478', 'estimate', 'estimate-send-to-client', 'polish', 'Send Estimate to Customer [polish]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('479', 'ticket', 'ticket-reply-to-admin', 'polish', 'Ticket Reply (Sent to Staff) [polish]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('480', 'estimate', 'estimate-already-send', 'polish', 'Estimate Already Sent to Customer [polish]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('481', 'contract', 'contract-expiration', 'polish', 'Contract Expiration [polish]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('482', 'tasks', 'task-assigned', 'polish', 'New Task Assigned (Sent to Staff) [polish]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('483', 'tasks', 'task-added-as-follower', 'polish', 'Staff Member Added as Follower on Task [polish]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('484', 'tasks', 'task-commented', 'polish', 'New Comment on Task (Sent to Staff) [polish]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('485', 'tasks', 'task-marked-as-finished', 'polish', 'Task Marked as Finished (Sent to Staff) [polish]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('486', 'tasks', 'task-added-attachment', 'polish', 'New Attachment on Task (Sent to Staff) [polish]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('487', 'tasks', 'task-unmarked-as-finished', 'polish', 'Task Unmarked as Finished (Sent to Staff) [polish]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('488', 'estimate', 'estimate-declined-to-staff', 'polish', 'Estimate Declined (Sent to Staff) [polish]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('489', 'estimate', 'estimate-accepted-to-staff', 'polish', 'Estimate Accepted (Sent to Staff) [polish]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('490', 'proposals', 'proposal-client-accepted', 'polish', 'Customer Action - Accepted (Sent to Staff) [polish]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('491', 'proposals', 'proposal-send-to-customer', 'polish', 'Send Proposal to Customer [polish]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('492', 'proposals', 'proposal-client-declined', 'polish', 'Customer Action - Declined (Sent to Staff) [polish]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('493', 'proposals', 'proposal-client-thank-you', 'polish', 'Thank You Email (Sent to Customer After Accept) [polish]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('494', 'proposals', 'proposal-comment-to-client', 'polish', 'New Comment  (Sent to Customer Contacts) [polish]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('495', 'proposals', 'proposal-comment-to-admin', 'polish', 'New Comment (Sent to Staff)  [polish]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('496', 'estimate', 'estimate-thank-you-to-customer', 'polish', 'Thank You Email (Sent to Customer After Accept) [polish]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('497', 'tasks', 'task-deadline-notification', 'polish', 'Task Deadline Reminder - Sent to Assigned Members [polish]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('498', 'contract', 'send-contract', 'polish', 'Send Contract to Customer [polish]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('499', 'invoice', 'invoice-payment-recorded-to-staff', 'polish', 'Invoice Payment Recorded (Sent to Staff) [polish]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('500', 'ticket', 'auto-close-ticket', 'polish', 'Auto Close Ticket [polish]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('501', 'project', 'new-project-discussion-created-to-staff', 'polish', 'New Project Discussion (Sent to Project Members) [polish]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('502', 'project', 'new-project-discussion-created-to-customer', 'polish', 'New Project Discussion (Sent to Customer Contacts) [polish]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('503', 'project', 'new-project-file-uploaded-to-customer', 'polish', 'New Project File Uploaded (Sent to Customer Contacts) [polish]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('504', 'project', 'new-project-file-uploaded-to-staff', 'polish', 'New Project File Uploaded (Sent to Project Members) [polish]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('505', 'project', 'new-project-discussion-comment-to-customer', 'polish', 'New Discussion Comment  (Sent to Customer Contacts) [polish]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('506', 'project', 'new-project-discussion-comment-to-staff', 'polish', 'New Discussion Comment (Sent to Project Members) [polish]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('507', 'project', 'staff-added-as-project-member', 'polish', 'Staff Added as Project Member [polish]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('508', 'estimate', 'estimate-expiry-reminder', 'polish', 'Estimate Expiration Reminder [polish]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('509', 'proposals', 'proposal-expiry-reminder', 'polish', 'Proposal Expiration Reminder [polish]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('510', 'staff', 'new-staff-created', 'polish', 'New Staff Created (Welcome Email) [polish]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('511', 'client', 'contact-forgot-password', 'polish', 'Forgot Password [polish]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('512', 'client', 'contact-password-reseted', 'polish', 'Password Reset - Confirmation [polish]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('513', 'client', 'contact-set-password', 'polish', 'Set New Password [polish]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('514', 'staff', 'staff-forgot-password', 'polish', 'Forgot Password [polish]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('515', 'staff', 'staff-password-reseted', 'polish', 'Password Reset - Confirmation [polish]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('516', 'project', 'assigned-to-project', 'polish', 'New Project Created (Sent to Customer Contacts) [polish]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('517', 'tasks', 'task-marked-as-finished-to-contacts', 'polish', 'Task Marked as Finished (Sent to customer contacts) [polish]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('518', 'tasks', 'task-added-attachment-to-contacts', 'polish', 'New Attachment on Task (Sent to Customer Contacts) [polish]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('519', 'tasks', 'task-commented-to-contacts', 'polish', 'New Comment on Task (Sent to Customer Contacts) [polish]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('520', 'leads', 'new-lead-assigned', 'polish', 'New Lead Assigned to Staff Member [polish]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('521', 'client', 'new-client-created', 'portuguese', 'New Contact Added/Registered (Welcome Email) [portuguese]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('522', 'invoice', 'invoice-send-to-client', 'portuguese', 'Send Invoice to Customer [portuguese]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('523', 'ticket', 'new-ticket-opened-admin', 'portuguese', 'New Ticket Opened (Opened by Staff, Sent to Customer) [portuguese]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('524', 'ticket', 'ticket-reply', 'portuguese', 'Ticket Reply (Sent to Customer) [portuguese]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('525', 'ticket', 'ticket-autoresponse', 'portuguese', 'New Ticket Opened - Autoresponse [portuguese]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('526', 'invoice', 'invoice-payment-recorded', 'portuguese', 'Invoice Payment Recorded (Sent to Customer) [portuguese]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('527', 'invoice', 'invoice-overdue-notice', 'portuguese', 'Invoice Overdue Notice [portuguese]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('528', 'invoice', 'invoice-already-send', 'portuguese', 'Invoice Already Sent to Customer [portuguese]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('529', 'ticket', 'new-ticket-created-staff', 'portuguese', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [portuguese]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('530', 'estimate', 'estimate-send-to-client', 'portuguese', 'Send Estimate to Customer [portuguese]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('531', 'ticket', 'ticket-reply-to-admin', 'portuguese', 'Ticket Reply (Sent to Staff) [portuguese]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('532', 'estimate', 'estimate-already-send', 'portuguese', 'Estimate Already Sent to Customer [portuguese]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('533', 'contract', 'contract-expiration', 'portuguese', 'Contract Expiration [portuguese]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('534', 'tasks', 'task-assigned', 'portuguese', 'New Task Assigned (Sent to Staff) [portuguese]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('535', 'tasks', 'task-added-as-follower', 'portuguese', 'Staff Member Added as Follower on Task [portuguese]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('536', 'tasks', 'task-commented', 'portuguese', 'New Comment on Task (Sent to Staff) [portuguese]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('537', 'tasks', 'task-marked-as-finished', 'portuguese', 'Task Marked as Finished (Sent to Staff) [portuguese]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('538', 'tasks', 'task-added-attachment', 'portuguese', 'New Attachment on Task (Sent to Staff) [portuguese]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('539', 'tasks', 'task-unmarked-as-finished', 'portuguese', 'Task Unmarked as Finished (Sent to Staff) [portuguese]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('540', 'estimate', 'estimate-declined-to-staff', 'portuguese', 'Estimate Declined (Sent to Staff) [portuguese]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('541', 'estimate', 'estimate-accepted-to-staff', 'portuguese', 'Estimate Accepted (Sent to Staff) [portuguese]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('542', 'proposals', 'proposal-client-accepted', 'portuguese', 'Customer Action - Accepted (Sent to Staff) [portuguese]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('543', 'proposals', 'proposal-send-to-customer', 'portuguese', 'Send Proposal to Customer [portuguese]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('544', 'proposals', 'proposal-client-declined', 'portuguese', 'Customer Action - Declined (Sent to Staff) [portuguese]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('545', 'proposals', 'proposal-client-thank-you', 'portuguese', 'Thank You Email (Sent to Customer After Accept) [portuguese]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('546', 'proposals', 'proposal-comment-to-client', 'portuguese', 'New Comment  (Sent to Customer Contacts) [portuguese]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('547', 'proposals', 'proposal-comment-to-admin', 'portuguese', 'New Comment (Sent to Staff)  [portuguese]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('548', 'estimate', 'estimate-thank-you-to-customer', 'portuguese', 'Thank You Email (Sent to Customer After Accept) [portuguese]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('549', 'tasks', 'task-deadline-notification', 'portuguese', 'Task Deadline Reminder - Sent to Assigned Members [portuguese]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('550', 'contract', 'send-contract', 'portuguese', 'Send Contract to Customer [portuguese]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('551', 'invoice', 'invoice-payment-recorded-to-staff', 'portuguese', 'Invoice Payment Recorded (Sent to Staff) [portuguese]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('552', 'ticket', 'auto-close-ticket', 'portuguese', 'Auto Close Ticket [portuguese]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('553', 'project', 'new-project-discussion-created-to-staff', 'portuguese', 'New Project Discussion (Sent to Project Members) [portuguese]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('554', 'project', 'new-project-discussion-created-to-customer', 'portuguese', 'New Project Discussion (Sent to Customer Contacts) [portuguese]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('555', 'project', 'new-project-file-uploaded-to-customer', 'portuguese', 'New Project File Uploaded (Sent to Customer Contacts) [portuguese]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('556', 'project', 'new-project-file-uploaded-to-staff', 'portuguese', 'New Project File Uploaded (Sent to Project Members) [portuguese]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('557', 'project', 'new-project-discussion-comment-to-customer', 'portuguese', 'New Discussion Comment  (Sent to Customer Contacts) [portuguese]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('558', 'project', 'new-project-discussion-comment-to-staff', 'portuguese', 'New Discussion Comment (Sent to Project Members) [portuguese]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('559', 'project', 'staff-added-as-project-member', 'portuguese', 'Staff Added as Project Member [portuguese]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('560', 'estimate', 'estimate-expiry-reminder', 'portuguese', 'Estimate Expiration Reminder [portuguese]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('561', 'proposals', 'proposal-expiry-reminder', 'portuguese', 'Proposal Expiration Reminder [portuguese]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('562', 'staff', 'new-staff-created', 'portuguese', 'New Staff Created (Welcome Email) [portuguese]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('563', 'client', 'contact-forgot-password', 'portuguese', 'Forgot Password [portuguese]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('564', 'client', 'contact-password-reseted', 'portuguese', 'Password Reset - Confirmation [portuguese]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('565', 'client', 'contact-set-password', 'portuguese', 'Set New Password [portuguese]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('566', 'staff', 'staff-forgot-password', 'portuguese', 'Forgot Password [portuguese]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('567', 'staff', 'staff-password-reseted', 'portuguese', 'Password Reset - Confirmation [portuguese]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('568', 'project', 'assigned-to-project', 'portuguese', 'New Project Created (Sent to Customer Contacts) [portuguese]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('569', 'tasks', 'task-marked-as-finished-to-contacts', 'portuguese', 'Task Marked as Finished (Sent to customer contacts) [portuguese]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('570', 'tasks', 'task-added-attachment-to-contacts', 'portuguese', 'New Attachment on Task (Sent to Customer Contacts) [portuguese]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('571', 'tasks', 'task-commented-to-contacts', 'portuguese', 'New Comment on Task (Sent to Customer Contacts) [portuguese]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('572', 'leads', 'new-lead-assigned', 'portuguese', 'New Lead Assigned to Staff Member [portuguese]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('573', 'client', 'new-client-created', 'portuguese_br', 'New Contact Added/Registered (Welcome Email) [portuguese_br]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('574', 'invoice', 'invoice-send-to-client', 'portuguese_br', 'Send Invoice to Customer [portuguese_br]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('575', 'ticket', 'new-ticket-opened-admin', 'portuguese_br', 'New Ticket Opened (Opened by Staff, Sent to Customer) [portuguese_br]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('576', 'ticket', 'ticket-reply', 'portuguese_br', 'Ticket Reply (Sent to Customer) [portuguese_br]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('577', 'ticket', 'ticket-autoresponse', 'portuguese_br', 'New Ticket Opened - Autoresponse [portuguese_br]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('578', 'invoice', 'invoice-payment-recorded', 'portuguese_br', 'Invoice Payment Recorded (Sent to Customer) [portuguese_br]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('579', 'invoice', 'invoice-overdue-notice', 'portuguese_br', 'Invoice Overdue Notice [portuguese_br]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('580', 'invoice', 'invoice-already-send', 'portuguese_br', 'Invoice Already Sent to Customer [portuguese_br]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('581', 'ticket', 'new-ticket-created-staff', 'portuguese_br', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [portuguese_br]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('582', 'estimate', 'estimate-send-to-client', 'portuguese_br', 'Send Estimate to Customer [portuguese_br]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('583', 'ticket', 'ticket-reply-to-admin', 'portuguese_br', 'Ticket Reply (Sent to Staff) [portuguese_br]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('584', 'estimate', 'estimate-already-send', 'portuguese_br', 'Estimate Already Sent to Customer [portuguese_br]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('585', 'contract', 'contract-expiration', 'portuguese_br', 'Contract Expiration [portuguese_br]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('586', 'tasks', 'task-assigned', 'portuguese_br', 'New Task Assigned (Sent to Staff) [portuguese_br]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('587', 'tasks', 'task-added-as-follower', 'portuguese_br', 'Staff Member Added as Follower on Task [portuguese_br]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('588', 'tasks', 'task-commented', 'portuguese_br', 'New Comment on Task (Sent to Staff) [portuguese_br]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('589', 'tasks', 'task-marked-as-finished', 'portuguese_br', 'Task Marked as Finished (Sent to Staff) [portuguese_br]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('590', 'tasks', 'task-added-attachment', 'portuguese_br', 'New Attachment on Task (Sent to Staff) [portuguese_br]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('591', 'tasks', 'task-unmarked-as-finished', 'portuguese_br', 'Task Unmarked as Finished (Sent to Staff) [portuguese_br]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('592', 'estimate', 'estimate-declined-to-staff', 'portuguese_br', 'Estimate Declined (Sent to Staff) [portuguese_br]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('593', 'estimate', 'estimate-accepted-to-staff', 'portuguese_br', 'Estimate Accepted (Sent to Staff) [portuguese_br]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('594', 'proposals', 'proposal-client-accepted', 'portuguese_br', 'Customer Action - Accepted (Sent to Staff) [portuguese_br]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('595', 'proposals', 'proposal-send-to-customer', 'portuguese_br', 'Send Proposal to Customer [portuguese_br]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('596', 'proposals', 'proposal-client-declined', 'portuguese_br', 'Customer Action - Declined (Sent to Staff) [portuguese_br]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('597', 'proposals', 'proposal-client-thank-you', 'portuguese_br', 'Thank You Email (Sent to Customer After Accept) [portuguese_br]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('598', 'proposals', 'proposal-comment-to-client', 'portuguese_br', 'New Comment  (Sent to Customer Contacts) [portuguese_br]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('599', 'proposals', 'proposal-comment-to-admin', 'portuguese_br', 'New Comment (Sent to Staff)  [portuguese_br]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('600', 'estimate', 'estimate-thank-you-to-customer', 'portuguese_br', 'Thank You Email (Sent to Customer After Accept) [portuguese_br]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('601', 'tasks', 'task-deadline-notification', 'portuguese_br', 'Task Deadline Reminder - Sent to Assigned Members [portuguese_br]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('602', 'contract', 'send-contract', 'portuguese_br', 'Send Contract to Customer [portuguese_br]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('603', 'invoice', 'invoice-payment-recorded-to-staff', 'portuguese_br', 'Invoice Payment Recorded (Sent to Staff) [portuguese_br]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('604', 'ticket', 'auto-close-ticket', 'portuguese_br', 'Auto Close Ticket [portuguese_br]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('605', 'project', 'new-project-discussion-created-to-staff', 'portuguese_br', 'New Project Discussion (Sent to Project Members) [portuguese_br]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('606', 'project', 'new-project-discussion-created-to-customer', 'portuguese_br', 'New Project Discussion (Sent to Customer Contacts) [portuguese_br]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('607', 'project', 'new-project-file-uploaded-to-customer', 'portuguese_br', 'New Project File Uploaded (Sent to Customer Contacts) [portuguese_br]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('608', 'project', 'new-project-file-uploaded-to-staff', 'portuguese_br', 'New Project File Uploaded (Sent to Project Members) [portuguese_br]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('609', 'project', 'new-project-discussion-comment-to-customer', 'portuguese_br', 'New Discussion Comment  (Sent to Customer Contacts) [portuguese_br]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('610', 'project', 'new-project-discussion-comment-to-staff', 'portuguese_br', 'New Discussion Comment (Sent to Project Members) [portuguese_br]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('611', 'project', 'staff-added-as-project-member', 'portuguese_br', 'Staff Added as Project Member [portuguese_br]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('612', 'estimate', 'estimate-expiry-reminder', 'portuguese_br', 'Estimate Expiration Reminder [portuguese_br]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('613', 'proposals', 'proposal-expiry-reminder', 'portuguese_br', 'Proposal Expiration Reminder [portuguese_br]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('614', 'staff', 'new-staff-created', 'portuguese_br', 'New Staff Created (Welcome Email) [portuguese_br]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('615', 'client', 'contact-forgot-password', 'portuguese_br', 'Forgot Password [portuguese_br]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('616', 'client', 'contact-password-reseted', 'portuguese_br', 'Password Reset - Confirmation [portuguese_br]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('617', 'client', 'contact-set-password', 'portuguese_br', 'Set New Password [portuguese_br]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('618', 'staff', 'staff-forgot-password', 'portuguese_br', 'Forgot Password [portuguese_br]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('619', 'staff', 'staff-password-reseted', 'portuguese_br', 'Password Reset - Confirmation [portuguese_br]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('620', 'project', 'assigned-to-project', 'portuguese_br', 'New Project Created (Sent to Customer Contacts) [portuguese_br]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('621', 'tasks', 'task-marked-as-finished-to-contacts', 'portuguese_br', 'Task Marked as Finished (Sent to customer contacts) [portuguese_br]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('622', 'tasks', 'task-added-attachment-to-contacts', 'portuguese_br', 'New Attachment on Task (Sent to Customer Contacts) [portuguese_br]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('623', 'tasks', 'task-commented-to-contacts', 'portuguese_br', 'New Comment on Task (Sent to Customer Contacts) [portuguese_br]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('624', 'leads', 'new-lead-assigned', 'portuguese_br', 'New Lead Assigned to Staff Member [portuguese_br]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('625', 'client', 'new-client-created', 'spanish', 'New Contact Added/Registered (Welcome Email) [spanish]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('626', 'invoice', 'invoice-send-to-client', 'spanish', 'Send Invoice to Customer [spanish]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('627', 'ticket', 'new-ticket-opened-admin', 'spanish', 'New Ticket Opened (Opened by Staff, Sent to Customer) [spanish]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('628', 'ticket', 'ticket-reply', 'spanish', 'Ticket Reply (Sent to Customer) [spanish]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('629', 'ticket', 'ticket-autoresponse', 'spanish', 'New Ticket Opened - Autoresponse [spanish]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('630', 'invoice', 'invoice-payment-recorded', 'spanish', 'Invoice Payment Recorded (Sent to Customer) [spanish]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('631', 'invoice', 'invoice-overdue-notice', 'spanish', 'Invoice Overdue Notice [spanish]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('632', 'invoice', 'invoice-already-send', 'spanish', 'Invoice Already Sent to Customer [spanish]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('633', 'ticket', 'new-ticket-created-staff', 'spanish', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [spanish]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('634', 'estimate', 'estimate-send-to-client', 'spanish', 'Send Estimate to Customer [spanish]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('635', 'ticket', 'ticket-reply-to-admin', 'spanish', 'Ticket Reply (Sent to Staff) [spanish]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('636', 'estimate', 'estimate-already-send', 'spanish', 'Estimate Already Sent to Customer [spanish]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('637', 'contract', 'contract-expiration', 'spanish', 'Contract Expiration [spanish]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('638', 'tasks', 'task-assigned', 'spanish', 'New Task Assigned (Sent to Staff) [spanish]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('639', 'tasks', 'task-added-as-follower', 'spanish', 'Staff Member Added as Follower on Task [spanish]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('640', 'tasks', 'task-commented', 'spanish', 'New Comment on Task (Sent to Staff) [spanish]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('641', 'tasks', 'task-marked-as-finished', 'spanish', 'Task Marked as Finished (Sent to Staff) [spanish]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('642', 'tasks', 'task-added-attachment', 'spanish', 'New Attachment on Task (Sent to Staff) [spanish]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('643', 'tasks', 'task-unmarked-as-finished', 'spanish', 'Task Unmarked as Finished (Sent to Staff) [spanish]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('644', 'estimate', 'estimate-declined-to-staff', 'spanish', 'Estimate Declined (Sent to Staff) [spanish]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('645', 'estimate', 'estimate-accepted-to-staff', 'spanish', 'Estimate Accepted (Sent to Staff) [spanish]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('646', 'proposals', 'proposal-client-accepted', 'spanish', 'Customer Action - Accepted (Sent to Staff) [spanish]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('647', 'proposals', 'proposal-send-to-customer', 'spanish', 'Send Proposal to Customer [spanish]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('648', 'proposals', 'proposal-client-declined', 'spanish', 'Customer Action - Declined (Sent to Staff) [spanish]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('649', 'proposals', 'proposal-client-thank-you', 'spanish', 'Thank You Email (Sent to Customer After Accept) [spanish]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('650', 'proposals', 'proposal-comment-to-client', 'spanish', 'New Comment  (Sent to Customer Contacts) [spanish]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('651', 'proposals', 'proposal-comment-to-admin', 'spanish', 'New Comment (Sent to Staff)  [spanish]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('652', 'estimate', 'estimate-thank-you-to-customer', 'spanish', 'Thank You Email (Sent to Customer After Accept) [spanish]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('653', 'tasks', 'task-deadline-notification', 'spanish', 'Task Deadline Reminder - Sent to Assigned Members [spanish]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('654', 'contract', 'send-contract', 'spanish', 'Send Contract to Customer [spanish]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('655', 'invoice', 'invoice-payment-recorded-to-staff', 'spanish', 'Invoice Payment Recorded (Sent to Staff) [spanish]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('656', 'ticket', 'auto-close-ticket', 'spanish', 'Auto Close Ticket [spanish]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('657', 'project', 'new-project-discussion-created-to-staff', 'spanish', 'New Project Discussion (Sent to Project Members) [spanish]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('658', 'project', 'new-project-discussion-created-to-customer', 'spanish', 'New Project Discussion (Sent to Customer Contacts) [spanish]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('659', 'project', 'new-project-file-uploaded-to-customer', 'spanish', 'New Project File Uploaded (Sent to Customer Contacts) [spanish]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('660', 'project', 'new-project-file-uploaded-to-staff', 'spanish', 'New Project File Uploaded (Sent to Project Members) [spanish]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('661', 'project', 'new-project-discussion-comment-to-customer', 'spanish', 'New Discussion Comment  (Sent to Customer Contacts) [spanish]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('662', 'project', 'new-project-discussion-comment-to-staff', 'spanish', 'New Discussion Comment (Sent to Project Members) [spanish]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('663', 'project', 'staff-added-as-project-member', 'spanish', 'Staff Added as Project Member [spanish]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('664', 'estimate', 'estimate-expiry-reminder', 'spanish', 'Estimate Expiration Reminder [spanish]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('665', 'proposals', 'proposal-expiry-reminder', 'spanish', 'Proposal Expiration Reminder [spanish]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('666', 'staff', 'new-staff-created', 'spanish', 'New Staff Created (Welcome Email) [spanish]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('667', 'client', 'contact-forgot-password', 'spanish', 'Forgot Password [spanish]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('668', 'client', 'contact-password-reseted', 'spanish', 'Password Reset - Confirmation [spanish]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('669', 'client', 'contact-set-password', 'spanish', 'Set New Password [spanish]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('670', 'staff', 'staff-forgot-password', 'spanish', 'Forgot Password [spanish]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('671', 'staff', 'staff-password-reseted', 'spanish', 'Password Reset - Confirmation [spanish]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('672', 'project', 'assigned-to-project', 'spanish', 'New Project Created (Sent to Customer Contacts) [spanish]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('673', 'tasks', 'task-marked-as-finished-to-contacts', 'spanish', 'Task Marked as Finished (Sent to customer contacts) [spanish]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('674', 'tasks', 'task-added-attachment-to-contacts', 'spanish', 'New Attachment on Task (Sent to Customer Contacts) [spanish]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('675', 'tasks', 'task-commented-to-contacts', 'spanish', 'New Comment on Task (Sent to Customer Contacts) [spanish]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('676', 'leads', 'new-lead-assigned', 'spanish', 'New Lead Assigned to Staff Member [spanish]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('677', 'client', 'new-client-created', 'swedish', 'New Contact Added/Registered (Welcome Email) [swedish]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('678', 'invoice', 'invoice-send-to-client', 'swedish', 'Send Invoice to Customer [swedish]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('679', 'ticket', 'new-ticket-opened-admin', 'swedish', 'New Ticket Opened (Opened by Staff, Sent to Customer) [swedish]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('680', 'ticket', 'ticket-reply', 'swedish', 'Ticket Reply (Sent to Customer) [swedish]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('681', 'ticket', 'ticket-autoresponse', 'swedish', 'New Ticket Opened - Autoresponse [swedish]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('682', 'invoice', 'invoice-payment-recorded', 'swedish', 'Invoice Payment Recorded (Sent to Customer) [swedish]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('683', 'invoice', 'invoice-overdue-notice', 'swedish', 'Invoice Overdue Notice [swedish]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('684', 'invoice', 'invoice-already-send', 'swedish', 'Invoice Already Sent to Customer [swedish]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('685', 'ticket', 'new-ticket-created-staff', 'swedish', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [swedish]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('686', 'estimate', 'estimate-send-to-client', 'swedish', 'Send Estimate to Customer [swedish]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('687', 'ticket', 'ticket-reply-to-admin', 'swedish', 'Ticket Reply (Sent to Staff) [swedish]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('688', 'estimate', 'estimate-already-send', 'swedish', 'Estimate Already Sent to Customer [swedish]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('689', 'contract', 'contract-expiration', 'swedish', 'Contract Expiration [swedish]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('690', 'tasks', 'task-assigned', 'swedish', 'New Task Assigned (Sent to Staff) [swedish]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('691', 'tasks', 'task-added-as-follower', 'swedish', 'Staff Member Added as Follower on Task [swedish]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('692', 'tasks', 'task-commented', 'swedish', 'New Comment on Task (Sent to Staff) [swedish]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('693', 'tasks', 'task-marked-as-finished', 'swedish', 'Task Marked as Finished (Sent to Staff) [swedish]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('694', 'tasks', 'task-added-attachment', 'swedish', 'New Attachment on Task (Sent to Staff) [swedish]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('695', 'tasks', 'task-unmarked-as-finished', 'swedish', 'Task Unmarked as Finished (Sent to Staff) [swedish]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('696', 'estimate', 'estimate-declined-to-staff', 'swedish', 'Estimate Declined (Sent to Staff) [swedish]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('697', 'estimate', 'estimate-accepted-to-staff', 'swedish', 'Estimate Accepted (Sent to Staff) [swedish]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('698', 'proposals', 'proposal-client-accepted', 'swedish', 'Customer Action - Accepted (Sent to Staff) [swedish]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('699', 'proposals', 'proposal-send-to-customer', 'swedish', 'Send Proposal to Customer [swedish]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('700', 'proposals', 'proposal-client-declined', 'swedish', 'Customer Action - Declined (Sent to Staff) [swedish]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('701', 'proposals', 'proposal-client-thank-you', 'swedish', 'Thank You Email (Sent to Customer After Accept) [swedish]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('702', 'proposals', 'proposal-comment-to-client', 'swedish', 'New Comment  (Sent to Customer Contacts) [swedish]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('703', 'proposals', 'proposal-comment-to-admin', 'swedish', 'New Comment (Sent to Staff)  [swedish]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('704', 'estimate', 'estimate-thank-you-to-customer', 'swedish', 'Thank You Email (Sent to Customer After Accept) [swedish]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('705', 'tasks', 'task-deadline-notification', 'swedish', 'Task Deadline Reminder - Sent to Assigned Members [swedish]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('706', 'contract', 'send-contract', 'swedish', 'Send Contract to Customer [swedish]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('707', 'invoice', 'invoice-payment-recorded-to-staff', 'swedish', 'Invoice Payment Recorded (Sent to Staff) [swedish]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('708', 'ticket', 'auto-close-ticket', 'swedish', 'Auto Close Ticket [swedish]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('709', 'project', 'new-project-discussion-created-to-staff', 'swedish', 'New Project Discussion (Sent to Project Members) [swedish]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('710', 'project', 'new-project-discussion-created-to-customer', 'swedish', 'New Project Discussion (Sent to Customer Contacts) [swedish]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('711', 'project', 'new-project-file-uploaded-to-customer', 'swedish', 'New Project File Uploaded (Sent to Customer Contacts) [swedish]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('712', 'project', 'new-project-file-uploaded-to-staff', 'swedish', 'New Project File Uploaded (Sent to Project Members) [swedish]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('713', 'project', 'new-project-discussion-comment-to-customer', 'swedish', 'New Discussion Comment  (Sent to Customer Contacts) [swedish]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('714', 'project', 'new-project-discussion-comment-to-staff', 'swedish', 'New Discussion Comment (Sent to Project Members) [swedish]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('715', 'project', 'staff-added-as-project-member', 'swedish', 'Staff Added as Project Member [swedish]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('716', 'estimate', 'estimate-expiry-reminder', 'swedish', 'Estimate Expiration Reminder [swedish]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('717', 'proposals', 'proposal-expiry-reminder', 'swedish', 'Proposal Expiration Reminder [swedish]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('718', 'staff', 'new-staff-created', 'swedish', 'New Staff Created (Welcome Email) [swedish]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('719', 'client', 'contact-forgot-password', 'swedish', 'Forgot Password [swedish]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('720', 'client', 'contact-password-reseted', 'swedish', 'Password Reset - Confirmation [swedish]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('721', 'client', 'contact-set-password', 'swedish', 'Set New Password [swedish]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('722', 'staff', 'staff-forgot-password', 'swedish', 'Forgot Password [swedish]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('723', 'staff', 'staff-password-reseted', 'swedish', 'Password Reset - Confirmation [swedish]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('724', 'project', 'assigned-to-project', 'swedish', 'New Project Created (Sent to Customer Contacts) [swedish]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('725', 'tasks', 'task-marked-as-finished-to-contacts', 'swedish', 'Task Marked as Finished (Sent to customer contacts) [swedish]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('726', 'tasks', 'task-added-attachment-to-contacts', 'swedish', 'New Attachment on Task (Sent to Customer Contacts) [swedish]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('727', 'tasks', 'task-commented-to-contacts', 'swedish', 'New Comment on Task (Sent to Customer Contacts) [swedish]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('728', 'leads', 'new-lead-assigned', 'swedish', 'New Lead Assigned to Staff Member [swedish]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('729', 'client', 'new-client-created', 'turkish', 'New Contact Added/Registered (Welcome Email) [turkish]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('730', 'invoice', 'invoice-send-to-client', 'turkish', 'Send Invoice to Customer [turkish]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('731', 'ticket', 'new-ticket-opened-admin', 'turkish', 'New Ticket Opened (Opened by Staff, Sent to Customer) [turkish]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('732', 'ticket', 'ticket-reply', 'turkish', 'Ticket Reply (Sent to Customer) [turkish]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('733', 'ticket', 'ticket-autoresponse', 'turkish', 'New Ticket Opened - Autoresponse [turkish]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('734', 'invoice', 'invoice-payment-recorded', 'turkish', 'Invoice Payment Recorded (Sent to Customer) [turkish]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('735', 'invoice', 'invoice-overdue-notice', 'turkish', 'Invoice Overdue Notice [turkish]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('736', 'invoice', 'invoice-already-send', 'turkish', 'Invoice Already Sent to Customer [turkish]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('737', 'ticket', 'new-ticket-created-staff', 'turkish', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [turkish]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('738', 'estimate', 'estimate-send-to-client', 'turkish', 'Send Estimate to Customer [turkish]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('739', 'ticket', 'ticket-reply-to-admin', 'turkish', 'Ticket Reply (Sent to Staff) [turkish]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('740', 'estimate', 'estimate-already-send', 'turkish', 'Estimate Already Sent to Customer [turkish]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('741', 'contract', 'contract-expiration', 'turkish', 'Contract Expiration [turkish]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('742', 'tasks', 'task-assigned', 'turkish', 'New Task Assigned (Sent to Staff) [turkish]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('743', 'tasks', 'task-added-as-follower', 'turkish', 'Staff Member Added as Follower on Task [turkish]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('744', 'tasks', 'task-commented', 'turkish', 'New Comment on Task (Sent to Staff) [turkish]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('745', 'tasks', 'task-marked-as-finished', 'turkish', 'Task Marked as Finished (Sent to Staff) [turkish]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('746', 'tasks', 'task-added-attachment', 'turkish', 'New Attachment on Task (Sent to Staff) [turkish]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('747', 'tasks', 'task-unmarked-as-finished', 'turkish', 'Task Unmarked as Finished (Sent to Staff) [turkish]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('748', 'estimate', 'estimate-declined-to-staff', 'turkish', 'Estimate Declined (Sent to Staff) [turkish]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('749', 'estimate', 'estimate-accepted-to-staff', 'turkish', 'Estimate Accepted (Sent to Staff) [turkish]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('750', 'proposals', 'proposal-client-accepted', 'turkish', 'Customer Action - Accepted (Sent to Staff) [turkish]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('751', 'proposals', 'proposal-send-to-customer', 'turkish', 'Send Proposal to Customer [turkish]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('752', 'proposals', 'proposal-client-declined', 'turkish', 'Customer Action - Declined (Sent to Staff) [turkish]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('753', 'proposals', 'proposal-client-thank-you', 'turkish', 'Thank You Email (Sent to Customer After Accept) [turkish]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('754', 'proposals', 'proposal-comment-to-client', 'turkish', 'New Comment  (Sent to Customer Contacts) [turkish]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('755', 'proposals', 'proposal-comment-to-admin', 'turkish', 'New Comment (Sent to Staff)  [turkish]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('756', 'estimate', 'estimate-thank-you-to-customer', 'turkish', 'Thank You Email (Sent to Customer After Accept) [turkish]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('757', 'tasks', 'task-deadline-notification', 'turkish', 'Task Deadline Reminder - Sent to Assigned Members [turkish]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('758', 'contract', 'send-contract', 'turkish', 'Send Contract to Customer [turkish]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('759', 'invoice', 'invoice-payment-recorded-to-staff', 'turkish', 'Invoice Payment Recorded (Sent to Staff) [turkish]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('760', 'ticket', 'auto-close-ticket', 'turkish', 'Auto Close Ticket [turkish]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('761', 'project', 'new-project-discussion-created-to-staff', 'turkish', 'New Project Discussion (Sent to Project Members) [turkish]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('762', 'project', 'new-project-discussion-created-to-customer', 'turkish', 'New Project Discussion (Sent to Customer Contacts) [turkish]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('763', 'project', 'new-project-file-uploaded-to-customer', 'turkish', 'New Project File Uploaded (Sent to Customer Contacts) [turkish]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('764', 'project', 'new-project-file-uploaded-to-staff', 'turkish', 'New Project File Uploaded (Sent to Project Members) [turkish]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('765', 'project', 'new-project-discussion-comment-to-customer', 'turkish', 'New Discussion Comment  (Sent to Customer Contacts) [turkish]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('766', 'project', 'new-project-discussion-comment-to-staff', 'turkish', 'New Discussion Comment (Sent to Project Members) [turkish]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('767', 'project', 'staff-added-as-project-member', 'turkish', 'Staff Added as Project Member [turkish]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('768', 'estimate', 'estimate-expiry-reminder', 'turkish', 'Estimate Expiration Reminder [turkish]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('769', 'proposals', 'proposal-expiry-reminder', 'turkish', 'Proposal Expiration Reminder [turkish]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('770', 'staff', 'new-staff-created', 'turkish', 'New Staff Created (Welcome Email) [turkish]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('771', 'client', 'contact-forgot-password', 'turkish', 'Forgot Password [turkish]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('772', 'client', 'contact-password-reseted', 'turkish', 'Password Reset - Confirmation [turkish]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('773', 'client', 'contact-set-password', 'turkish', 'Set New Password [turkish]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('774', 'staff', 'staff-forgot-password', 'turkish', 'Forgot Password [turkish]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('775', 'staff', 'staff-password-reseted', 'turkish', 'Password Reset - Confirmation [turkish]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('776', 'project', 'assigned-to-project', 'turkish', 'New Project Created (Sent to Customer Contacts) [turkish]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('777', 'tasks', 'task-marked-as-finished-to-contacts', 'turkish', 'Task Marked as Finished (Sent to customer contacts) [turkish]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('778', 'tasks', 'task-added-attachment-to-contacts', 'turkish', 'New Attachment on Task (Sent to Customer Contacts) [turkish]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('779', 'tasks', 'task-commented-to-contacts', 'turkish', 'New Comment on Task (Sent to Customer Contacts) [turkish]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('780', 'leads', 'new-lead-assigned', 'turkish', 'New Lead Assigned to Staff Member [turkish]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('781', 'client', 'new-client-created', 'vietnamese', 'New Contact Added/Registered (Welcome Email) [vietnamese]', 'Welcome aboard', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('782', 'invoice', 'invoice-send-to-client', 'vietnamese', 'Send Invoice to Customer [vietnamese]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('783', 'ticket', 'new-ticket-opened-admin', 'vietnamese', 'New Ticket Opened (Opened by Staff, Sent to Customer) [vietnamese]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('784', 'ticket', 'ticket-reply', 'vietnamese', 'Ticket Reply (Sent to Customer) [vietnamese]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('785', 'ticket', 'ticket-autoresponse', 'vietnamese', 'New Ticket Opened - Autoresponse [vietnamese]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('786', 'invoice', 'invoice-payment-recorded', 'vietnamese', 'Invoice Payment Recorded (Sent to Customer) [vietnamese]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('787', 'invoice', 'invoice-overdue-notice', 'vietnamese', 'Invoice Overdue Notice [vietnamese]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('788', 'invoice', 'invoice-already-send', 'vietnamese', 'Invoice Already Sent to Customer [vietnamese]', 'On your command here is the invoice', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('789', 'ticket', 'new-ticket-created-staff', 'vietnamese', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [vietnamese]', 'New Ticket Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('790', 'estimate', 'estimate-send-to-client', 'vietnamese', 'Send Estimate to Customer [vietnamese]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('791', 'ticket', 'ticket-reply-to-admin', 'vietnamese', 'Ticket Reply (Sent to Staff) [vietnamese]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('792', 'estimate', 'estimate-already-send', 'vietnamese', 'Estimate Already Sent to Customer [vietnamese]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('793', 'contract', 'contract-expiration', 'vietnamese', 'Contract Expiration [vietnamese]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('794', 'tasks', 'task-assigned', 'vietnamese', 'New Task Assigned (Sent to Staff) [vietnamese]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('795', 'tasks', 'task-added-as-follower', 'vietnamese', 'Staff Member Added as Follower on Task [vietnamese]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('796', 'tasks', 'task-commented', 'vietnamese', 'New Comment on Task (Sent to Staff) [vietnamese]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('797', 'tasks', 'task-marked-as-finished', 'vietnamese', 'Task Marked as Finished (Sent to Staff) [vietnamese]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('798', 'tasks', 'task-added-attachment', 'vietnamese', 'New Attachment on Task (Sent to Staff) [vietnamese]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('799', 'tasks', 'task-unmarked-as-finished', 'vietnamese', 'Task Unmarked as Finished (Sent to Staff) [vietnamese]', 'Task UN-marked as finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('800', 'estimate', 'estimate-declined-to-staff', 'vietnamese', 'Estimate Declined (Sent to Staff) [vietnamese]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('801', 'estimate', 'estimate-accepted-to-staff', 'vietnamese', 'Estimate Accepted (Sent to Staff) [vietnamese]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('802', 'proposals', 'proposal-client-accepted', 'vietnamese', 'Customer Action - Accepted (Sent to Staff) [vietnamese]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('803', 'proposals', 'proposal-send-to-customer', 'vietnamese', 'Send Proposal to Customer [vietnamese]', 'Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('804', 'proposals', 'proposal-client-declined', 'vietnamese', 'Customer Action - Declined (Sent to Staff) [vietnamese]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('805', 'proposals', 'proposal-client-thank-you', 'vietnamese', 'Thank You Email (Sent to Customer After Accept) [vietnamese]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('806', 'proposals', 'proposal-comment-to-client', 'vietnamese', 'New Comment  (Sent to Customer Contacts) [vietnamese]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('807', 'proposals', 'proposal-comment-to-admin', 'vietnamese', 'New Comment (Sent to Staff)  [vietnamese]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('808', 'estimate', 'estimate-thank-you-to-customer', 'vietnamese', 'Thank You Email (Sent to Customer After Accept) [vietnamese]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('809', 'tasks', 'task-deadline-notification', 'vietnamese', 'Task Deadline Reminder - Sent to Assigned Members [vietnamese]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('810', 'contract', 'send-contract', 'vietnamese', 'Send Contract to Customer [vietnamese]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('811', 'invoice', 'invoice-payment-recorded-to-staff', 'vietnamese', 'Invoice Payment Recorded (Sent to Staff) [vietnamese]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('812', 'ticket', 'auto-close-ticket', 'vietnamese', 'Auto Close Ticket [vietnamese]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('813', 'project', 'new-project-discussion-created-to-staff', 'vietnamese', 'New Project Discussion (Sent to Project Members) [vietnamese]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('814', 'project', 'new-project-discussion-created-to-customer', 'vietnamese', 'New Project Discussion (Sent to Customer Contacts) [vietnamese]', 'New Project Discussion Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('815', 'project', 'new-project-file-uploaded-to-customer', 'vietnamese', 'New Project File Uploaded (Sent to Customer Contacts) [vietnamese]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('816', 'project', 'new-project-file-uploaded-to-staff', 'vietnamese', 'New Project File Uploaded (Sent to Project Members) [vietnamese]', 'New Project File Uploaded', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('817', 'project', 'new-project-discussion-comment-to-customer', 'vietnamese', 'New Discussion Comment  (Sent to Customer Contacts) [vietnamese]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('818', 'project', 'new-project-discussion-comment-to-staff', 'vietnamese', 'New Discussion Comment (Sent to Project Members) [vietnamese]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('819', 'project', 'staff-added-as-project-member', 'vietnamese', 'Staff Added as Project Member [vietnamese]', 'New project assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('820', 'estimate', 'estimate-expiry-reminder', 'vietnamese', 'Estimate Expiration Reminder [vietnamese]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('821', 'proposals', 'proposal-expiry-reminder', 'vietnamese', 'Proposal Expiration Reminder [vietnamese]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('822', 'staff', 'new-staff-created', 'vietnamese', 'New Staff Created (Welcome Email) [vietnamese]', 'You are added as staff member', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('823', 'client', 'contact-forgot-password', 'vietnamese', 'Forgot Password [vietnamese]', 'Create New Password', '', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('824', 'client', 'contact-password-reseted', 'vietnamese', 'Password Reset - Confirmation [vietnamese]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('825', 'client', 'contact-set-password', 'vietnamese', 'Set New Password [vietnamese]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('826', 'staff', 'staff-forgot-password', 'vietnamese', 'Forgot Password [vietnamese]', 'Create New Password', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('827', 'staff', 'staff-password-reseted', 'vietnamese', 'Password Reset - Confirmation [vietnamese]', 'Your password has been changed', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('828', 'project', 'assigned-to-project', 'vietnamese', 'New Project Created (Sent to Customer Contacts) [vietnamese]', 'New Project Created', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('829', 'tasks', 'task-marked-as-finished-to-contacts', 'vietnamese', 'Task Marked as Finished (Sent to customer contacts) [vietnamese]', 'Task Marked as Finished - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('830', 'tasks', 'task-added-attachment-to-contacts', 'vietnamese', 'New Attachment on Task (Sent to Customer Contacts) [vietnamese]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('831', 'tasks', 'task-commented-to-contacts', 'vietnamese', 'New Comment on Task (Sent to Customer Contacts) [vietnamese]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('832', 'leads', 'new-lead-assigned', 'vietnamese', 'New Lead Assigned to Staff Member [vietnamese]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('833', 'marketing', 'new-marketing-created', 'english', 'Mẫu Email Marketing 1', 'Chào Mừng Email', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><br /></span><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank you for registering on the {companyname} CRM System.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We just wanted to say welcome.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us if you need any help.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">(This is an automated email, so please don\'t reply to this email address)</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;dassadsadsadsadsadsadsadsadsadasdsadsadsadsad<br />{reset_password_url}{contact_lastname}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('834', 'marketing', 'new-marketing-created', 'vietnamese', 'New marketing Added/Registered (Welcome Email) [vietnamese]', 'Welcome aboard', '', '{companyname} | CRM', '', '0', '1', '0');


#
# TABLE STRUCTURE FOR: tblestimates
#

DROP TABLE IF EXISTS `tblestimates`;

CREATE TABLE `tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '0',
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL DEFAULT '0.00',
  `total` decimal(11,2) NOT NULL,
  `adjustment` decimal(11,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `clientnote` text,
  `adminnote` text,
  `discount_percent` decimal(11,2) DEFAULT '0.00',
  `discount_total` decimal(11,2) DEFAULT '0.00',
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `pipeline_order` int(11) NOT NULL DEFAULT '0',
  `is_expiry_notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblevents
#

DROP TABLE IF EXISTS `tblevents`;

CREATE TABLE `tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` mediumtext NOT NULL,
  `description` text,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT '0',
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpenses
#

DROP TABLE IF EXISTS `tblexpenses`;

CREATE TABLE `tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` text,
  `expense_name` varchar(500) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `billable` int(11) DEFAULT '0',
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `recurring_ends_on` date DEFAULT NULL,
  `custom_recurring` int(11) NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblexpenses` (`id`, `category`, `currency`, `amount`, `tax`, `reference_no`, `note`, `expense_name`, `clientid`, `project_id`, `billable`, `invoiceid`, `paymentmode`, `date`, `recurring_type`, `repeat_every`, `recurring`, `recurring_ends_on`, `custom_recurring`, `last_recurring_date`, `create_invoice_billable`, `send_invoice_to_customer`, `recurring_from`, `dateadded`, `addedfrom`) VALUES ('1', '0', '0', '5000.00', '1', NULL, 'abc', 'bb', '1', '0', '0', NULL, 'dsadsa', '2017-05-31', 'dsads', '2', '0', NULL, '0', NULL, NULL, '0', NULL, '0000-00-00 00:00:00', '0');


#
# TABLE STRUCTURE FOR: tblexpensescategories
#

DROP TABLE IF EXISTS `tblexpensescategories`;

CREATE TABLE `tblexpensescategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblfiles
#

DROP TABLE IF EXISTS `tblfiles`;

CREATE TABLE `tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `id_category` int(11) NOT NULL,
  `file_name` varchar(600) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT '0',
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` text,
  `thumbnail_link` text COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

INSERT INTO `tblfiles` (`id`, `rel_id`, `rel_type`, `id_category`, `file_name`, `filetype`, `visible_to_customer`, `attachment_key`, `external`, `external_link`, `thumbnail_link`, `staffid`, `contact_id`, `dateadded`) VALUES ('53', '1', 'customer', '1', 'logohung-19.png', 'image/png', '0', '910642f344a8d7538665f2d139510da9', NULL, NULL, NULL, '1', '0', '2017-05-05 09:54:15');
INSERT INTO `tblfiles` (`id`, `rel_id`, `rel_type`, `id_category`, `file_name`, `filetype`, `visible_to_customer`, `attachment_key`, `external`, `external_link`, `thumbnail_link`, `staffid`, `contact_id`, `dateadded`) VALUES ('54', '1', 'customer', '2', 'logohung-20.png', 'image/png', '0', 'ff6d635d12fc7ecfdb7f8d5ca41dff70', NULL, NULL, NULL, '1', '0', '2017-05-05 10:04:28');


#
# TABLE STRUCTURE FOR: tblformquestionboxes
#

DROP TABLE IF EXISTS `tblformquestionboxes`;

CREATE TABLE `tblformquestionboxes` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblformquestionboxesdescription
#

DROP TABLE IF EXISTS `tblformquestionboxesdescription`;

CREATE TABLE `tblformquestionboxesdescription` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblformquestions
#

DROP TABLE IF EXISTS `tblformquestions`;

CREATE TABLE `tblformquestions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblformresults
#

DROP TABLE IF EXISTS `tblformresults`;

CREATE TABLE `tblformresults` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblgoals
#

DROP TABLE IF EXISTS `tblgoals`;

CREATE TABLE `tblgoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(400) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `goal_type` int(11) NOT NULL,
  `contract_type` int(11) NOT NULL DEFAULT '0',
  `achievement` int(11) NOT NULL,
  `notify_when_fail` tinyint(1) NOT NULL DEFAULT '1',
  `notify_when_achieve` tinyint(1) NOT NULL DEFAULT '1',
  `notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentrecords
#

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;

CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(200) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentsmodes
#

DROP TABLE IF EXISTS `tblinvoicepaymentsmodes`;

CREATE TABLE `tblinvoicepaymentsmodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `show_on_pdf` int(11) NOT NULL DEFAULT '0',
  `invoices_only` int(11) NOT NULL DEFAULT '0',
  `expenses_only` int(11) NOT NULL DEFAULT '0',
  `selected_by_default` int(11) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblinvoicepaymentsmodes` (`id`, `name`, `description`, `show_on_pdf`, `invoices_only`, `expenses_only`, `selected_by_default`, `active`) VALUES ('1', 'Bank', NULL, '0', '0', '0', '1', '1');


#
# TABLE STRUCTURE FOR: tblinvoices
#

DROP TABLE IF EXISTS `tblinvoices`;

CREATE TABLE `tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL DEFAULT '0.00',
  `total` decimal(11,2) NOT NULL,
  `adjustment` decimal(11,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT '1',
  `clientnote` text,
  `adminnote` text,
  `last_overdue_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT '0',
  `allowed_payment_modes` mediumtext,
  `token` mediumtext,
  `discount_percent` decimal(11,2) DEFAULT '0.00',
  `discount_total` decimal(11,2) DEFAULT '0.00',
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `recurring_ends_on` date DEFAULT NULL,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` text,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `project_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems
#

DROP TABLE IF EXISTS `tblitems`;

CREATE TABLE `tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `long_description` text,
  `landtypeid` tinyint(4) DEFAULT NULL,
  `district_id` varchar(5) DEFAULT NULL,
  `provinceid` varchar(5) DEFAULT NULL,
  `rate` decimal(11,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO `tblitems` (`id`, `description`, `long_description`, `landtypeid`, `district_id`, `provinceid`, `rate`, `tax`, `unit`, `group_id`) VALUES ('34', '1', 'sds', '12', '750', '77', '1.00', '1', 'a', '1');
INSERT INTO `tblitems` (`id`, `description`, `long_description`, `landtypeid`, `district_id`, `provinceid`, `rate`, `tax`, `unit`, `group_id`) VALUES ('35', '2', '11111111', '5', '688', '70', '5.00', '1', 'cai', '1');
INSERT INTO `tblitems` (`id`, `description`, `long_description`, `landtypeid`, `district_id`, `provinceid`, `rate`, `tax`, `unit`, `group_id`) VALUES ('36', 'dsa', 'dsad', '6', '215', '24', '1.00', '0', '', '0');


#
# TABLE STRUCTURE FOR: tblitems_groups
#

DROP TABLE IF EXISTS `tblitems_groups`;

CREATE TABLE `tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblitems_groups` (`id`, `name`) VALUES ('1', 'thuy');


#
# TABLE STRUCTURE FOR: tblitems_in
#

DROP TABLE IF EXISTS `tblitems_in`;

CREATE TABLE `tblitems_in` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` mediumtext NOT NULL,
  `long_description` mediumtext,
  `qty` decimal(11,2) NOT NULL,
  `rate` decimal(11,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitemsrelated
#

DROP TABLE IF EXISTS `tblitemsrelated`;

CREATE TABLE `tblitemsrelated` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitemstax
#

DROP TABLE IF EXISTS `tblitemstax`;

CREATE TABLE `tblitemstax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(11,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledgebase
#

DROP TABLE IF EXISTS `tblknowledgebase`;

CREATE TABLE `tblknowledgebase` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT '0',
  `staff_article` int(11) NOT NULL DEFAULT '0',
  `views` int(11) DEFAULT NULL,
  PRIMARY KEY (`articleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledgebasearticleanswers
#

DROP TABLE IF EXISTS `tblknowledgebasearticleanswers`;

CREATE TABLE `tblknowledgebasearticleanswers` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledgebasegroups
#

DROP TABLE IF EXISTS `tblknowledgebasegroups`;

CREATE TABLE `tblknowledgebasegroups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `description` mediumtext,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT '0',
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleadactivitylog
#

DROP TABLE IF EXISTS `tblleadactivitylog`;

CREATE TABLE `tblleadactivitylog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` varchar(600) DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleads
#

DROP TABLE IF EXISTS `tblleads`;

CREATE TABLE `tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(300) DEFAULT NULL,
  `description` text,
  `country` int(11) NOT NULL DEFAULT '0',
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT '1',
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT '0',
  `junk` int(11) NOT NULL DEFAULT '0',
  `last_lead_status` int(11) NOT NULL DEFAULT '0',
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT '0',
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `client_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `assigned` (`assigned`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `leadorder` (`leadorder`),
  KEY `dateadded` (`dateadded`),
  KEY `from_form_id` (`from_form_id`),
  KEY `from_form_id_2` (`from_form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleadsemailintegrationemails
#

DROP TABLE IF EXISTS `tblleadsemailintegrationemails`;

CREATE TABLE `tblleadsemailintegrationemails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext,
  `body` mediumtext,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleadsintegration
#

DROP TABLE IF EXISTS `tblleadsintegration`;

CREATE TABLE `tblleadsintegration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` mediumtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT '5',
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT '1',
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT '1',
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT '1',
  `delete_after_import` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblleadsintegration` (`id`, `active`, `email`, `imap_server`, `password`, `check_every`, `responsible`, `lead_source`, `lead_status`, `encryption`, `folder`, `last_run`, `notify_lead_imported`, `notify_lead_contact_more_times`, `notify_type`, `notify_ids`, `only_loop_on_unseen_emails`, `delete_after_import`) VALUES ('1', '0', '', '', '', '10', '0', '0', '0', 'tls', 'inbox', '', '1', '1', 'roles', '', '1', '0');


#
# TABLE STRUCTURE FOR: tblleadssources
#

DROP TABLE IF EXISTS `tblleadssources`;

CREATE TABLE `tblleadssources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblleadssources` (`id`, `name`) VALUES ('1', 'Google');
INSERT INTO `tblleadssources` (`id`, `name`) VALUES ('2', 'Facebook');


#
# TABLE STRUCTURE FOR: tblleadsstatus
#

DROP TABLE IF EXISTS `tblleadsstatus`;

CREATE TABLE `tblleadsstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblleadsstatus` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES ('1', 'Customer', '1000', '#7cb342', '1');
INSERT INTO `tblleadsstatus` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES ('2', 'Đã liên lạc', '0', '#4fc25b', '0');


#
# TABLE STRUCTURE FOR: tbllistemails
#

DROP TABLE IF EXISTS `tbllistemails`;

CREATE TABLE `tbllistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmaillistscustomfields
#

DROP TABLE IF EXISTS `tblmaillistscustomfields`;

CREATE TABLE `tblmaillistscustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmaillistscustomfieldvalues
#

DROP TABLE IF EXISTS `tblmaillistscustomfieldvalues`;

CREATE TABLE `tblmaillistscustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmenubds
#

DROP TABLE IF EXISTS `tblmenubds`;

CREATE TABLE `tblmenubds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL,
  `menu_chil` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblmenubds` (`id`, `menu_name`, `parent_id`, `menu_chil`) VALUES ('49', 'Biệt thự', '0', '');
INSERT INTO `tblmenubds` (`id`, `menu_name`, `parent_id`, `menu_chil`) VALUES ('53', 'Biệt thự', '49', 'Quận gò vấp');
INSERT INTO `tblmenubds` (`id`, `menu_name`, `parent_id`, `menu_chil`) VALUES ('58', 'Căn hộ', '0', '');
INSERT INTO `tblmenubds` (`id`, `menu_name`, `parent_id`, `menu_chil`) VALUES ('59', 'Căn hộ', '58', 'Quận Tân Phú');
INSERT INTO `tblmenubds` (`id`, `menu_name`, `parent_id`, `menu_chil`) VALUES ('61', 'Biệt thự', '49', 'Quận 7');


#
# TABLE STRUCTURE FOR: tblmigrations
#

DROP TABLE IF EXISTS `tblmigrations`;

CREATE TABLE `tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblmigrations` (`version`) VALUES ('161');


#
# TABLE STRUCTURE FOR: tblmilestones
#

DROP TABLE IF EXISTS `tblmilestones`;

CREATE TABLE `tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(400) NOT NULL,
  `description` text,
  `description_visible_to_customer` tinyint(1) DEFAULT '0',
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT '0',
  `datecreated` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnotes
#

DROP TABLE IF EXISTS `tblnotes`;

CREATE TABLE `tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` text,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnotifications
#

DROP TABLE IF EXISTS `tblnotifications`;

CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT '0',
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext,
  `additional_data` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('1', '0', '2017-04-03 12:52:41', 'not_task_assigned_to_you', '1', '0', ' ', '4', NULL, '#taskid=1', 'a:1:{i:0;s:14:\"Nhiệm vụ 1\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('2', '0', '2017-04-03 12:52:55', 'not_task_added_you_as_follower', '1', '0', ' ', '4', NULL, '#taskid=1', 'a:1:{i:0;s:14:\"Nhiệm vụ 1\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('3', '0', '2017-04-03 12:53:07', 'not_task_marked_as_complete', '1', '0', ' ', '4', NULL, '#taskid=1', 'a:1:{i:0;s:14:\"Nhiệm vụ 1\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('4', '0', '2017-04-03 12:56:20', 'not_task_assigned_to_you', '1', '0', ' ', '4', NULL, '#taskid=2', 'a:1:{i:0;s:23:\"Chăm sóc khách hàng\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('5', '0', '2017-04-03 12:56:30', 'not_task_marked_as_complete', '1', '0', ' ', '4', NULL, '#taskid=2', 'a:1:{i:0;s:23:\"Chăm sóc khách hàng\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('6', '0', '2017-04-03 12:56:38', 'not_task_unmarked_as_complete', '1', '0', ' ', '4', NULL, '#taskid=2', 'a:1:{i:0;s:23:\"Chăm sóc khách hàng\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('7', '0', '2017-04-03 12:56:52', 'not_task_marked_as_complete', '1', '0', ' ', '4', NULL, '#taskid=2', 'a:1:{i:0;s:23:\"Chăm sóc khách hàng\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('8', '0', '2017-04-03 12:58:07', 'not_task_assigned_to_you', '1', '0', ' ', '4', NULL, '#taskid=3', 'a:1:{i:0;s:23:\"Chăm sóc khách hàng\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('9', '0', '2017-04-03 12:58:08', 'not_task_added_you_as_follower', '1', '0', ' ', '4', NULL, '#taskid=3', 'a:1:{i:0;s:23:\"Chăm sóc khách hàng\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('10', '1', '2017-04-03 12:58:43', 'not_task_new_comment', '4', '0', 'Thùy Linh', '1', NULL, '#taskid=3', 'a:1:{i:0;s:23:\"Chăm sóc khách hàng\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('11', '0', '2017-05-25 14:08:44', 'not_staff_added_as_project_member', '1', '0', ' ', '4', NULL, 'projects/view/1', 'a:1:{i:0;s:3:\"ABC\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('12', '0', '2017-05-25 14:08:44', 'not_staff_added_as_project_member', '1', '0', ' ', '3', NULL, 'projects/view/1', 'a:1:{i:0;s:3:\"ABC\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES ('13', '0', '2017-05-25 14:10:04', 'not_staff_added_as_project_member', '1', '0', ' ', '3', NULL, 'projects/view/2', 'a:1:{i:0;s:3:\"dcb\";}');


#
# TABLE STRUCTURE FOR: tbloptions
#

DROP TABLE IF EXISTS `tbloptions`;

CREATE TABLE `tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;

INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('1', 'dateformat', 'Y-m-d|%Y-%m-%d');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('2', 'companyname', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('3', 'services', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('4', 'maximum_allowed_ticket_attachments', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('5', 'ticket_attachments_file_extensions', '.jpg,.png,.pdf,.doc');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('6', 'staff_access_only_assigned_departments', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('7', 'use_knowledge_base', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('8', 'smtp_email', 'nguyenthuan.fososoft@gmail.com');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('9', 'smtp_password', 'f63cead8f41159d268aad7d7d900ee126d497ae008f549d329170c6f9079c5692cd6a29372e4175bcfb3ed6a8bd09206f3d822f6de5ac554dfd5887e32e2a919tvoCZ2yk7thZiTxeV4LRUIlVL6+yOB33bFJK3ZCuMGU=');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('10', 'smtp_port', '465');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('11', 'smtp_host', 'smtp.gmail.com');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('12', 'smtp_email_charset', 'utf-8');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('13', 'default_timezone', 'Asia/Bangkok');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('14', 'clients_default_theme', 'perfex');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('15', 'company_logo', 'logo.png');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('16', 'tables_pagination_limit', '25');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('17', 'main_domain', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('18', 'allow_registration', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('19', 'knowledge_base_without_registration', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('20', 'email_signature', '---GIẢI PHÁP PHẦN MỀM FOSO---');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('21', 'default_staff_role', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('22', 'newsfeed_maximum_files_upload', '10');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('23', 'newsfeed_maximum_file_size', '5');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('24', 'contract_expiration_before', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('25', 'invoice_prefix', 'INV-');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('26', 'decimal_separator', '.');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('27', 'thousand_separator', ',');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('28', 'currency_placement', 'before');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('29', 'invoice_company_name', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('30', 'invoice_company_address', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('31', 'invoice_company_city', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('32', 'invoice_company_country_code', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('33', 'invoice_company_postal_code', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('34', 'invoice_company_phonenumber', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('35', 'view_invoice_only_logged_in', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('36', 'invoice_number_format', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('37', 'next_invoice_number', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('38', 'cron_send_invoice_overdue_reminder', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('39', 'active_language', 'english');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('40', 'invoice_number_decrement_on_delete', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('41', 'automatically_send_invoice_overdue_reminder_after', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('42', 'automatically_resend_invoice_overdue_reminder_after', '3');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('43', 'expenses_auto_operations_hour', '21');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('44', 'survey_send_emails_per_cron_run', '100');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('45', 'delete_only_on_last_invoice', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('46', 'delete_only_on_last_estimate', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('47', 'create_invoice_from_recurring_only_on_paid_invoices', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('48', 'allow_payment_amount_to_be_modified', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('49', 'send_renewed_invoice_from_recurring_to_email', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('50', 'rtl_support_client', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('51', 'limit_top_search_bar_results_to', '10');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('52', 'estimate_prefix', 'EST-');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('53', 'next_estimate_number', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('54', 'estimate_number_decrement_on_delete', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('55', 'estimate_number_format', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('56', 'estimate_auto_convert_to_invoice_on_client_accept', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('57', 'exclude_estimate_from_client_area_with_draft_status', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('58', 'rtl_support_admin', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('59', 'last_cron_run', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('60', 'show_sale_agent_on_estimates', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('61', 'show_sale_agent_on_invoices', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('62', 'predefined_terms_invoice', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('63', 'predefined_terms_estimate', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('64', 'default_task_priority', '2');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('65', 'dropbox_app_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('66', 'show_expense_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('67', 'only_show_contact_tickets', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('68', 'predefined_clientnote_invoice', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('69', 'predefined_clientnote_estimate', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('70', 'custom_pdf_logo_image_url', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('71', 'favicon', 'favicon.png');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('72', 'auto_backup_enabled', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('73', 'invoice_due_after', '30');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('74', 'google_api_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('75', 'google_calendar_main_calendar', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('76', 'default_tax', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('77', 'show_invoices_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('78', 'show_estimates_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('79', 'show_contracts_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('80', 'show_tasks_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('81', 'show_customer_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('82', 'auto_backup_every', '7');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('83', 'last_auto_backup', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('84', 'output_client_pdfs_from_admin_area_in_client_language', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('85', 'show_lead_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('86', 'aside_menu_active', '{\"aside_menu_active\":[{\"name\":\"als_dashboard\",\"url\":\"\\/\",\"permission\":\"\",\"icon\":\"fa fa-tachometer\",\"id\":\"dashboard\"},{\"name\":\"als_clients\",\"url\":\"clients\",\"permission\":\"customers\",\"icon\":\"fa fa-users\",\"id\":\"customers\"},{\"name\":\"projects\",\"url\":\"projects\",\"permission\":\"\",\"icon\":\"fa fa-bars\",\"id\":\"projects\"},{\"name\":\"als_sales\",\"url\":\"#\",\"permission\":\"\",\"icon\":\"fa fa-balance-scale\",\"id\":\"sales\",\"children\":[{\"name\":\"invoices\",\"url\":\"invoices\\/list_invoices\",\"permission\":\"invoices\",\"icon\":\"\",\"id\":\"child-invoices\"},{\"name\":\"payments\",\"url\":\"payments\",\"permission\":\"payments\",\"icon\":\"\",\"id\":\"child-payments\"}]},{\"name\":\"als_expenses\",\"url\":\"expenses\\/list_expenses\",\"permission\":\"expenses\",\"icon\":\"fa fa-heartbeat\",\"id\":\"expenses\"},{\"name\":\"support\",\"url\":\"tickets\",\"permission\":\"\",\"icon\":\"fa fa-ticket\",\"id\":\"tickets\"},{\"name\":\"als_contracts\",\"url\":\"contracts\",\"permission\":\"contracts\",\"icon\":\"fa fa-file\",\"id\":\"contracts\"},{\"name\":\"als_tasks\",\"url\":\"tasks\\/list_tasks\",\"permission\":\"\",\"icon\":\"fa fa-tasks\",\"id\":\"tasks\"},{\"name\":\"als_leads\",\"url\":\"leads\",\"permission\":\"is_staff_member\",\"icon\":\"fa fa-tty\",\"id\":\"leads\"},{\"name\":\"als_reports\",\"url\":\"#\",\"permission\":\"reports\",\"icon\":\"fa fa-area-chart\",\"id\":\"reports\",\"children\":[{\"name\":\"als_reports_sales_submenu\",\"url\":\"reports\\/sales\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-sales\"},{\"name\":\"als_reports_expenses\",\"url\":\"reports\\/expenses\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-expenses\"},{\"name\":\"als_expenses_vs_income\",\"url\":\"reports\\/expenses_vs_income\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-expenses-vs-income\"},{\"name\":\"als_reports_leads_submenu\",\"url\":\"reports\\/leads\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-leads\"},{\"name\":\"als_kb_articles_submenu\",\"url\":\"reports\\/knowledge_base_articles\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-kb-articles\"}]},{\"name\":\"als_utilities\",\"url\":\"#\",\"permission\":\"\",\"icon\":\"fa fa-cogs\",\"id\":\"utilities\",\"children\":[{\"name\":\"als_media\",\"url\":\"utilities\\/media\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-media\"},{\"name\":\"bulk_pdf_exporter\",\"url\":\"utilities\\/bulk_pdf_exporter\",\"permission\":\"bulk_pdf_exporter\",\"icon\":\"\",\"id\":\"child-bulk-pdf-exporter\"},{\"name\":\"als_calendar_submenu\",\"url\":\"utilities\\/calendar\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-calendar\"},{\"name\":\"als_announcements_submenu\",\"url\":\"announcements\",\"permission\":\"is_admin\",\"icon\":\"\",\"id\":\"child-announcements\"},{\"name\":\"utility_backup\",\"url\":\"utilities\\/backup\",\"permission\":\"is_admin\",\"icon\":\"\",\"id\":\"child-database-backup\"},{\"name\":\"als_activity_log_submenu\",\"url\":\"utilities\\/activity_log\",\"permission\":\"is_admin\",\"icon\":\"\",\"id\":\"child-activity-log\"},{\"name\":\"ticket_pipe_log\",\"url\":\"utilities\\/pipe_log\",\"permission\":\"is_admin\",\"icon\":\"\",\"id\":\"ticket-pipe-log\"}]}]}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('87', 'estimate_expiry_reminder_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('88', 'send_estimate_expiry_reminder_before', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('89', 'leads_default_source', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('90', 'leads_default_status', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('91', 'proposal_expiry_reminder_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('92', 'send_proposal_expiry_reminder_before', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('93', 'default_contact_permissions', 'a:6:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('94', 'pdf_logo_width', '150');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('95', 'aside_menu_inactive', '{\"aside_menu_inactive\":[]}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('96', 'setup_menu_active', '{\"setup_menu_active\":[{\"permission\":\"staff\",\"name\":\"als_staff\",\"url\":\"staff\",\"icon\":\"\",\"id\":\"staff\"},{\"permission\":\"is_admin\",\"name\":\"clients\",\"url\":\"#\",\"icon\":\"\",\"id\":\"customers\",\"children\":[{\"permission\":\"\",\"name\":\"customer_groups\",\"url\":\"clients\\/groups\",\"icon\":\"\",\"id\":\"groups\"}]},{\"permission\":\"\",\"name\":\"support\",\"url\":\"#\",\"icon\":\"\",\"id\":\"tickets\",\"children\":[{\"permission\":\"is_admin\",\"name\":\"acs_departments\",\"url\":\"departments\",\"icon\":\"\",\"id\":\"departments\"},{\"permission\":\"is_admin\",\"name\":\"acs_ticket_predefined_replies_submenu\",\"url\":\"tickets\\/predifined_replies\",\"icon\":\"\",\"id\":\"predifined-replies\"},{\"permission\":\"is_admin\",\"name\":\"acs_ticket_priority_submenu\",\"url\":\"tickets\\/priorities\",\"icon\":\"\",\"id\":\"ticket-priority\"},{\"permission\":\"is_admin\",\"name\":\"acs_ticket_statuses_submenu\",\"url\":\"tickets\\/statuses\",\"icon\":\"\",\"id\":\"ticket-statuses\"},{\"permission\":\"is_admin\",\"name\":\"acs_ticket_services_submenu\",\"url\":\"tickets\\/services\",\"icon\":\"\",\"id\":\"services\"},{\"permission\":\"is_admin\",\"name\":\"spam_filters\",\"url\":\"tickets\\/spam_filters\",\"icon\":\"\",\"id\":\"spam-filters\"}]},{\"permission\":\"is_admin\",\"name\":\"acs_leads\",\"url\":\"#\",\"icon\":\"\",\"id\":\"leads\",\"children\":[{\"permission\":\"\",\"name\":\"acs_leads_sources_submenu\",\"url\":\"leads\\/sources\",\"icon\":\"\",\"id\":\"sources\"},{\"permission\":\"\",\"name\":\"acs_leads_statuses_submenu\",\"url\":\"leads\\/statuses\",\"icon\":\"\",\"id\":\"statuses\"},{\"permission\":\"\",\"name\":\"leads_email_integration\",\"url\":\"leads\\/email_integration\",\"icon\":\"\",\"id\":\"email-integration\"},{\"name\":\"web_to_lead\",\"permission\":\"is_admin\",\"icon\":\"\",\"url\":\"leads\\/forms\",\"id\":\"web-to-lead\"}]},{\"permission\":\"is_admin\",\"name\":\"acs_finance\",\"url\":\"#\",\"icon\":\"\",\"id\":\"finance\",\"children\":[{\"permission\":\"\",\"name\":\"acs_sales_taxes_submenu\",\"url\":\"taxes\",\"icon\":\"\",\"id\":\"taxes\"},{\"permission\":\"\",\"name\":\"acs_sales_currencies_submenu\",\"url\":\"currencies\",\"icon\":\"\",\"id\":\"currencies\"},{\"permission\":\"\",\"name\":\"acs_sales_payment_modes_submenu\",\"url\":\"paymentmodes\",\"icon\":\"\",\"id\":\"payment-modes\"},{\"permission\":\"\",\"name\":\"acs_expense_categories\",\"url\":\"expenses\\/categories\",\"icon\":\"\",\"id\":\"expenses-categories\"}]},{\"permission\":\"is_admin\",\"name\":\"acs_contracts\",\"url\":\"#\",\"icon\":\"\",\"id\":\"contracts\",\"children\":[{\"permission\":\"\",\"name\":\"acs_contract_types\",\"url\":\"contracts\\/types\",\"icon\":\"\",\"id\":\"contract-types\"}]},{\"permission\":\"email_templates\",\"name\":\"acs_email_templates\",\"url\":\"emails\",\"icon\":\"\",\"id\":\"email-templates\"},{\"permission\":\"is_admin\",\"name\":\"asc_custom_fields\",\"url\":\"custom_fields\",\"icon\":\"\",\"id\":\"custom-fields\"},{\"permission\":\"roles\",\"name\":\"acs_roles\",\"url\":\"roles\",\"icon\":\"\",\"id\":\"roles\"},{\"permission\":\"is_admin\",\"name\":\"menu_builder\",\"url\":\"#\",\"icon\":\"\",\"id\":\"menu-builder\",\"children\":[{\"permission\":\"\",\"name\":\"main_menu\",\"url\":\"utilities\\/main_menu\",\"icon\":\"\",\"id\":\"organize-sidebar\"},{\"permission\":\"is_admin\",\"name\":\"setup_menu\",\"url\":\"utilities\\/setup_menu\",\"icon\":\"\",\"id\":\"setup-menu\"}]},{\"name\":\"theme_style\",\"permission\":\"is_admin\",\"icon\":\"\",\"url\":\"utilities\\/theme_style\",\"id\":\"theme-style\"},{\"permission\":\"settings\",\"name\":\"acs_settings\",\"url\":\"settings\",\"icon\":\"\",\"id\":\"settings\"}]}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('97', 'access_tickets_to_none_staff_members', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('98', 'setup_menu_inactive', '{\"setup_menu_inactive\":[]}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('99', 'customer_default_country', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('100', 'view_estimate_only_logged_in', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('101', 'show_status_on_pdf_ei', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('102', 'email_piping_only_replies', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('103', 'email_piping_only_registered', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('104', 'default_view_calendar', 'month');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('105', 'email_piping_default_priority', '2');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('106', 'total_to_words_lowercase', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('107', 'show_tax_per_item', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('108', 'last_survey_send_cron', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('109', 'total_to_words_enabled', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('110', 'receive_notification_on_new_ticket', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('111', 'autoclose_tickets_after', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('112', 'media_max_file_size_upload', '10');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('113', 'client_staff_add_edit_delete_task_comments_first_hour', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('114', 'show_projects_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('115', 'leads_kanban_limit', '50');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('116', 'tasks_reminder_notification_before', '2');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('117', 'pdf_font', 'freesans');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('118', 'pdf_table_heading_color', '#323a45');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('119', 'pdf_table_heading_text_color', '#ffffff');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('120', 'pdf_font_size', '10');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('121', 'defaut_leads_kanban_sort', 'leadorder');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('122', 'defaut_leads_kanban_sort_type', 'asc');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('123', 'allowed_files', '.gif,.png,.jpeg,.jpg,.pdf,.doc,.txt,.docx,.xls,.zip,.rar,.xls,.mp4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('124', 'show_all_tasks_for_project_member', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('125', 'email_protocol', 'mail');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('126', 'calendar_first_day', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('127', 'recaptcha_secret_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('128', 'show_help_on_setup_menu', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('129', 'show_proposals_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('130', 'smtp_encryption', 'ssl');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('131', 'recaptcha_site_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('132', 'smtp_username', 'nguyenthuan.fososoft@gmail.com');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('133', 'auto_stop_tasks_timers_on_new_timer', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('134', 'notification_when_customer_pay_invoice', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('135', 'theme_style', '[]');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('136', 'calendar_invoice_color', '#FF6F00');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('137', 'calendar_estimate_color', '#FF6F00');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('138', 'calendar_proposal_color', '#84c529');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('139', 'calendar_task_color', '#FC2D42');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('140', 'calendar_reminder_color', '#03A9F4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('141', 'calendar_contract_color', '#B72974');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('142', 'calendar_project_color', '#B72974');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('143', 'update_info_message', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('144', 'show_estimate_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('145', 'show_invoice_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('146', 'show_proposal_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('147', 'proposal_due_after', '7');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('148', 'allow_customer_to_change_ticket_status', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('149', 'lead_lock_after_convert_to_customer', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('150', 'default_proposals_pipeline_sort', 'pipeline_order');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('151', 'defaut_proposals_pipeline_sort_type', 'asc');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('152', 'default_estimates_pipeline_sort', 'pipeline_order');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('153', 'defaut_estimates_pipeline_sort_type', 'asc');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('154', 'use_recaptcha_customers_area', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('155', 'remove_decimals_on_zero', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('156', 'remove_tax_name_from_item_table', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('157', 'pdf_format_invoice', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('158', 'pdf_format_estimate', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('159', 'pdf_format_proposal', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('160', 'pdf_format_payment', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('161', 'pdf_format_contract', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('162', 'pdf_text_color', '#000000');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('163', 'auto_check_for_new_notifications', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('164', 'swap_pdf_info', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('165', 'exclude_invoice_from_client_area_with_draft_status', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('166', 'cron_has_run_from_cli', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('167', 'hide_cron_is_required_message', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('168', 'auto_assign_customer_admin_after_lead_convert', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('169', 'show_transactions_on_invoice_pdf', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('170', 'show_pay_link_to_invoice_pdf', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('171', 'tasks_kanban_limit', '50');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('172', 'purchase_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('173', 'estimates_pipeline_limit', '50');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('174', 'proposals_pipeline_limit', '50');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('175', 'proposal_number_prefix', 'PRO-');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('176', 'number_padding_prefixes', '6');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('177', 'show_page_number_on_pdf', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('178', 'calendar_events_limit', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('179', 'show_setup_menu_item_only_on_hover', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('180', 'company_requires_vat_number_field', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('181', 'company_is_required', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('182', 'allow_contact_to_delete_files', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('183', 'company_vat', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('184', 'di', '1490858650');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('185', 'invoice_auto_operations_hour', '21');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('186', 'use_minified_files', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('187', 'only_own_files_contacts', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('188', 'allow_primary_contact_to_view_edit_billing_and_shipping', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('189', 'estimate_due_after', '7');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('190', 'delete_backups_older_then', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('191', 'staff_members_open_tickets_to_all_contacts', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('192', 'paymentmethod_stripe_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('193', 'paymentmethod_stripe_label', 'Stripe');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('194', 'paymentmethod_stripe_api_secret_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('195', 'paymentmethod_stripe_api_publishable_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('196', 'paymentmethod_stripe_currencies', 'USD,CAD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('197', 'paymentmethod_stripe_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('198', 'paymentmethod_stripe_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('199', 'paymentmethod_two_checkout_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('200', 'paymentmethod_two_checkout_label', '2Checkout');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('201', 'paymentmethod_two_checkout_account_number', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('202', 'paymentmethod_two_checkout_private_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('203', 'paymentmethod_two_checkout_publishable_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('204', 'paymentmethod_two_checkout_currencies', 'USD,EUR');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('205', 'paymentmethod_two_checkout_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('206', 'paymentmethod_two_checkout_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('207', 'paymentmethod_paypal_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('208', 'paymentmethod_paypal_label', 'Paypal');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('209', 'paymentmethod_paypal_username', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('210', 'paymentmethod_paypal_password', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('211', 'paymentmethod_paypal_signature', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('212', 'paymentmethod_paypal_currencies', 'EUR,USD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('213', 'paymentmethod_paypal_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('214', 'paymentmethod_paypal_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('215', 'paymentmethod_paypal_braintree_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('216', 'paymentmethod_paypal_braintree_label', 'Braintree');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('217', 'paymentmethod_paypal_braintree_merchant_id', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('218', 'paymentmethod_paypal_braintree_api_public_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('219', 'paymentmethod_paypal_braintree_api_private_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('220', 'paymentmethod_paypal_braintree_currencies', 'USD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('221', 'paymentmethod_paypal_braintree_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('222', 'paymentmethod_paypal_braintree_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('223', 'paymentmethod_authorize_sim_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('224', 'paymentmethod_authorize_sim_label', 'Authorize.net');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('225', 'paymentmethod_authorize_sim_api_login_id', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('226', 'paymentmethod_authorize_sim_api_transaction_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('227', 'paymentmethod_authorize_sim_api_secret_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('228', 'paymentmethod_authorize_sim_currencies', 'USD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('229', 'paymentmethod_authorize_sim_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('230', 'paymentmethod_authorize_sim_test_mode_enabled', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('231', 'paymentmethod_authorize_sim_developer_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('232', 'paymentmethod_mollie_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('233', 'paymentmethod_mollie_label', 'Mollie');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('234', 'paymentmethod_mollie_api_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('235', 'paymentmethod_mollie_currencies', 'EUR');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('236', 'paymentmethod_mollie_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('237', 'paymentmethod_mollie_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('238', 'paymentmethod_authorize_aim_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('239', 'paymentmethod_authorize_aim_label', 'Authorize.net');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('240', 'paymentmethod_authorize_aim_api_login_id', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('241', 'paymentmethod_authorize_aim_api_transaction_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('242', 'paymentmethod_authorize_aim_currencies', 'USD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('243', 'paymentmethod_authorize_aim_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('244', 'paymentmethod_authorize_aim_test_mode_enabled', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('245', 'paymentmethod_authorize_aim_developer_mode_enabled', '1');


#
# TABLE STRUCTURE FOR: tblpermissions
#

DROP TABLE IF EXISTS `tblpermissions`;

CREATE TABLE `tblpermissions` (
  `permissionid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `shortname` mediumtext NOT NULL,
  PRIMARY KEY (`permissionid`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('1', 'Contracts', 'contracts');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('2', 'Tasks', 'tasks');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('3', 'Reports', 'reports');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('4', 'Settings', 'settings');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('5', 'Projects', 'projects');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('6', 'Surveys', 'surveys');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('7', 'Staff', 'staff');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('8', 'Customers', 'customers');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('9', 'Email Templates', 'email_templates');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('10', 'Roles', 'roles');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('11', 'Estimates', 'estimates');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('12', 'Knowledge base', 'knowledge_base');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('13', 'Proposals', 'proposals');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('14', 'Goals', 'goals');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('15', 'Expenses', 'expenses');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('16', 'Bulk PDF Exporter', 'bulk_pdf_exporter');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('17', 'Payments', 'payments');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('18', 'Invoices', 'invoices');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('19', 'Items', 'items');


#
# TABLE STRUCTURE FOR: tblpinnedprojects
#

DROP TABLE IF EXISTS `tblpinnedprojects`;

CREATE TABLE `tblpinnedprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpostcomments
#

DROP TABLE IF EXISTS `tblpostcomments`;

CREATE TABLE `tblpostcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpostlikes
#

DROP TABLE IF EXISTS `tblpostlikes`;

CREATE TABLE `tblpostlikes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblposts
#

DROP TABLE IF EXISTS `tblposts`;

CREATE TABLE `tblposts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpredifinedreplies
#

DROP TABLE IF EXISTS `tblpredifinedreplies`;

CREATE TABLE `tblpredifinedreplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpricebds
#

DROP TABLE IF EXISTS `tblpricebds`;

CREATE TABLE `tblpricebds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price_min` double NOT NULL,
  `price_max` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblpricebds` (`id`, `price_min`, `price_max`) VALUES ('1', '0', '5000000');
INSERT INTO `tblpricebds` (`id`, `price_min`, `price_max`) VALUES ('2', '5000000', '10000000');
INSERT INTO `tblpricebds` (`id`, `price_min`, `price_max`) VALUES ('3', '10000000', '15000000');
INSERT INTO `tblpricebds` (`id`, `price_min`, `price_max`) VALUES ('4', '15000000', '20000000');
INSERT INTO `tblpricebds` (`id`, `price_min`, `price_max`) VALUES ('5', '20000000', '30000000');
INSERT INTO `tblpricebds` (`id`, `price_min`, `price_max`) VALUES ('6', '30000000', '40000000');


#
# TABLE STRUCTURE FOR: tblpriorities
#

DROP TABLE IF EXISTS `tblpriorities`;

CREATE TABLE `tblpriorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblpriorities` (`priorityid`, `name`) VALUES ('1', 'Low');
INSERT INTO `tblpriorities` (`priorityid`, `name`) VALUES ('2', 'Medium');
INSERT INTO `tblpriorities` (`priorityid`, `name`) VALUES ('3', 'High');


#
# TABLE STRUCTURE FOR: tblprojectactivity
#

DROP TABLE IF EXISTS `tblprojectactivity`;

CREATE TABLE `tblprojectactivity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT '0',
  `description_key` varchar(500) NOT NULL COMMENT 'Language file key',
  `additional_data` text,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tblprojectactivity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES ('1', '1', '1', '0', ' ', '1', 'project_activity_added_team_member', 'Thùy Linh', '2017-05-25 14:08:44');
INSERT INTO `tblprojectactivity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES ('2', '1', '1', '0', ' ', '1', 'project_activity_added_team_member', 'Ngọc Hà', '2017-05-25 14:08:44');
INSERT INTO `tblprojectactivity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES ('3', '1', '1', '0', ' ', '1', 'project_activity_created', '', '2017-05-25 14:08:44');
INSERT INTO `tblprojectactivity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES ('4', '2', '1', '0', ' ', '1', 'project_activity_added_team_member', 'Ngọc Hà', '2017-05-25 14:10:04');
INSERT INTO `tblprojectactivity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES ('5', '2', '1', '0', ' ', '1', 'project_activity_created', '', '2017-05-25 14:10:04');


#
# TABLE STRUCTURE FOR: tblprojectdiscussioncomments
#

DROP TABLE IF EXISTS `tblprojectdiscussioncomments`;

CREATE TABLE `tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` text NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT '0',
  `fullname` varchar(300) DEFAULT NULL,
  `file_name` varchar(300) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectdiscussions
#

DROP TABLE IF EXISTS `tblprojectdiscussions`;

CREATE TABLE `tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `contact_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectfiles
#

DROP TABLE IF EXISTS `tblprojectfiles`;

CREATE TABLE `tblprojectfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` mediumtext NOT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `description` text,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT '0',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `external` varchar(40) DEFAULT NULL,
  `external_link` text,
  `thumbnail_link` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectmembers
#

DROP TABLE IF EXISTS `tblprojectmembers`;

CREATE TABLE `tblprojectmembers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblprojectmembers` (`id`, `project_id`, `staff_id`) VALUES ('1', '1', '4');
INSERT INTO `tblprojectmembers` (`id`, `project_id`, `staff_id`) VALUES ('2', '1', '3');
INSERT INTO `tblprojectmembers` (`id`, `project_id`, `staff_id`) VALUES ('3', '2', '3');


#
# TABLE STRUCTURE FOR: tblprojectmenu
#

DROP TABLE IF EXISTS `tblprojectmenu`;

CREATE TABLE `tblprojectmenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `project_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `project` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cost` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_menu` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `project_parent` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tblprojectmenu` (`id`, `code`, `project_name`, `project`, `price`, `cost`, `id_menu`, `status`, `project_parent`) VALUES ('28', '2', 'Căn hộ B', '59', '20000000', '1', '0', '0', '58');
INSERT INTO `tblprojectmenu` (`id`, `code`, `project_name`, `project`, `price`, `cost`, `id_menu`, `status`, `project_parent`) VALUES ('29', '3', 'Căn hộ C', '59', '50000000', '2', '0', '0', '58');
INSERT INTO `tblprojectmenu` (`id`, `code`, `project_name`, `project`, `price`, `cost`, `id_menu`, `status`, `project_parent`) VALUES ('34', '1', 'Biệt Thự Hoa Mai', '61', '100000000', '2', '0', '2', '49');


#
# TABLE STRUCTURE FOR: tblprojectnotes
#

DROP TABLE IF EXISTS `tblprojectnotes`;

CREATE TABLE `tblprojectnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojects
#

DROP TABLE IF EXISTS `tblprojects`;

CREATE TABLE `tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `description` text,
  `status` int(11) NOT NULL DEFAULT '0',
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT '0',
  `progress_from_tasks` int(11) NOT NULL DEFAULT '1',
  `project_cost` decimal(11,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(11,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblprojects` (`id`, `name`, `description`, `status`, `clientid`, `billing_type`, `start_date`, `deadline`, `project_created`, `date_finished`, `progress`, `progress_from_tasks`, `project_cost`, `project_rate_per_hour`, `addedfrom`) VALUES ('1', 'ABC', '', '1', '1', '1', '2017-05-25', '2017-05-31', '2017-05-25', NULL, '0', '1', '0.00', '0.00', '1');
INSERT INTO `tblprojects` (`id`, `name`, `description`, `status`, `clientid`, `billing_type`, `start_date`, `deadline`, `project_created`, `date_finished`, `progress`, `progress_from_tasks`, `project_cost`, `project_rate_per_hour`, `addedfrom`) VALUES ('2', 'dcb', '', '1', '2', '2', '2017-05-08', '2017-05-24', '2017-05-25', NULL, '0', '1', '0.00', '1.00', '1');


#
# TABLE STRUCTURE FOR: tblprojectsettings
#

DROP TABLE IF EXISTS `tblprojectsettings`;

CREATE TABLE `tblprojectsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('1', '1', 'view_tasks', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('2', '1', 'comment_on_tasks', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('3', '1', 'view_task_comments', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('4', '1', 'view_task_attachments', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('5', '1', 'view_task_checklist_items', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('6', '1', 'upload_on_tasks', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('7', '1', 'view_task_total_logged_time', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('8', '1', 'view_finance_overview', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('9', '1', 'upload_files', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('10', '1', 'open_discussions', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('11', '1', 'view_milestones', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('12', '1', 'view_gantt', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('13', '1', 'view_timesheets', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('14', '1', 'view_activity_log', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('15', '1', 'view_team_members', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('16', '2', 'view_tasks', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('17', '2', 'comment_on_tasks', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('18', '2', 'view_task_comments', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('19', '2', 'view_task_attachments', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('20', '2', 'view_task_checklist_items', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('21', '2', 'upload_on_tasks', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('22', '2', 'view_task_total_logged_time', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('23', '2', 'view_finance_overview', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('24', '2', 'upload_files', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('25', '2', 'open_discussions', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('26', '2', 'view_milestones', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('27', '2', 'view_gantt', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('28', '2', 'view_timesheets', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('29', '2', 'view_activity_log', '1');
INSERT INTO `tblprojectsettings` (`id`, `project_id`, `name`, `value`) VALUES ('30', '2', 'view_team_members', '1');


#
# TABLE STRUCTURE FOR: tblproposalcomments
#

DROP TABLE IF EXISTS `tblproposalcomments`;

CREATE TABLE `tblproposalcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproposals
#

DROP TABLE IF EXISTS `tblproposals`;

CREATE TABLE `tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(500) DEFAULT NULL,
  `content` longtext,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(11,2) DEFAULT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL DEFAULT '0.00',
  `adjustment` decimal(11,2) DEFAULT NULL,
  `discount_percent` decimal(11,2) NOT NULL,
  `discount_total` decimal(11,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(600) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT '0',
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) NOT NULL DEFAULT '0',
  `is_expiry_notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblreminders
#

DROP TABLE IF EXISTS `tblreminders`;

CREATE TABLE `tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT '0',
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT '1',
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblrolepermissions
#

DROP TABLE IF EXISTS `tblrolepermissions`;

CREATE TABLE `tblrolepermissions` (
  `rolepermissionid` int(11) NOT NULL AUTO_INCREMENT,
  `roleid` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_own` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `permissionid` int(11) NOT NULL,
  PRIMARY KEY (`rolepermissionid`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('1', '1', '1', '0', '0', '0', '0', '16');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('2', '1', '1', '0', '0', '0', '0', '1');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('3', '1', '1', '0', '0', '0', '0', '8');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('4', '1', '1', '0', '0', '0', '0', '9');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('5', '1', '0', '0', '0', '0', '0', '11');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('6', '1', '0', '0', '0', '0', '0', '15');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('7', '1', '1', '0', '0', '0', '0', '14');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('8', '1', '0', '0', '0', '0', '0', '18');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('9', '1', '1', '0', '0', '0', '0', '19');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('10', '1', '1', '0', '0', '0', '0', '12');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('11', '1', '1', '0', '0', '0', '0', '17');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('12', '1', '0', '0', '0', '0', '0', '5');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('13', '1', '1', '0', '0', '0', '0', '13');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('14', '1', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('15', '1', '1', '0', '0', '0', '0', '10');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('16', '1', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('17', '1', '0', '0', '0', '0', '0', '7');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('18', '1', '1', '0', '0', '0', '0', '6');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('19', '1', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('20', '2', '0', '0', '0', '0', '0', '16');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('21', '2', '1', '0', '0', '0', '0', '1');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('22', '2', '1', '0', '0', '0', '0', '8');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('23', '2', '0', '0', '0', '0', '0', '9');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('24', '2', '0', '0', '0', '0', '0', '11');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('25', '2', '0', '0', '0', '0', '0', '15');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('26', '2', '0', '0', '0', '0', '0', '14');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('27', '2', '0', '0', '0', '0', '0', '18');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('28', '2', '0', '0', '0', '0', '0', '19');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('29', '2', '1', '0', '0', '0', '0', '12');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('30', '2', '0', '0', '0', '0', '0', '17');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('31', '2', '1', '0', '0', '0', '0', '5');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('32', '2', '0', '0', '0', '0', '0', '13');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('33', '2', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('34', '2', '0', '0', '0', '0', '0', '10');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('35', '2', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('36', '2', '0', '0', '0', '0', '0', '7');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('37', '2', '0', '0', '0', '0', '0', '6');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('38', '2', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('39', '3', '0', '0', '0', '0', '0', '16');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('40', '3', '1', '0', '0', '0', '0', '1');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('41', '3', '1', '0', '0', '0', '0', '8');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('42', '3', '0', '0', '0', '0', '0', '9');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('43', '3', '1', '0', '0', '0', '0', '11');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('44', '3', '1', '0', '0', '0', '0', '15');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('45', '3', '0', '0', '0', '0', '0', '14');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('46', '3', '1', '0', '0', '0', '0', '18');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('47', '3', '1', '0', '0', '0', '0', '19');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('48', '3', '1', '0', '0', '0', '0', '12');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('49', '3', '1', '0', '0', '0', '0', '17');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('50', '3', '0', '0', '0', '0', '0', '5');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('51', '3', '0', '0', '0', '0', '0', '13');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('52', '3', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('53', '3', '1', '0', '0', '0', '0', '10');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('54', '3', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('55', '3', '1', '0', '0', '0', '0', '7');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('56', '3', '0', '0', '0', '0', '0', '6');
INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES ('57', '3', '0', '0', '0', '0', '0', '2');


#
# TABLE STRUCTURE FOR: tblroles
#

DROP TABLE IF EXISTS `tblroles`;

CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblroles` (`roleid`, `name`) VALUES ('1', 'Sale');
INSERT INTO `tblroles` (`roleid`, `name`) VALUES ('2', 'Nghiệp Vụ');
INSERT INTO `tblroles` (`roleid`, `name`) VALUES ('3', 'Kế toán');


#
# TABLE STRUCTURE FOR: tblsalesactivity
#

DROP TABLE IF EXISTS `tblsalesactivity`;

CREATE TABLE `tblsalesactivity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `additional_data` varchar(600) DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblservices
#

DROP TABLE IF EXISTS `tblservices`;

CREATE TABLE `tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsessions
#

DROP TABLE IF EXISTS `tblsessions`;

CREATE TABLE `tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d74a5d7fc4723486ae728455588f63af371390c0', '66.102.6.153', '1496110567', 'Q4V7uruvmPobZx1Ham1eNDKNyfJ21AWTKpFpsGlQW4uM8xHhmzCcPz5k6ojZ8Fswu7OdOAeiTjOWBSZPzfHlxg..');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d8c62ace948e607c60cc857151ed262928fa414', '171.232.85.48', '1496111179', 'K6Khvouf_SJWAfOfatyd5xOWduSX8tnqsVRcIEowcB4qr6lYwFwAwhZ2Nl_hEA4Lwg5EG6KO2XWBzECUz9pqMuUunfhECrNG3tK9d5edRlvZzIURxucJI5BRSa2x_N4j');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9e12189d4d61e502123190397de6ba17b983dcf3', '117.6.132.124', '1496115994', 'vKlg3mjBq0WuDWS33Kp6iP9Nac0XZvzEx-whYcBMsgJSjkOT7n0UkVJVhWr4BDaIawd2c-tEbTouHCsbc1qOlfTRpLEHncas3aOqiyeBk_ojmj2dgELb5Z6kFQOxd7QFfk5_gLK0MOqp0iUfMFyL7nNlin9MzojW4r0_tPfmbi0zwxqde1tdkdPejZLHqP0eKIYfl1cn3qOWjxJPU3mx-q73gji9jQJtnUHlO8-0eyUJbxGq5XiTvsGTiNOA51QnSgqCa_E-yW27qLbHJSDeLR42gSaYK6kDD_N47qbxd8bWH0zC3rxTjTDbEyfSGIaHsvt8S7OLvODeEXB_tW_U-xPl2PJl1ELu2H-wzHSut9fCAdEuBeeZkCYUvUBpJ5H8Lk_vnrJMvzuydie-vjUTtR7ES_-pRWCa-AfUW1Ogm9la7XBh09IJ3fZZV6bc30DZNKK8s_Hh-a8hbP21wNcuiYQ7ynW1EJc41R8nyT5g9mcEl0CLph02ANhGi40gqBVcGJBou8rZcgkqELGrXFbWdANhMOs0oMCohANOHdJ-2PVRcY1buQdQbikZ_lb1ZTKcigKo9j7RymnMWwyk85U-ech4HgMHaC0e-SEV2i5gqWoQuR2aqlcZaqLlrnaa5ZUaZ-GJX0SqxrCt42RYr4HrVm2TME9Hu36vZf3aUvCXCcCgT79Ra2whEyHumDyFLWikoTf_VZfuIvkk_N7Qg3nKSGwgBHrY1M-GSoCBw7XCLZ-AicEUduWjVlM_MkqzN0VsSVBoThh3hIa0XHcGlV_hh7qHSSiy_7iFLg9UmvxdawqYAmqWdO3HIFcShZ03JC6ovOGw3l9UamjQjoHyVwQKg6u3Mx2910E5mTv7pcaR-W4-YsxzCIlcWnqop0FZMKghPRHChuhAW2mqrsRxAfT1l2UD4-5s_68bQrAqQwANgOGJnDNHFxTa-ayefIdqQ9eErU51-8SlYc_lEmB38DUFZN9ToIcHiEHrkOPa3AJlnrhUsFAToUpWLe1Oo1VuJTBl5v8ieFaYTuDcKGqw_JKn1xhB-bSfLtArkhAXpTuRrdyotzxbH0NM6kV7AOmVcRYnXs-ngv_ZQMGZrtVeSXMRnJ0OOAPppw1kT39JTityFdL1KUBW9E3nUTfsdOhKLqj5u_qsM0qAk-Qo6IkNFeL-Qvbdd1mbeJwEg3Bi4ZVXdrgrUiHYGDTIWxI_UXFKNjKFdfab7eL_TX-UMmwJBf2AF03dC_y5MzL4CKiG2bUXv8xdpOmUAsfGapwejDuHN_cA0t4I8zQp63S075GENCkaulAK8aZeH2nk2upRFeCA8s1i017_iiA3tdd7mVEBV-mhjlIe44-bebRH4gQwSEa_RBg1I2-HSVeevAvo5c_sR1ADJ51aT5cbcdHvI3ijARNPfIf_dKpSwkgW2HyvvBUDGPCzSNhpBhIjKB6w7zXJgfeXA_XFtQZaRHsfLv64_DHJBCEIPiTob2LMeEXdJbKLsTu8z8qQUV5E7mqILERgV4aCjMJ8WH0Ajm95h-I6UpNubRZFLFwDh5JyBl0xLJFHuvj19jjb24RFODZ-L4kTLkzw4obqYlr_LV3fv1PILMtasW4aWUuK_o17GY5dnUhK24eROK4jmRITBfpQDW3capiVIEiu7OSIb05cBX8MxgDPoyy6bawpMTC8mBedQoFljn4mEQ00BAOOqFwk31LJikYQBFye6jA5WQ6t20Mmf_omxScC1ioO9fQGhNMfWNHzqz4Fboe4E8xCPG3VSeP056OMqRRnTeHmF-NTTy6v9vG-ZwulrjIrO-U0DvZfOLGwb7TO35GxviWL-ctSKwcFXKMnXof2w5AjG3brjK3s4Rmid9z57RzwwlNtbJuo9-br4QboMV_zRyqV27iBfDuSe5yxGICMpWqqq2mgvONeoYXEkEKki3jkrwF_aJyDQWXvNqET7wv3ZmP_iavqYc0Wjv84_FAwLBFHWFB-CKkR4lJ6itauPyRB9HZ1XXvoFLyCMBTyv3KNh-na7oMaA9XzTHOWMJahus3JhPoHftcyWJHkLbHG7W7Lliv3ifTx4PRtoymJpegUOc58uSGJ-CgFimEDKxKO4CYxgJH0SpAAT6LxleuqpLXBT0264SE47xysvLnFsIAHpZ68hZbKf-9VwzSrsWzC9AS4BrY4Msli0QoszQ7u5hch03pZ91pUAxX9CBBfTf8SDzMHVMF3hf57zueO4zu-jOdwTUTv1zAzH7mmIM5TElJk5MxGNdErGHGF6Hls3_9QIbNF2N9vrXjAPZY5_nHV9L57ojoTJpoCvhkHbdnWkjuWRd9yik77G43KIcSj-TSAEWVeGHT2wNHaY0DrdF-uJ6n-6YHOcfz9GAwII-8HZQ9igyqRv0aha--uFvtL11vQy6CGJBwEhqWU474QFYs8lc08SMwdGpEks99f0PnH-42CwSV__2w2zPxr_AoMbZDZgWnxSvBdoSdkh3Ft0q4j1W6xwgMCgDbkXJSLMeDYnM0xnt2f96U7M6EHU3UR7Hur33mKIPkKyQ3LlG4tl7yvrkJsvxiXxsHNeQQmMA3szAwZmqH5jnvUyEjMKWmEWIsmhbMiJOc6ZR0vMURh3DJva1FoRu9-Nx3PPm6knUxNrA-awNiB_uX3tSmLqLU1lh2XskRmO1RBHHrbSlzHWlJle7PdDu3hVUoZqSnsP0U6F_8Fg_N4C6W9uMl-xuMBPGL8soIFWDK-i9Q3bBquhBKpXJNtEksp4fihwhw26xTRWHDf9-oClCZ07Uya6Q..');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cae948156c2f223a4836ce5bc508f807775082ec', '171.232.85.48', '1496116463', 'BdBzxL_NIYj4zGLtSB_p2HLg8vH9oS6m7uz4F2oe1rWKA_pTlmWQd4hCv5kvTtk1W1-WC3G-Cj3frkkh3bft_YNve3p2s-7VVDrxiiTfRUE4gUoTKSgh_kQ27DB18ywQ');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('26889da8bc4d243ee475d5b3e9928352300ac6bd', '14.169.252.140', '1496118692', '-dpvO6gUrVPTgjPJd5EL6e7GiBKr4TyODV6zoyNBtxC-Mh7wU2wxFTy83B5wrBlHxGdjUpg0WKl7bAHDLc8Vu8JVirpZc2P47sV7CAgfQAgzAYr0bY2oLkOYysrVmUam');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aef8be374c4e7bb19f7c11102a23d0e58b4ab01f', '14.169.252.140', '1496119024', 'WA21VRLtK-yBWX_R20hnrVmLR_-iEkLdaA2zgpx7wLqAYm_NH6-iJRXChcNGakgPdZjZdcH4RG9Fw3Tb4e13NwTXbylJkI8pzf8JuPNchjpSsdCpMxW4Zb_86uPTTT5G');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aaa27669af87f1e0d737f7f1109518fb691a74ef', '14.169.252.140', '1496119514', 'M3Q8Td2oiGbYAWfSom7wQX-REzH8-t5KS1EghRdqv6xNVN1GZOxWxQzFlQOy1e2mPrJD3UH3TXhV8ICQDNg2G0ZislvI5q0g8UPXLylvoaDKJX2oIveGO7gBbssSutwQ7EQVK3YoscoS7iX9IIbt2yYdY7pu9Ii7yxEqUNvtJf8.');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('13603a8b0cd16b63b8a76df8b94d3a1a15df306e', '14.169.252.140', '1496119861', '6cAsxTe5ITdS6goHuWlyMg2f5vkglu9m4uU2XClicagrA3LzrI6ESxSf6f_S59p_vxJOMDMolNMwT6oAMaLAzmbUcvkmbkdfbdbw7PXGmpS1xIJFVgKad3OBttZr8KDIOxnTqgHJpiMj7-skUBw0B28qsfEOT2m6CeNC72tqVNo.');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('29386854112587535ade7660475f827ea8f983d5', '14.169.252.140', '1496120229', 'UESDNiOWPfG9_6Hb4RAo7_X3WtCdD9Mt_t2ZDnCV3lu_v9okDdoiEihZIYwO5eTbafWLp-oj5E6aHr-zWULXxZKKJd_7jsabCivsYd7TLFSF-ziz4T8jdzbSUwRgmcdqdXiZckhifmHQMT36wC3jyHyz2eDLkNGpfVSpTldIn2s.');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('59bacc3b763f116a074929c365650f307be79fdb', '14.169.252.140', '1496120545', 'OEs3WyG9BSq_XqlAUkWVuRs0GkQeCcoXMnJuMJuYEwx2WuRzBAeaRl2VFZWxRE-0_NGGevvGo2PET22ry5zOFL6lvbRn8f9y65UFpv74SudURA-bkTtzVrL-u480xse8BVZxVmQoWF4PGcCDf_CFRNgOOhGoPRtXr2rSJPdkNDE.');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88bb72d106ca681a80eee0038a5b1be2a7493662', '14.169.252.140', '1496120869', 'd2r_QUz49yrluK-OHksuANM_kxluiVROar4uytPcoSlFGABz4izKgNXSmSm-A7-RPR68qjX3xsiDp58OsA6AI7-3kD7LLRZJ6UiKLgb0fPA5QZqUjypHwzXJBEyZXf-PAiK36OhDNCmX7nTyI1swZRkoUN23fqlZCx8vm_PXP-8.');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3885d940a0acd2944af3ab3b3780c5b59dcce00a', '14.169.252.140', '1496121168', 'Xy_2cgx674WmSjU7wrc5Ya1EX_JA6TnMXxbxClNJRhEv6Zsla-xQRDOgyC1RIDduhn-lqyJDzixYbeZQP45Y7NsISEkldhZsZi8_L6NwplqIxWSuMdAgV5f4sV9oybNIaXzV-GTnUml47FOzgkCzYFdIUARQ_IkPK-NGg0AHIVajYZCZ_rWXt-WgiJcZB61Q');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5a80ee0fa529d6cb9d689091be411e2efd1c69b0', '14.169.252.140', '1496127245', 'jjknW-GTOa9yudOjWmVthimk_y6RMMasKoIpqHXxu63o2spwZVmgUfc4ROdNc-4FMwt_C04AKhXGIEP7wIU5oeNCpwQcN67INssDVUouk52ioiEKNWCTQdbPDreZd_dePZ6PUkXBs0LMAiX-HQnhipy0M3jogYaoJ9H7tQEs2derEic05-KDu2O6PklX8bV4d7tz1hvo0gI1UASexV87rw..');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6408b6d9492b3ab8693b78c9bc44ad7e2315cadb', '14.169.252.140', '1496124718', 'aVfqMMr4xMzpjG9MftqoRdBRliKZO_EkE6NN2g-cI6TZWOzsPQlZuQRHUzcyJUCzc2INQ0X7l-Aphm1DZfmCtzUmqfT3GZ7e1rscxGXVx2tdVxSxpRt2bi2tdwes2KSo');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25aeaf0ae6da54b4cc4ed3ccf2605c5c24efcfe5', '14.169.252.140', '1496125323', '8gcX-FD44k7at1DStVD6z139cHebCfhTxinXv7Hlt0KtyDWesdyPsALXQVjCw4VLkPAiOTe3ius8EuB_baBhvfmdKtqqq8xJf4fno7JDhv7arfKHVPUU-e3e52ci4Msd');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7a6eb930b401feaac0af9b70de04d62aa86f78f4', '14.169.252.140', '1496125638', 'jHCSrhhnmIMKApNE5T-8FR2TcrwV3w6RmTm3RrYpwFX5C0vbgtsQ5xGncb5r9r8GsNzJSL_hkhy1G5_lrOTw0JvyjfCjosBobN4atQNox-U1jKy0WwOZIVU_cbhj5qlW');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37d9ad89f4d4acd2b90554ade0abb729244ab515', '14.169.252.140', '1496125890', 'CCVFs7IAsbbDRzfXG_JBtcsGhz0zltcg-sHcNZO-XIFhWPzSTT-Kklz9Z8St6s7IH9nOo5fHYI9-uz3Mc4hRqYyxtQYnJ67r7-8Am8QJluC6159J-AB_WIdqI-lfdJTf');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('268dafdc3f7257e68352e9c8e29841c0f54c5ead', '14.169.252.140', '1496126394', '4hmbmXd4ynh9MkWzZkVXFPGt8udrhef7FkActEehZXSFb5ugys3d0Ry0q-DLDlT2aBdeLy8lK3D2abGXC8DybMS6NB8w_6E9_aqiLDLzhi9s9aC1wvZiEP4oUW-a-gtG');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23864f05588f31313a70a54dd6454ccfca9bdf28', '14.169.252.140', '1496126667', '5UGoWbQlGXOoJCzhhmaZ1IsPVgcgG6p2kCeomgEDmQq9yaVtkV62omh_l2y-DYlrOFDkuxPYcvYsDV_erIWW9asc4HO_Kw5CD5GvtQhG-7U108J4N7soyrxCRZSu5qQJ');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ea4e3ade388e54d15d0f91735b127ba9e944028', '14.169.252.140', '1496126999', 'wboo6NToumrHTuy_fEUI2iwdiwwUH8rtTgErowJIG9yG2wmW22paU884xtFL1cv0ZaIanYkb-oPn9FU-b4KhOno2CQvRumbq0aYk83b3TxT7BuHhoFjjIgX-8sTvvZVp');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1cf536ed1d04d47cda2481370a666a030718c9e3', '14.169.252.140', '1496127235', 'nJVW1NEROrAMGeRSViQQ7uvIj-tlbNKKFKK842E0s9Vsq6IQq6Iy5kDQgf5_GG197GH3-FeKfiMJj_YmMmUKewFFUAcAkXQtJvqH4xIM4sl6G86qMxQ04_8VHMH1GP1N');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ed7c2f4c8f3a1da24c7ec7081f28c599318e5c3f', '14.169.252.140', '1496127355', 'B79heM9vpdZEeas8f9bgYukDxIVaXMTwy3Zc_HZ7hGV8chEMcmaa4r3Q1K4QrIJDU-Zq6i5jC1CdP5N3XoDO--qtTcYcI9PmVsDKLvSIy_EF7gcsheMksWUuknWxrJjEvsRBwxH0o2YHjWQcMAbpjUitX3FTtAg9u-XiRCWVC484rNTlvu4e8FxtFGBPE9wEwgqROXRKIXGSJQ5VD1Jn0Q..');


#
# TABLE STRUCTURE FOR: tblstaff
#

DROP TABLE IF EXISTS `tblstaff`;

CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` mediumtext,
  `linkedin` mediumtext,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(300) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(300) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(11,2) NOT NULL DEFAULT '0.00',
  `email_signature` text,
  PRIMARY KEY (`staffid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `email_signature`) VALUES ('1', 'amin@admin.com', '', '', NULL, NULL, NULL, NULL, '$2a$08$9uFKA7CEZjqLO3zSOQfPBul5FwOw8Xwj6pJs4onV4gHAn9Tlcv762', '2017-03-30 09:24:10', NULL, '14.169.252.140', '2017-05-30 13:11:21', NULL, NULL, NULL, '1', NULL, '1', 'vietnamese', NULL, NULL, '0', '0.00', NULL);
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `email_signature`) VALUES ('2', 'buiphamthanhthuy@gmail.com', 'Tân', 'Nguyễn', 'tannguyen', '', '0909365456', '', '$2a$08$GMPg1TJgHJsyM9Oa1bp4veWqPqkglBTxdmU.OkFTM8lJ9OS8oLwRe', '2017-03-31 00:37:49', NULL, '::1', '2017-03-31 00:42:57', NULL, NULL, NULL, '0', '1', '1', 'vietnamese', '', 'tan-nguyễn', '0', '200.00', '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `email_signature`) VALUES ('3', 'ngocha@gmail.com', 'Ngọc', 'Hà', '', '', '0909321456', '', '$2a$08$Mof54rGUKvPFdx5B9/su1u3xYZllzkE7gRGUY1NXj/4rWkS1OETWa', '2017-03-31 00:49:22', NULL, NULL, NULL, NULL, NULL, NULL, '0', '2', '1', 'vietnamese', '', 'ngọc-ha', '0', '200.00', '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `email_signature`) VALUES ('4', 'thuylinh@gmail.com', 'Thùy', 'Linh', '', '', '09123456789', '', '$2a$08$mxYDHk1OwXmcx7QVbtKDTeKprQua5DSEDZTLEhpg65wYscNF2RY86', '2017-03-31 00:50:39', NULL, '::1', '2017-04-03 12:57:20', NULL, NULL, NULL, '0', '3', '1', 'vietnamese', '', 'thuy-linh', '0', '150.00', '');


#
# TABLE STRUCTURE FOR: tblstaffdepartments
#

DROP TABLE IF EXISTS `tblstaffdepartments`;

CREATE TABLE `tblstaffdepartments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaffpermissions
#

DROP TABLE IF EXISTS `tblstaffpermissions`;

CREATE TABLE `tblstaffpermissions` (
  `staffpermid` int(11) NOT NULL AUTO_INCREMENT,
  `permissionid` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_own` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `staffid` int(11) NOT NULL,
  PRIMARY KEY (`staffpermid`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('1', '16', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('2', '1', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('3', '8', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('4', '9', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('5', '11', '0', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('6', '15', '0', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('7', '14', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('8', '18', '0', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('9', '19', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('10', '12', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('11', '17', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('12', '5', '0', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('13', '13', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('14', '3', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('15', '10', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('16', '4', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('17', '7', '0', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('18', '6', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('19', '2', '1', '0', '0', '0', '0', '2');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('20', '16', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('21', '1', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('22', '8', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('23', '9', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('24', '11', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('25', '15', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('26', '14', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('27', '18', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('28', '19', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('29', '12', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('30', '17', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('31', '5', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('32', '13', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('33', '3', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('34', '10', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('35', '4', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('36', '7', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('37', '6', '0', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('38', '2', '1', '0', '0', '0', '0', '3');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('39', '16', '0', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('40', '1', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('41', '8', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('42', '9', '0', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('43', '11', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('44', '15', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('45', '14', '0', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('46', '18', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('47', '19', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('48', '12', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('49', '17', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('50', '5', '0', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('51', '13', '0', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('52', '3', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('53', '10', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('54', '4', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('55', '7', '1', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('56', '6', '0', '0', '0', '0', '0', '4');
INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES ('57', '2', '0', '0', '0', '0', '0', '4');


#
# TABLE STRUCTURE FOR: tblstafftaskassignees
#

DROP TABLE IF EXISTS `tblstafftaskassignees`;

CREATE TABLE `tblstafftaskassignees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `staffid` (`staffid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblstafftaskassignees` (`id`, `staffid`, `taskid`, `assigned_from`) VALUES ('1', '4', '1', '1');
INSERT INTO `tblstafftaskassignees` (`id`, `staffid`, `taskid`, `assigned_from`) VALUES ('2', '4', '2', '1');
INSERT INTO `tblstafftaskassignees` (`id`, `staffid`, `taskid`, `assigned_from`) VALUES ('3', '4', '3', '1');


#
# TABLE STRUCTURE FOR: tblstafftaskcomments
#

DROP TABLE IF EXISTS `tblstafftaskcomments`;

CREATE TABLE `tblstafftaskcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblstafftaskcomments` (`id`, `content`, `taskid`, `staffid`, `contact_id`, `dateadded`) VALUES ('1', 'Đ&atilde; nhận được nhiệm vụ', '3', '4', '0', '2017-04-03 12:58:43');


#
# TABLE STRUCTURE FOR: tblstafftasks
#

DROP TABLE IF EXISTS `tblstafftasks`;

CREATE TABLE `tblstafftasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext,
  `description` text,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `recurring_ends_on` date DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `billable` tinyint(1) NOT NULL DEFAULT '0',
  `billed` tinyint(1) NOT NULL DEFAULT '0',
  `invoice_id` int(11) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(11,2) NOT NULL DEFAULT '0.00',
  `milestone` int(11) DEFAULT '0',
  `kanban_order` int(11) NOT NULL DEFAULT '0',
  `milestone_order` int(11) NOT NULL DEFAULT '0',
  `visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  `deadline_notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblstafftasks` (`id`, `name`, `description`, `priority`, `dateadded`, `startdate`, `duedate`, `datefinished`, `addedfrom`, `status`, `recurring_type`, `repeat_every`, `recurring`, `recurring_ends_on`, `custom_recurring`, `last_recurring_date`, `rel_id`, `rel_type`, `is_public`, `billable`, `billed`, `invoice_id`, `hourly_rate`, `milestone`, `kanban_order`, `milestone_order`, `visible_to_client`, `deadline_notified`) VALUES ('1', 'Nhiệm vụ 1', '', '2', '2017-04-03 12:52:35', '2017-04-03', '2017-04-05', '2017-04-03 12:53:07', '1', '5', 'month', '1', '1', NULL, '0', NULL, '2', 'customer', '0', '1', '0', '0', '0.00', '0', '0', '0', '0', '0');
INSERT INTO `tblstafftasks` (`id`, `name`, `description`, `priority`, `dateadded`, `startdate`, `duedate`, `datefinished`, `addedfrom`, `status`, `recurring_type`, `repeat_every`, `recurring`, `recurring_ends_on`, `custom_recurring`, `last_recurring_date`, `rel_id`, `rel_type`, `is_public`, `billable`, `billed`, `invoice_id`, `hourly_rate`, `milestone`, `kanban_order`, `milestone_order`, `visible_to_client`, `deadline_notified`) VALUES ('2', 'Chăm sóc khách hàng', '', '2', '2017-04-03 12:56:14', '2017-04-03', NULL, '2017-04-03 12:56:52', '1', '5', 'week', '2', '1', NULL, '0', NULL, '2', 'customer', '0', '1', '0', '0', '0.00', '0', '0', '0', '0', '0');
INSERT INTO `tblstafftasks` (`id`, `name`, `description`, `priority`, `dateadded`, `startdate`, `duedate`, `datefinished`, `addedfrom`, `status`, `recurring_type`, `repeat_every`, `recurring`, `recurring_ends_on`, `custom_recurring`, `last_recurring_date`, `rel_id`, `rel_type`, `is_public`, `billable`, `billed`, `invoice_id`, `hourly_rate`, `milestone`, `kanban_order`, `milestone_order`, `visible_to_client`, `deadline_notified`) VALUES ('3', 'Chăm sóc khách hàng', '', '2', '2017-04-03 12:58:03', '2017-04-03', NULL, '0000-00-00 00:00:00', '1', '4', 'week', '2', '1', NULL, '0', NULL, '2', 'customer', '0', '1', '0', '0', '0.00', '0', '0', '0', '0', '0');


#
# TABLE STRUCTURE FOR: tblstafftasksfollowers
#

DROP TABLE IF EXISTS `tblstafftasksfollowers`;

CREATE TABLE `tblstafftasksfollowers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblstafftasksfollowers` (`id`, `staffid`, `taskid`) VALUES ('1', '4', '1');
INSERT INTO `tblstafftasksfollowers` (`id`, `staffid`, `taskid`) VALUES ('2', '4', '3');


#
# TABLE STRUCTURE FOR: tblstatusbds
#

DROP TABLE IF EXISTS `tblstatusbds`;

CREATE TABLE `tblstatusbds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tblstatusbds` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES ('1', 'Đã bán', '1000', '#7cb342', '1');
INSERT INTO `tblstatusbds` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES ('2', 'Chưa bán', '1000', '#7cb342', '1');
INSERT INTO `tblstatusbds` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES ('3', 'Đã thuê', '1000', '#7cb342', '1');
INSERT INTO `tblstatusbds` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES ('4', 'Chưa thuê', '1000', '#7cb342', '1');


#
# TABLE STRUCTURE FOR: tblsurveyresultsets
#

DROP TABLE IF EXISTS `tblsurveyresultsets`;

CREATE TABLE `tblsurveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveys
#

DROP TABLE IF EXISTS `tblsurveys`;

CREATE TABLE `tblsurveys` (
  `surveyid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text NOT NULL,
  `viewdescription` text,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT '0',
  `onlyforloggedin` int(11) DEFAULT '0',
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY (`surveyid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveysemailsendcron
#

DROP TABLE IF EXISTS `tblsurveysemailsendcron`;

CREATE TABLE `tblsurveysemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveysendlog
#

DROP TABLE IF EXISTS `tblsurveysendlog`;

CREATE TABLE `tblsurveysendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT '0',
  `send_to_mail_lists` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltags
#

DROP TABLE IF EXISTS `tbltags`;

CREATE TABLE `tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltags_in
#

DROP TABLE IF EXISTS `tbltags_in`;

CREATE TABLE `tbltags_in` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT '0',
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaskchecklists
#

DROP TABLE IF EXISTS `tbltaskchecklists`;

CREATE TABLE `tbltaskchecklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `finished` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT '0',
  `list_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaskstimers
#

DROP TABLE IF EXISTS `tbltaskstimers`;

CREATE TABLE `tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(11,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaxes
#

DROP TABLE IF EXISTS `tbltaxes`;

CREATE TABLE `tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbltaxes` (`id`, `name`, `taxrate`) VALUES ('1', 'T', '5.00');


#
# TABLE STRUCTURE FOR: tblticketattachments
#

DROP TABLE IF EXISTS `tblticketattachments`;

CREATE TABLE `tblticketattachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` mediumtext NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketpipelog
#

DROP TABLE IF EXISTS `tblticketpipelog`;

CREATE TABLE `tblticketpipelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(500) NOT NULL,
  `name` varchar(200) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `message` mediumtext NOT NULL,
  `email` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketreplies
#

DROP TABLE IF EXISTS `tblticketreplies`;

CREATE TABLE `tblticketreplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT '0',
  `name` text,
  `email` text,
  `date` datetime NOT NULL,
  `message` text,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `ip` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets
#

DROP TABLE IF EXISTS `tbltickets`;

CREATE TABLE `tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT '0',
  `email` text,
  `name` text,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `message` text,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT '0',
  `adminread` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(40) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketsspamcontrol
#

DROP TABLE IF EXISTS `tblticketsspamcontrol`;

CREATE TABLE `tblticketsspamcontrol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketstatus
#

DROP TABLE IF EXISTS `tblticketstatus`;

CREATE TABLE `tblticketstatus` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT '0',
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('3', 'Answered', '1', '#0000ff', '3');
INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('4', 'On Hold', '1', '#c0c0c0', '4');
INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('2', 'In progress', '1', '#84c529', '2');
INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('5', 'Closed', '1', '#03a9f4', '5');
INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('1', 'Open', '1', '#ff2d42', '1');


#
# TABLE STRUCTURE FOR: tbltodoitems
#

DROP TABLE IF EXISTS `tbltodoitems`;

CREATE TABLE `tbltodoitems` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbluserautologin
#

DROP TABLE IF EXISTS `tbluserautologin`;

CREATE TABLE `tbluserautologin` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `tbluserautologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`, `staff`) VALUES ('67e637a5f78ab93f4180c306f413a5e3', '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '117.6.132.124', '2017-05-29 23:44:37', '1');


#
# TABLE STRUCTURE FOR: tblviewstracking
#

DROP TABLE IF EXISTS `tblviewstracking`;

CREATE TABLE `tblviewstracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblwebtolead
#

DROP TABLE IF EXISTS `tblwebtolead`;

CREATE TABLE `tblwebtolead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT '1',
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext,
  `responsible` int(11) NOT NULL DEFAULT '0',
  `name` varchar(400) NOT NULL,
  `form_data` mediumtext,
  `recaptcha` int(11) NOT NULL DEFAULT '0',
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT '1',
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

