<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Braintree extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
  }

  public function complete_purchase()
  {

    if ($this->input->post()) {

      $data      = $this->input->post();
      $total     = $this->input->post('amount');
      $this->load->model('invoices_model');
      $invoice             = $this->invoices_model->get($this->input->post('invoiceid'));
      check_invoice_restrictions($invoice->id, $invoice->hash);

      load_client_language($invoice->clientid);
      $data['amount']      = $total;
      $data['nonce']      =  $this->input->post('payment_method_nonce');
      $data['currency']    = $invoice->currency_name;
      $oResponse      = $this->paypal_braintree_gateway->finish_payment($data);
      if ($oResponse->isSuccessful()) {

       $transactionid  = $oResponse->getTransactionReference();
       $data['transactionid'] = $transactionid;
       $paymentResponse = $this->paypal_braintree_gateway->fetch_payment($transactionid);
       $paymentData      = $paymentResponse->getData();

               // Add payment to database
       $payment_data['amount']        = $data['amount'];
       $payment_data['invoiceid']     = $invoice->id;
       $payment_data['paymentmode']   = $this->paypal_braintree_gateway->get_id();
       $payment_data['paymentmethod']   = $paymentData->paymentInstrumentType;
       $payment_data['transactionid'] = $transactionid;
       $this->load->model('payments_model');
       $success = $this->payments_model->add($payment_data);
       if ($success) {
        set_alert('success', _l('online_payment_recorded_success'));
      } else {
        set_alert('danger', _l('online_payment_recorded_success_fail_database'));
      }
      redirect(site_url('viewinvoice/' . $invoice->id . '/' . $invoice->hash));

    } elseif ($oResponse->isRedirect()) {
      $oResponse->redirect();
    } else {
      set_alert('danger', $oResponse->getMessage());
      redirect(site_url('viewinvoice/' . $invoice->id . '/' . $invoice->hash));
    }
  }
}
public function make_payment()
{
  check_invoice_restrictions($this->input->get('invoiceid'), $this->input->get('hash'));
  $this->load->model('invoices_model');
  $invoice      = $this->invoices_model->get($this->input->get('invoiceid'));
  load_client_language($invoice->clientid);
  $data['invoice']      = $invoice;
  $data['total']        = $this->input->get('total');
  $data['client_token'] = $this->paypal_braintree_gateway->generate_token();
  echo $this->get_view($data);
}

public function get_view($data = array()){
  ob_start(); ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>
      <?php echo _l('payment_for_invoice') . ' ' . format_invoice_number($data['invoice']->id); ?>
    </title>
          <?php if(get_option('favicon') != ''){ ?>
      <link href="<?php echo base_url('uploads/company/'.get_option('favicon')); ?>" rel="shortcut icon">
      <?php } ?>
    <?php echo app_stylesheet('assets/css','reset.css'); ?>
    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href='<?php echo base_url('assets/plugins/roboto/roboto.css'); ?>' rel='stylesheet'>
    <?php echo app_stylesheet(template_assets_path().'/css','style.css'); ?>
    <script src="https://js.braintreegateway.com/js/braintree-2.30.0.min.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="col-md-8 col-md-offset-2 mtop30">
        <div class="row">
          <div class="panel_s">
            <div class="panel-body">
             <h4 class="bold no-margin font-medium">
              <?php echo _l('payment_for_invoice'); ?> <a href="<?php echo site_url('viewinvoice/'. $data['invoice']->id . '/' . $data['invoice']->hash); ?>"><?php echo format_invoice_number($data['invoice']->id); ?></a>
            </h4>
            <hr />
            <p><span class="bold"><?php echo _l('payment_total',format_money($data['total'],$data['invoice']->symbol)); ?></span></p>
            <form method="post" id="payment-form" action="<?php echo site_url('gateways/braintree/complete_purchase'); ?>">
              <section>
                <div class="bt-drop-in-wrapper">
                  <div id="bt-dropin"></div>
                </div>
                <input id="amount" name="amount" type="hidden" value="<?php echo number_format($data['total'], 2, '.', ''); ?>">
                <input type="hidden" name="invoiceid" value="<?php echo $data['invoice']->id; ?>">
              </section>
              <div class="text-center" style="margin-top:15px;">
                <button class="btn btn-info" type="submit"><?php echo _l('submit_payment'); ?></button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <script>
      braintree.setup('<?php echo $data['client_token']; ?>', 'dropin', {
        container: 'bt-dropin'
      });
    </script>
  </body>
  </html>
  <?php
  $contents = ob_get_contents();
  ob_end_clean();
  return $contents;
}
}

